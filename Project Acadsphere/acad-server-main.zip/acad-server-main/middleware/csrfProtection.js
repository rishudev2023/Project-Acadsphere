const csurf = require("csurf");
const cookieParser = require("cookie-parser");

const csrfProtection = csurf({ cookie: true });

const csrfMiddleware = (app) => {
  app.use(cookieParser());
  app.use(csrfProtection);

  app.use((err, req, res, next) => {
    if (err.code !== "EBADCSRFTOKEN") return next(err);

    res.status(403).json({ error: "Invalid CSRF token" });
  });
};

module.exports = csrfMiddleware;
