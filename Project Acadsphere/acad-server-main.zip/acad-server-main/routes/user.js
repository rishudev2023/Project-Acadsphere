const express = require("express");
const {
  registerController,
  authController,
  loginController,
  verifyOtpController,
  forgotPasswordController,
  resetPasswordController,
} = require("../controller/user");
const protect = require("../middleware/authMiddleware");
router = express.Router();

router.post("/register", registerController);
router.post("/get-user", protect, authController);
router.post("/login", loginController);
router.post("/verify-otp", verifyOtpController);
router.post("/forgot-password", forgotPasswordController);
router.post("/reset-password", resetPasswordController);
module.exports = router;
