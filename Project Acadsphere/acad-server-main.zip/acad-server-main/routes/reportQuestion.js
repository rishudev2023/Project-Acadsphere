const express = require("express");
const {
  reportQuestion,
  getQuestionReports,
} = require("../controller/reportQuestion");
const protect = require("../middleware/authMiddleware");
router = express.Router();

router.post("/question", reportQuestion);
router.get("/question-reports", getQuestionReports);

module.exports = router;
