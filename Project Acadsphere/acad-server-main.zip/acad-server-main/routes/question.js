const express = require("express");
const protect = require("../middleware/authMiddleware");
const getUserData = require("../middleware/getUserData");
const checkSubscription = require("../middleware/checkSubscriptionStatus");

const {
  createQuestion,
  getQuestionByYearAndSubject,
  getQuestionBySubjectAndModule,
  getQuestionByID,
} = require("../controller/question");

router = express.Router();

router.post("/addquestion", protect, getUserData, createQuestion);

router.get(
  "/getQuestionByYear&Subject",
  protect,
  getUserData,
  checkSubscription,
  getQuestionByYearAndSubject
);

router.get(
  "/getQuestionBySubjectAndModule",
  protect,
  getUserData,
  checkSubscription,
  getQuestionBySubjectAndModule
);

router.get("/getQuestionByID", getQuestionByID);

module.exports = router;
