const express = require("express");
const {
  createFeedbackController,
  getFeedbackController,
} = require("../controller/feedback");

router = express.Router();

router.post("/submit-feedback", createFeedbackController);
router.get("/get-feedback", getFeedbackController);

module.exports = router;
