const express = require("express");
const { getMyQuestions } = require("../controller/adminQuestions");
const protect = require("../middleware/authMiddleware");
const getUserData = require("../middleware/getUserData");

router = express.Router();

router.get("/my-questions", protect, getUserData, getMyQuestions);

module.exports = router;
