const express = require("express");
const protect = require("../middleware/authMiddleware");
const {
  createDetailedNotes,
  getNotesBySubjectAndModule,
} = require("../controller/notes");

router = express.Router();

router.post("/addDetailedNotes", protect, createDetailedNotes);

router.get("/getNotesBySubjectAndModule", getNotesBySubjectAndModule);

module.exports = router;
