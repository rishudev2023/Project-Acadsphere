const express = require("express");
const router = express.Router();
const dataStats = require("../controller/dataStats");

router.get("/total", dataStats.getTotalUsers);
router.get("/monthly", dataStats.getMonthlyUsers);
router.get("/yearly", dataStats.getYearlyUsers);
router.get("/today", dataStats.getTodayUsers);
router.get("/total-questions", dataStats.getTotalQuestions); // New route for total questions

module.exports = router;
