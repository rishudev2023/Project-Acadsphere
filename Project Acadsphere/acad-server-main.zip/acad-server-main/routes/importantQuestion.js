const express = require("express");
const {
  addImportantQuestion,
  getImportantQuestions,
  removeImportantQuestion,
} = require("../controller/importantQuestion");
const protect = require("../middleware/authMiddleware");
const getUserData = require("../middleware/getUserData");

router = express.Router();

router.post("/addImpQues", addImportantQuestion);
router.post("/removeImpQues", removeImportantQuestion);
router.get("/getImpQues", getImportantQuestions);

module.exports = router;
