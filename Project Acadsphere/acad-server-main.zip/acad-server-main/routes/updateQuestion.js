const express = require("express");

const protect = require("../middleware/authMiddleware");
const getUserData = require("../middleware/getUserData");

const {
  getQuestionForEdit,
  updateQuestion,
} = require("../controller/updateQuestion");

router = express.Router();

router.get("/:id/edit", protect, getUserData, getQuestionForEdit);

router.put("/:id/edit", protect, getUserData, updateQuestion);

module.exports = router;
