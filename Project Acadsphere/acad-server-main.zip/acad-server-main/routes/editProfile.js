const express = require("express");

const protect = require("../middleware/authMiddleware");
const getUserData = require("../middleware/getUserData");

const { getUserToEdit, updateUser } = require("../controller/editProfile");

router = express.Router();

router.get("/editProfile", protect, getUserData, getUserToEdit);

router.put("/updateProfile", protect, getUserData, updateUser);

module.exports = router;
