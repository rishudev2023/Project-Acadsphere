const express = require("express");
const router = express.Router();
const paymentController = require("../controller/payment");

// POST route to initiate a payment
router.post("/initiate", paymentController.initiatePayment);

// POST route to handle payment success callback from Razorpay
router.post("/success", paymentController.handlePaymentSuccess);

module.exports = router;
