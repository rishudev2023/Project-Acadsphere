const express = require("express");
const {
  createNotification,
  fetchNotifications,
} = require("../controller//notification");
const protect = require("../middleware/authMiddleware");
const getUserData = require("../middleware/getUserData");

const router = express.Router();

router.post("/create-notification", protect, getUserData, createNotification);
router.get("/get-notifications", fetchNotifications);

module.exports = router;
