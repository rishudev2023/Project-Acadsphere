const express = require("express");
const {
  fetchPosts,
  fetchDetailedPost,
  createPost,
  likePost,
  commentOnPost,
  sharePost,
  editPost,
  deletePost,
  fetchCommentsForPost,
  fetchPostsByUser,
  likeComment,
  deleteComment,
} = require("../controller/postController");
const protect = require("../middleware/authMiddleware");
const getUserData = require("../middleware/getUserData");

const router = express.Router();

router.get("/posts", protect, getUserData, fetchPosts);
router.get("/post/:postId", protect, getUserData, fetchDetailedPost);
router.post("/create-post", protect, getUserData, createPost);
router.put("/posts/:id/like", protect, getUserData, likePost);
router.post("/posts/:id/comment", protect, getUserData, commentOnPost);
router.post("/posts/:id/share", protect, getUserData, sharePost);
router.put("/posts/:id/edit", protect, getUserData, editPost);
router.delete("/posts/:id", protect, getUserData, deletePost);
router.get("/posts/:id/comments", protect, getUserData, fetchCommentsForPost);
router.get("/user/:id/posts", protect, getUserData, fetchPostsByUser);
router.put("/comment/:id/like", protect, getUserData, likeComment);
router.delete("/comment/:id", protect, getUserData, deleteComment);

module.exports = router;
