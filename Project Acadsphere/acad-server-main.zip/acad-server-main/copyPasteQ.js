const mongoose = require("mongoose");
const Question = require("./model/Question");
require("dotenv").config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB);

const copyQuestions = async () => {
  try {
    // Fetch all questions for subject 'BEE' in branch 'CSE'
    const cseQuestions = await Question.find({
      branch: "MECH",
      subject: "PPS",
      semester: "Second",
    });

    if (cseQuestions.length === 0) {
      console.log("No questions found for BEE in CSE branch.");
      return;
    }

    // Prepare new questions for EEE branch
    const eeeQuestions = cseQuestions.map((question) => {
      const {
        semester,
        year,
        subject,
        module,
        question: ques,
        answer,
        importantQues,
        createdBy,
        lastEditedBy,
      } = question;

      // Create a new question for EEE branch
      return {
        semester,
        branch: "CIVIL", // Change the branch to 'EEE'
        year,
        subject,
        module,
        question: ques,
        answer,
        importantQues,
        createdBy,
        lastEditedBy,
      };
    });

    // Insert the new questions for the EEE branch
    await Question.insertMany(eeeQuestions);
    console.log(
      `${eeeQuestions.length} questions copied from CSE to EEE for subject BEE.`
    );
  } catch (error) {
    console.error("Error copying questions:", error);
  } finally {
    // Close the database connection
    mongoose.connection.close();
  }
};

// Call the function to copy questions
copyQuestions();
