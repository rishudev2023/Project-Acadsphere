const mongoose = require("mongoose");
const algoliasearch = require("algoliasearch");
const dotenv = require("dotenv");
const Question = require("./model/Question");

dotenv.config();

const client = algoliasearch(
  process.env.APPLICATION_ID,
  process.env.ALGOLIA_ADMIN_API_KEY
);
const index = client.initIndex("questions_index");

index.setSettings({
  attributesForFaceting: ["question"], // Only include the 'question' attribute
});

async function fetchDataAndIndex() {
  try {
    await mongoose.connect(process.env.MONGODB);
    console.log("Connected to MongoDB");

    const data = await Question.find({}).lean();

    const objects = data.map((item) => ({
      objectID: item._id.toString(),
      ...item,
    }));

    index
      .saveObjects(objects)
      .then(({ objectIDs }) => {
        console.log("Data indexed in Algolia:", objectIDs);
      })
      .catch((err) => {
        console.error("Error indexing data:", err);
      });
  } catch (error) {
    console.error("Error fetching data from MongoDB:", error);
  } finally {
    await mongoose.connection.close();
    console.log("Disconnected from MongoDB");
  }
}

fetchDataAndIndex().catch(console.error);
