const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../model/User");
const otpGenerator = require("otp-generator");
const nodemailer = require("nodemailer");
require("dotenv").config();

const transporter = nodemailer.createTransport({
  host: "smtp.hostinger.com",
  port: 465,
  secure: true,
  auth: {
    user: "rishu@acadsphere.in",
    pass: process.env.EMAIL_PASS,
  },
});

const registerController = async (req, res) => {
  try {
    const existingUser = await User.findOne({ email: req.body.email });
    if (existingUser) {
      return res.status(200).send({
        message: "User already exists",
        success: false,
      });
    }

    const password = req.body.password;
    const salt = await bcrypt.genSalt(10);
    const hashPassword = await bcrypt.hash(password, salt);
    req.body.password = hashPassword;

    const confirmPassword = await bcrypt.hash(req.body.passwordConfirm, salt);
    req.body.passwordConfirm = confirmPassword;

    if (req.body.password !== req.body.passwordConfirm) {
      return res.status(400).send({
        message: "Passwords do not match",
        success: false,
      });
    }

    const otp = otpGenerator.generate(6, {
      digits: true,
      upperCase: false,
      specialChars: false,
      upperCaseAlphabets: false,
      lowerCaseAlphabets: false,
    });

    const newUser = new User({
      name: req.body.name,
      email: req.body.email,
      college: req.body.college,
      semester: req.body.semester,
      branch: req.body.branch,
      profileImage: req.body.profileImage,
      password: req.body.password,
      passwordConfirm: req.body.passwordConfirm,
      otp: otp,
    });
    await newUser.save();

    const token = jwt.sign({ id: newUser.id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    const mailOptions = {
      from: "rishu@acadsphere.in",
      to: req.body.email,
      bcc: "acadsphere@gmail.com",
      subject: "OTP for Email Verification",
      text: `Hi,
      Welcome to Acadsphere
      Here is your OTP: ${otp}.
      This is an auto-generated email, reply only if you have any questions.`,
    };

    await transporter.sendMail(mailOptions);

    return res.status(201).send({
      message: "Register successful, OTP sent to email",
      data: {
        user: newUser,
        otp: null,
        token,
      },
      success: true,
    });
  } catch (error) {
    console.error("Server error:", error);
    return res.status(500).send({
      message: "Register error",
      success: false,
    });
  }
};

const authController = async (req, res) => {
  try {
    const user = await User.findOne({ _id: req.body.userId });
    if (!user) {
      return res.status(200).send({
        message: "User not found",
        success: false,
      });
    } else {
      return res.status(200).send({
        message: "Registered successfully",
        data: {
          user,
        },
        success: true,
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: `Auth error`,
    });
  }
};

const loginController = async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email }).select(
      "+password"
    );
    if (!user) {
      return res.status(200).send({
        message: "User not found",
        success: false,
      });
    }

    const isMatch = await bcrypt.compare(req.body.password, user.password);
    const signuser = await User.findOne({ email: req.body.email });
    if (!isMatch) {
      return res.status(200).send({
        success: false,
        message: `Invalid password or email`,
      });
    }

    const token = jwt.sign({ id: signuser.id }, process.env.JWT_SECRET, {
      expiresIn: "30d",
    });

    return res.status(201).send({
      message: "Login successfully",
      data: {
        user: signuser,
        token,
      },

      success: true,
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: `Auth error`,
    });
  }
};

const verifyOtpController = async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    if (user.otp === req.body.combineOtp) {
      user.isVerified = true;
      await user.save();
      res.status(200).send({
        success: true,
        message: `otp verified`,
      });
    } else {
      res.status(200).send({
        success: false,
        message: `otp not verified`,
      });
    }
  } catch (error) {
    res.status(500).send({
      success: false,
      message: `failed to verify`,
    });
  }
};

const forgotPasswordController = async (req, res) => {
  try {
    const existingUser = await User.findOne({ email: req.body.email });
    if (!existingUser) {
      return res.status(200).send({
        message: "User not found",
        success: false,
      });
    }

    const signUser = await User.findOne({ email: req.body.email });

    const token = jwt.sign({ id: existingUser._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    const mailOptions = {
      from: "rishu@acadsphere.in",
      to: req.body.email,
      bcc: "acadsphere@gmail.com",
      subject: "Password Reset Link",
      text: `Hi, 
      Welcome to Acadsphere 
      Please use the following link to reset your password: 
      https://acadsphere.in/accounts/reset-password?token=${token}

      This link will expire in 24 hours.

      This is an auto generated email, reply only if you have any questions.
      `,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        return res.status(500).send({
          message: "Error sending email",
          success: false,
        });
      }

      return res.status(201).send({
        message: "Password reset link sent to your email",
        data: {
          user: signUser,
          token,
        },

        success: true,
      });
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      message: "Server error",
      success: false,
    });
  }
};

const resetPasswordController = async (req, res) => {
  try {
    const { password, token } = req.body;

    if (!token) {
      return res.status(400).send({
        message: "Invalid or missing token",
        success: false,
      });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
      const issuedAt = decoded.iat * 1000; // `iat` is in seconds, convert to milliseconds
      const currentTime = Date.now(); // Current time in milliseconds

      // 24 hours = 24 * 60 * 60 * 1000 milliseconds
      const tokenAge = currentTime - issuedAt;

      if (tokenAge >= 24 * 60 * 60 * 1000) {
        return res.status(400).send({
          message: "Invalid or expired token",
          success: false,
        });
      }
    } catch (err) {
      return res.status(400).send({
        message: "Invalid or expired token",
        success: false,
      });
    }

    const existingUser = await User.findById(decoded.id);
    if (!existingUser) {
      return res.status(404).send({
        message: "User not found",
        success: false,
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    existingUser.password = hashedPassword;
    await existingUser.save();

    return res.status(200).send({
      message: "Password reset successfully",
      success: true,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      message: "Server error",
      success: false,
    });
  }
};

module.exports = {
  registerController,
  authController,
  loginController,
  verifyOtpController,
  forgotPasswordController,
  resetPasswordController,
};
