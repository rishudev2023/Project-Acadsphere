const Question = require("../model/Question");

const getQuestionForEdit = async (req, res) => {
  try {
    const { id } = req.params;

    const userId = req.user.id;
    const isAdmin = req.user.role === "admin";

    const question = await Question.findById(id);

    if (!question) {
      return res.status(404).send("Question not found");
    }

    if (question.createdBy !== userId && !isAdmin) {
      return res.status(403).send("Permission denied");
    }

    res.json(question);
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
};

const updateQuestion = async (req, res) => {
  const { id } = req.params;

  const userId = req.user.id;
  const isAdmin = req.user.role === "admin";

  const { semester, branch, year, subject, module, question, answer } =
    req.body;

  try {
    let existingQuestion = await Question.findById(id);
    if (!existingQuestion) {
      return res.status(404).send("Question not found");
    }
    if (existingQuestion.createdBy !== userId && !isAdmin) {
      return res.status(403).send("Permission denied");
    }

    existingQuestion.semester = semester;
    existingQuestion.branch = branch;
    existingQuestion.year = year;
    existingQuestion.subject = subject;
    existingQuestion.module = module;
    existingQuestion.question = question;
    existingQuestion.answer = answer;
    existingQuestion.lastEditedBy = userId;
    existingQuestion.createdBy = userId;

    await existingQuestion.save();
    res.json(existingQuestion);
  } catch (error) {
    console.log(error);
    res.status(500).send("Server error");
  }
};

module.exports = { getQuestionForEdit, updateQuestion };
