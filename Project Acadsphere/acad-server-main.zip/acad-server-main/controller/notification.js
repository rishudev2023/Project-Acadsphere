const Notification = require("../model/Notification");

const createNotification = async (req, res) => {
  try {
    // Check if the user's role is admin
    if (req.user.role !== "admin") {
      return res.status(403).json({
        message: "Forbidden: Only admins can create notifications",
        success: false,
      });
    }

    const { title, message } = req.body;

    const newNotification = new Notification({
      title,
      message,
    });

    const savedNotification = await newNotification.save();
    res.status(201).json({
      message: "Notification created successfully",
      success: true,
      data: savedNotification,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

// Fetch all notifications
const fetchNotifications = async (req, res) => {
  try {
    const notifications = await Notification.find().sort({ createdAt: -1 });
    res.status(200).json({
      message: "Notifications fetched successfully",
      success: true,
      data: notifications,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      error: "Error fetching notifications",
      success: false,
    });
  }
};

module.exports = {
  createNotification,
  fetchNotifications,
};
