const cloudinary = require("cloudinary");

cloudinary.config({
  cloud_name: "dholu25rb",
  api_key: "361471858737972",
  api_secret: "CYy9bKnVJKw3LwgpLSg0QbyP04g",
});

const imageUploadController = async (req, res) => {
  try {
    const result = await cloudinary.uploader.upload(req.files.image.path);
    res.json({
      url: result.secure_url,
      public_id: result.public_id,
    });
  } catch (error) {
    console.log(error);
  }
};

module.exports = { imageUploadController };
