const DetailedNotes = require("../model/DetailedNotes");

const createDetailedNotes = async (req, res) => {
  try {
    const { subject, module, topic, topicExplanation } = req.body;
    const newDetailedNotes = new DetailedNotes({
      subject,
      module,
      topic,
      topicExplanation,
    });

    if (!subject || !module || !topic || !topicExplanation) {
      return res
        .status(400)
        .json({ success: false, message: "All fields are required" });
    }

    const saveDetailedNotes = newDetailedNotes.save();
    res.status(200).json({
      message: "topic added successfully",
      success: true,
      data: {
        DetailedNotes: saveDetailedNotes,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

const getNotesBySubjectAndModule = async (req, res) => {
  try {
    const { module, subject } = req.query;
    const notesLists = await DetailedNotes.find({
      module: module,
      subject: subject,
    });
    res.status(200).json({
      message: "detailed notes by subject and module",
      success: true,
      data: {
        notes: notesLists,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

module.exports = {
  createDetailedNotes,
  getNotesBySubjectAndModule,
};
