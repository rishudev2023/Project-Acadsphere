const Question = require("../model/Question");
const User = require("../model/User");
const ImportantQuestion = require("../model/ImportantQuestion");

const addImportantQuestion = async (req, res) => {
  try {
    const { userId, questionId } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const question = await Question.findById(questionId);
    if (!question) {
      return res.status(404).json({ message: "Question not found" });
    }

    const importantQuestion = new ImportantQuestion({ question: questionId });

    await importantQuestion.save();

    user.importantQues.push(importantQuestion._id);
    await user.save();

    res.status(201).json({
      message: "Important question added successfully",
      importantQuestion,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

const removeImportantQuestion = async (req, res) => {
  try {
    const { userId, questionId } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const importantQuestion = await ImportantQuestion.findOneAndDelete({
      question: questionId,
    });

    if (!importantQuestion) {
      return res.status(404).json({ message: "Important question not found" });
    }

    user.importantQues.pull(importantQuestion._id);
    await user.save();

    res
      .status(200)
      .json({ message: "Important question removed successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

const getImportantQuestions = async (req, res) => {
  try {
    const { userId, subject } = req.query;

    const user = await User.findById(userId).populate("importantQues");
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const importantQuestionIds = user.importantQues.map((iq) => iq._id);

    // Find important question documents in the 'ImportantQuestion' collection
    const importantQuestionDocs = await ImportantQuestion.find({
      _id: { $in: importantQuestionIds },
    });

    // Extract question IDs from important question documents
    const questionIds = importantQuestionDocs.map((doc) => doc.question);

    // Find questions in the 'Question' collection using the extracted question IDs
    const importantQuestions = await Question.find({
      _id: { $in: questionIds },
      subject: subject,
    });

    res.status(200).json({
      message: "got important questions",
      success: true,
      data: importantQuestions,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

module.exports = {
  getImportantQuestions,
};

module.exports = {
  addImportantQuestion,
  getImportantQuestions,
  removeImportantQuestion,
};
