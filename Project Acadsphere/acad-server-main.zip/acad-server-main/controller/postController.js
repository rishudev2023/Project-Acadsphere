const Post = require("../model/Post");
const User = require("../model/User");

const createPost = async (req, res) => {
  try {
    const { text } = req.body;

    const newPost = new Post({
      text,
      createdBy: req.user._id,
    });

    const savePost = await newPost.save();
    res.status(200).json({
      message: "Posted",
      success: true,
      data: {
        post: savePost,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

const fetchPosts = async (req, res) => {
  try {
    // Fetch posts and populate user data from the createdBy field
    const postLists = await Post.find()
      .populate({
        path: "createdBy", // The field in Post that references the User
        select: "name profileImage college", // Select specific fields to return
      })
      .sort({ createdAt: -1 });

    res.status(200).json({
      message: "Fetching posts",
      success: true,
      data: {
        posts: postLists,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error fetching posts" });
  }
};

const fetchDetailedPost = async (req, res) => {
  try {
    const postId = req.params.postId;

    const post = await Post.findById(postId).populate({
      path: "createdBy",
      select: "name college profileImage",
    });

    if (!post) {
      return res.status(404).json({ message: "Post not found" });
    }

    res.status(200).json(post);
  } catch (error) {
    console.error("Error fetching post:", error);
    res.status(500).json({ message: "Server error" });
  }
};

const likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res
        .status(404)
        .json({ success: false, message: "Post not found" });
    }

    const alreadyLiked = post.likes.includes(req.user._id);
    if (alreadyLiked) {
      post.likes.pull(req.user._id);
    } else {
      post.likes.push(req.user._id);
    }

    await post.save();
    res.status(200).json({ success: true, likes: post.likes });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal server error", success: false });
  }
};

const commentOnPost = async (req, res) => {
  try {
    const { text } = req.body;
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res
        .status(404)
        .json({ success: false, message: "Post not found" });
    }

    const comment = {
      text,
      createdBy: req.user._id,
    };

    post.comments.push(comment);
    await post.save();
    res.status(200).json({ success: true, comments: post.comments });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal server error", success: false });
  }
};

// Share a post
const sharePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res
        .status(404)
        .json({ success: false, message: "Post not found" });
    }

    post.sharedBy.push(req.user._id);
    await post.save();
    res
      .status(200)
      .json({ success: true, message: "Post shared successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal server error", success: false });
  }
};

// Edit a post
const editPost = async (req, res) => {
  try {
    const { text } = req.body;
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res
        .status(404)
        .json({ success: false, message: "Post not found" });
    }

    // Check if user is the creator of the post or an admin
    if (
      post.createdBy.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res
        .status(403)
        .json({ success: false, message: "Unauthorized to edit this post" });
    }

    post.text = text;
    post.lastEditedBy = req.user._id;
    await post.save();
    res.status(200).json({ success: true, post });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal server error", success: false });
  }
};

const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res
        .status(404)
        .json({ success: false, message: "Post not found" });
    }

    // Check if user is the creator of the post or an admin
    if (
      post.createdBy.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res
        .status(403)
        .json({ success: false, message: "Unauthorized to delete this post" });
    }

    await post.deleteOne();
    res
      .status(200)
      .json({ success: true, message: "Post deleted successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal server error", success: false });
  }
};

//fetching comments to a post
const fetchCommentsForPost = async (req, res) => {
  const postId = req.params.id;

  try {
    const post = await Post.findById(postId).populate(
      "comments.createdBy",
      "name email profileImage"
    );
    if (!post) {
      return res.status(404).json({ message: "Post not found." });
    }

    return res.status(200).json(post.comments);
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Server error", error: error.message });
  }
};

//fetch posts created by a user
const fetchPostsByUser = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1; // Get the current page from query params
    const limit = parseInt(req.query.limit) || 10; // Number of posts per page
    const skip = (page - 1) * limit; // Calculate the number of posts to skip

    // Fetch posts and populate user data from the createdBy field
    const postLists = await Post.find({ createdBy: req.user._id })
      .populate({
        path: "createdBy", // The field in Post that references the User
        select: "name profileImage college", // Select specific fields to return
      })
      .sort({ createdAt: -1 }) // Sort by creation date in descending order
      .skip(skip) // Skip the appropriate number of posts
      .limit(limit); // Limit the number of posts returned

    // Get total count of posts for pagination
    const totalPosts = await Post.countDocuments({ createdBy: req.user._id });

    res.status(200).json({
      message: "Fetching posts",
      success: true,
      data: {
        posts: postLists,
        totalPosts, // Include total count for pagination
        totalPages: Math.ceil(totalPosts / limit), // Calculate total pages
        currentPage: page, // Include current page
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Error fetching posts" });
  }
};

const likeComment = async (req, res) => {
  const postId = req.params.postId;
  const commentId = req.params.commentId;
  const userId = req.user._id;

  try {
    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ message: "Post not found." });
    }

    const comment = post.comments.id(commentId);
    if (!comment) {
      return res.status(404).json({ message: "Comment not found." });
    }

    // Check if user has already liked the comment
    if (comment.likes.includes(userId)) {
      return res.status(400).json({ message: "Comment already liked." });
    }

    // Add user ID to likes array
    comment.likes.push(userId);
    await post.save();

    return res
      .status(200)
      .json({ message: "Comment liked successfully.", comment, success: true });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ message: "Server error", error: error.message });
  }
};

// Controller to delete a comment
const deleteComment = async (req, res) => {
  const commentId = req.params.commentId;
  const postId = req.params.postId;

  const userId = req.user._id;

  try {
    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ message: "Post not found." });
    }

    const comment = post.comments.id(commentId);
    if (!comment) {
      return res.status(404).json({ message: "Comment not found." });
    }

    if (
      comment.createdBy.toString() !== userId.toString() &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({
        message: "You are not authorized to delete this comment.",
        success: true,
      });
    }

    comment.deleteOne();
    await post.save();

    return res.status(200).json({ message: "Comment deleted successfully." });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ message: "Server error", error: error.message });
  }
};

module.exports = {
  createPost,
  fetchPosts,
  fetchDetailedPost,
  likePost,
  commentOnPost,
  sharePost,
  editPost,
  deletePost,
  fetchCommentsForPost,
  fetchPostsByUser,
  likeComment,
  deleteComment,
};
