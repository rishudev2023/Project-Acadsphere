const Question = require("../model/Question");

const getMyQuestions = async (req, res) => {
  try {
    const questions = await Question.find({ createdBy: req.user._id });
    res.json(questions);
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
};

module.exports = { getMyQuestions };
