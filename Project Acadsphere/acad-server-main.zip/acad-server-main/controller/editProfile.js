const User = require("../model/User");

const getUserToEdit = async (req, res) => {
  try {
    const userId = req.user.id;

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).send("User not found");
    }

    res.status(200).json({
      data: user,
      success: true,
    });
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
};

const updateUser = async (req, res) => {
  const userId = req.user.id;

  const { name, college, semester, branch, profileImage } = req.body;

  try {
    let existingUser = await User.findById(userId);
    if (!existingUser) {
      return res.status(404).send("User not found");
    }

    existingUser.name = name;
    existingUser.college = college;
    existingUser.semester = semester;
    existingUser.branch = branch;
    existingUser.profileImage = profileImage;

    await existingUser.save();
    res.json(existingUser);
  } catch (error) {
    console.log(error);
    res.status(500).send("Server error");
  }
};

module.exports = { getUserToEdit, updateUser };
