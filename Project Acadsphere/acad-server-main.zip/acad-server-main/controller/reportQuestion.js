const express = require("express");
const ReportedQuestion = require("../model/ReportedQuestion");

const reportQuestion = async (req, res) => {
  try {
    const { questionId, userId, reason } = req.body;

    if (!questionId || !userId || !reason) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    const newReportedQuestion = new ReportedQuestion({
      questionId,
      userId,
      reason,
    });

    await newReportedQuestion.save();

    res.status(201).json({
      success: true,
      message: "Report submitted successfully",
      data: newReportedQuestion,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};

const getQuestionReports = async (req, res) => {
  try {
    const { questionId, userId } = req.query;
    const query = {};

    if (questionId) {
      query.questionId = questionId;
    }
    if (userId) {
      query.userId = userId;
    }

    const reports = await ReportedQuestion.find(query)
      .populate("questionId", "question answer")
      .populate("userId", "name email");

    if (reports.length === 0) {
      return res.status(404).json({
        message: "No reports found",
        success: false,
      });
    }

    res.status(200).json({
      message: "Reports retrieved successfully",
      success: true,
      data: reports,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

module.exports = { reportQuestion, getQuestionReports };
