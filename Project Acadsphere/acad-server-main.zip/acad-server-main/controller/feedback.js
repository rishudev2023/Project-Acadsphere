const Feedback = require("../model/Feedback");

const createFeedbackController = async (req, res) => {
  try {
    const { name, email, message } = req.body;

    // Basic validation
    if (!name || !email || !message) {
      return res.status(400).json({
        message: "All fields are required",
        success: false,
      });
    }

    const newFeedback = new Feedback({
      name,
      email,
      message,
    });

    await newFeedback.save();

    res.status(201).json({
      message: "Thanks for your feedback!",
      success: true,
      data: {
        feedback: newFeedback,
      },
    });
  } catch (error) {
    console.error("Error saving feedback:", error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

const getFeedbackController = async (req, res) => {
  try {
    const { email } = req.query;

    const FeedbackMessages = await Feedback.find(email ? { email } : {});

    res.status(200).json({
      message: "got feedback messages",
      success: true,
      feedback: FeedbackMessages,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

module.exports = { createFeedbackController, getFeedbackController };
