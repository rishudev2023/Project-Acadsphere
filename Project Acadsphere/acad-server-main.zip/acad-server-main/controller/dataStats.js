const Question = require("../model/Question");
const User = require("../model/User");

exports.getTotalQuestions = async (req, res) => {
  try {
    const totalQuestions = await Question.countDocuments();
    res.json({ totalQuestions });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};
exports.getTotalUsers = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    res.json({ totalUsers });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getMonthlyUsers = async (req, res) => {
  try {
    // Assuming 'createdAt' is the field storing user creation date
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - 1);
    const monthlyUsers = await User.countDocuments({
      createdAt: { $gte: startDate },
    });
    res.json({ monthlyUsers });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getYearlyUsers = async (req, res) => {
  try {
    const startDate = new Date();
    startDate.setFullYear(startDate.getFullYear() - 1);
    const yearlyUsers = await User.countDocuments({
      createdAt: { $gte: startDate },
    });
    res.json({ yearlyUsers });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};

exports.getTodayUsers = async (req, res) => {
  try {
    const startDate = new Date();
    startDate.setHours(0, 0, 0, 0);
    const todayUsers = await User.countDocuments({
      createdAt: { $gte: startDate },
    });
    res.json({ todayUsers });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};
