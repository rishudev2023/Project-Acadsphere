const Razorpay = require("razorpay");
const crypto = require("crypto");
const Subscription = require("../model/Subscription");
const Payment = require("../model/Payment");
const User = require("../model/User");
const dotenv = require("dotenv");
const nodemailer = require("nodemailer");
require("dotenv").config();

const transporter = nodemailer.createTransport({
  host: "smtp.hostinger.com",
  port: 465,
  secure: true, // use TLS
  auth: {
    user: "rishu@acadsphere.in",
    pass: process.env.EMAIL_PASS,
  },
});

dotenv.config();

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// Controller function to initiate a payment
exports.initiatePayment = async (req, res) => {
  const { userId, amount } = req.body;

  try {
    const options = {
      amount: amount * 100, // Amount in paisa
      currency: "INR",
      receipt: `receipt_${userId}`,
    };

    const order = await razorpay.orders.create(options);

    const payment = new Payment({
      userId,
      amount,
      razorpayPaymentId: order.id,
    });
    await payment.save();

    res.json({
      orderId: order.id,
      amount: order.amount / 100,
      currency: order.currency,
      receipt: order.receipt,
    });
  } catch (error) {
    console.error("Error creating Razorpay order:", error);
    res.status(500).json({ message: "Failed to initiate payment" });
  }
};

// Controller function to handle payment success callback
exports.handlePaymentSuccess = async (req, res) => {
  const { razorpay_payment_id, razorpay_order_id, razorpay_signature } =
    req.body;

  try {
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(razorpay_order_id + "|" + razorpay_payment_id)
      .digest("hex");

    if (expectedSignature !== razorpay_signature) {
      return res.status(400).json({ error: "Invalid payment signature" });
    }

    const payment = await Payment.findOne({
      razorpayPaymentId: razorpay_order_id,
    });
    if (!payment) {
      return res.status(404).json({ error: "Payment not found" });
    }

    const subscriptionEnd = new Date();
    subscriptionEnd.setMonth(subscriptionEnd.getMonth() + 1);

    // Create subscription record
    const subscription = new Subscription({
      userId: payment.userId,
      amount: payment.amount,
      paymentId: payment._id,
      subscriptionEnd,
    });
    await subscription.save();

    // Update user's subscription status
    const user = await User.findByIdAndUpdate(
      payment.userId,
      {
        $set: {
          "subscription.status": "active",
          "subscription.planId": payment._id,
          "subscription.razorpaySubscriptionId": razorpay_payment_id,
          "subscription.validUntil": subscriptionEnd,
        },
      },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    payment.status = "success";
    await payment.save();

    res.json({ status: "success", message: "Payment successful", user });

    const mailOptions = {
      from: "rishu@acadsphere.in",
      to: user?.email,
      bcc: "acadsphere@gmail.com",
      subject: "Subscription Purchased Successfully",
      text: `Subject: Thank You for Your Subscription!

Dear ${user?.name}, 

Thank you for subscribing to Acadsphere! We’re excited to have you on board and can’t wait for you to explore all the resources available to enhance your learning experience.

If you have any questions, feel free to reach out!

Happy studying!

Best,
The Acadsphere Team`,
    };

    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error("Error processing payment callback:", error);
    res.status(500).json({ error: "Payment processing failed" });
  }
};
