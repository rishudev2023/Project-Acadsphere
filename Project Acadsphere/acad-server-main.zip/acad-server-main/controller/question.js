const Question = require("../model/Question");

const createQuestion = async (req, res) => {
  try {
    const { semester, branch, year, subject, module, question, answer } =
      req.body;

    if (req.user.role !== "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Only admins can add questions" });
    }

    const newQuestion = new Question({
      semester,
      branch,
      year,
      subject,
      module,
      question,
      answer,
      createdBy: req.user._id,
    });

    if (
      !semester ||
      !branch ||
      !year ||
      !subject ||
      !module ||
      !question ||
      !answer
    ) {
      return res
        .status(400)
        .json({ success: false, message: "All fields are required" });
    }

    const saveQuestion = await newQuestion.save();
    res.status(200).json({
      message: "Question added successfully",
      success: true,
      data: {
        question: saveQuestion,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

const getQuestionByYearAndSubject = async (req, res) => {
  try {
    const { year, subject } = req.query;
    const { branch, semester } = req.user;

    const questionLists = await Question.find({
      branch: branch,
      semester: semester,
      year: year,
      subject: subject,
    });

    res.status(200).json({
      message: "Questions by year & subject",
      success: true,
      data: {
        questions: questionLists,
      },
    });
  } catch (error) {
    res.status(500).json({
      message: "Internal server error",
      success: false,
    });
  }
};

const getQuestionBySubjectAndModule = async (req, res) => {
  try {
    const { module, subject } = req.query;
    const { branch, semester } = req.user;
    const questionLists = await Question.find({
      branch: branch,
      semester: semester,
      module: module,
      subject: subject,
    });
    res.status(200).json({
      message: "question by subject and module",
      success: true,
      data: {
        question: questionLists,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      error: "Internal server error",
      success: false,
    });
  }
};

const getQuestionByID = async (req, res) => {
  try {
    const { questionId } = req.query;

    // Ensure questionId is provided
    if (!questionId) {
      return res.status(400).json({
        message: "questionId is required",
        success: false,
      });
    }

    // Find the question by ID
    const question = await Question.findById(questionId);

    // Handle case where question is not found
    if (!question) {
      return res.status(404).json({
        message: "Question not found",
        success: false,
      });
    }

    // Return the found question
    res.status(200).json({
      message: "Question by ID",
      success: true,
      data: {
        question,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      message: "Internal server error",
      success: false,
    });
  }
};

module.exports = {
  createQuestion,
  getQuestionByYearAndSubject,
  getQuestionBySubjectAndModule,
  getQuestionByID,
};
