// sendEmails.js

const nodemailer = require("nodemailer");
const mongoose = require("mongoose");
require("dotenv").config();
const User = require("./model/User");

// Connect to MongoDB
mongoose
  .connect(process.env.MONGODB)
  .then(() => {
    console.log("MongoDB connected");
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err);
  });

// Create a transporter
const transporter = nodemailer.createTransport({
  host: "smtp.hostinger.com",
  port: 465,
  secure: true, // use TLS
  auth: {
    user: "rishu@acadsphere.in",
    pass: process.env.EMAIL_PASS,
  },
});

// Function to send emails
const sendEmailsToAllUsers = async () => {
  try {
    // Fetch all users from the database
    const users = await User.find();
    const googleFormLink =
      "https://docs.google.com/forms/d/e/1FAIpQLSdkrAIJJa_7dpGBPz_Itk1Zc8v_9ufZFjlt0YuzOrckxdJJ-Q/viewform?usp=sf_link";

    // Prepare and send emails
    const emailPromises = users.map((user) => {
      return transporter.sendMail({
        from: "rishu@acadsphere.in",
        to: user.email,
        bcc: "acadsphere@gmail.com",
        subject: "Important Message",
        text: `Hello!\n\nWe would love to hear your thoughts about Acadsphere. Please take a moment to fill out our feedback form: ${googleFormLink}\n\nThank you for your support!\n\nBest Regards,\nThe Acadsphere Team`,
      });
    });

    // Wait for all email promises to resolve
    await Promise.all(emailPromises);
    console.log("Emails sent successfully to all users!");
  } catch (error) {
    console.error("Error sending emails:", error);
  } finally {
    mongoose.connection.close(); // Close the database connection
  }
};

// Execute the function
sendEmailsToAllUsers();
