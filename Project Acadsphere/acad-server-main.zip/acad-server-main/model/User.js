const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const validator = require("validator");
const ImportantQuestion = require("./ImportantQuestion");

const UserSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      require: true,
      unique: true,
      validate: [validator.isEmail, "Please provide email"],
    },
    college: {
      type: String,
      require: true,
    },
    semester: {
      type: String,
      require: true,
    },
    branch: {
      type: String,
      require: true,
    },
    password: {
      type: String,
      require: true,
      minlength: 8,
      select: false,
    },
    passwordConfirm: {
      type: String,
      require: true,
      minlength: 8,
      select: false,
      validate: {
        validator: function (el) {
          return el === this.password;
        },
        message: "Password don't match ",
      },
    },

    isVerified: {
      type: Boolean,
      default: false,
    },
    otp: {
      type: Number,
    },

    role: {
      type: String,
      enum: ["user", "admin"],
      default: "user",
    },
    profileImage: {
      type: String,
      // required: true,
    },
    importantQues: [
      { type: mongoose.Schema.Types.ObjectId, ref: ImportantQuestion },
    ],
    subscription: {
      status: {
        type: String,
        enum: ["active", "inactive"],
        default: "inactive",
      },
      planId: {
        type: String,
      },
      razorpaySubscriptionId: {
        type: String,
      },
      validUntil: {
        type: Date,
      },
    },
  },

  {
    timestamps: true,
  }
);

module.exports = mongoose.model("User", UserSchema);
