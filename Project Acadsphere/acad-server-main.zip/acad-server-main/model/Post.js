const mongoose = require("mongoose");
const User = require("./User");

const CommentSchema = new mongoose.Schema({
  text: {
    type: String,
    required: true,
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: User,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: User }],
});

const PostSchema = new mongoose.Schema(
  {
    text: {
      type: String,
      required: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: User,
      required: true,
    },
    lastEditedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: User,
      default: null,
    },
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: User }],
    comments: [CommentSchema],
    sharedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: User }],
  },
  { timestamps: true }
);

module.exports = mongoose.model("Post", PostSchema);
