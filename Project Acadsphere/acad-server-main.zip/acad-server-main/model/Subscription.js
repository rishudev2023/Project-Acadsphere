const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const User = require("./User");

const subscriptionSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: User, required: true },
  amount: { type: Number, required: true },
  paymentId: { type: String, required: true }, // Razorpay payment ID
  subscriptionStart: { type: Date, default: Date.now },
  subscriptionEnd: { type: Date, required: true },
});

module.exports = mongoose.model("Subscription", subscriptionSchema);
