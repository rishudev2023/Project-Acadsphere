const mongoose = require("mongoose");
const ImportantQuestion = require("./ImportantQuestion");
const User = require("./User");

const QuestionSchema = new mongoose.Schema(
  {
    semester: {
      type: String,
      required: true,
    },
    branch: {
      type: String,
      required: true,
    },
    year: {
      type: String,
      required: true,
    },
    subject: {
      type: String,
      required: true,
    },
    module: {
      type: String,
      required: true,
    },
    question: {
      type: String,
      required: true,
    },
    answer: {
      type: String,
      required: true,
    },
    importantQues: [
      { type: mongoose.Schema.Types.ObjectId, ref: ImportantQuestion },
    ],
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: User,
      required: true,
    },
    lastEditedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: User,
      default: null,
    },
  },
  { timestamps: true }
);

// Creating indexes
QuestionSchema.index({ semester: 1, branch: 1, year: 1, subject: 1 }); // Compound index for faster lookups
QuestionSchema.index({ createdBy: 1 }); // Index for createdBy field
QuestionSchema.index({ lastEditedBy: 1 }); // Index for lastEditedBy field

module.exports = mongoose.model("Question", QuestionSchema);
