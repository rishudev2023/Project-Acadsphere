const mongoose = require("mongoose");

const ImportantQuesSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  question: { type: mongoose.Schema.Types.ObjectId, ref: "Question" },
});

module.exports = mongoose.model("ImportantQuestion", ImportantQuesSchema);
