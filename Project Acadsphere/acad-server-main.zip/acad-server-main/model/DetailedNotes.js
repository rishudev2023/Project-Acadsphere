const mongoose = require("mongoose");

const DetailedNotesSchema = new mongoose.Schema(
  {
    subject: {
      type: String,
      required: true,
    },
    module: {
      type: String,
      required: true,
    },
    topic: {
      type: String,
      required: true,
    },
    topicExplanation: {
      type: String,
      required: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("DetailedNotes", DetailedNotesSchema);
