const express = require("express");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const path = require("path");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const compression = require("compression");
const cors = require("cors");
const helmet = require("helmet");
const rateLimiter = require("./middleware/rateLimiter");
const csrfMiddleware = require("./middleware/csrfProtection");
const morgan = require("morgan");

const imageRoute = require("./routes/image");
const userRoute = require("./routes/user");
const statsRoute = require("./routes/dataStats");
const questionRoute = require("./routes/question");
const notesRoute = require("./routes/notes");
const feedbackRoute = require("./routes/feedback");
const importantQuesRoute = require("./routes/importantQuestion");
const updateQuestionRoute = require("./routes/updateQuestion");
const adminQuesRoute = require("./routes/adminQuestions");
const editProfileRoute = require("./routes/editProfile");
const reportQuestionRoute = require("./routes/reportQuestion");
const postRoute = require("./routes/postRoute");
const notificationRoute = require("./routes/notification");
const paymentRoute = require("./routes/payment");

const app = express();
// csrfMiddleware(app);
app.use(helmet());
app.use((req, res, next) => {
  const headers = req.headers;
  const ip = headers["x-real-ip"] || headers["x-forwarded-for"] || req.ip;
  if (ip) {
    req.ipAddress = ip;
  }
  next();
});
morgan.token("ipadd", function getIp(req) {
  return req.ipAddress || "unknown-ip";
});

app.use(
  morgan(":ipadd :method :url :response-time ms :status :res[content-length]")
);

app.get("/", (req, res) => {
  res.send("Hello World");
});

dotenv.config();

const corsOptions = {
  origin: "https://acadsphere.in",
  methods: ["GET", "HEAD", "PUT", "PATCH", "POST", "DELETE", "OPTIONS"],
  allowedHeaders: [
    "Content-Type",
    "Authorization",
    "X-Requested-With",
    "Accept",
  ],
};

app.use(cors(corsOptions));

const port = process.env.PORT || 8000;
app.use(cors());

app.use(compression());

const connect = async () => {
  try {
    await mongoose.connect(process.env.MONGODB);
    console.log("connected to MongoDB");
  } catch (error) {
    console.error("MongoDB connection error:", error);
    throw error;
  }
};

mongoose.connection.on("disconnected", () => {
  console.log("MongoDB disconnected");
});

mongoose.connection.on("connected", () => {
  console.log("MongoDB connected");
});

app.use(
  express.static(path.join(__dirname, "../acad-front/dist"), {
    setHeaders: (res, path) => {
      if (path.endsWith(".html")) {
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      } else {
        res.setHeader("Cache-Control", "public, max-age=31536000");
      }
    },
  })
);

app.use(express.static("public"));

const store = MongoStore.create({
  mongoUrl: process.env.MONGODB,
  crypto: {
    secret: process.env.SECRET,
  },
  touchAfter: 24 * 3600,
});

store.on("error", (err) => {
  console.error("Session store error:", err);
});

const sessionOptions = {
  store: store,
  secret: process.env.SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: {
    expires: Date.now() + 7 * 24 * 60 * 60 * 1000,
    maxAge: 7 * 24 * 60 * 60 * 1000,
    httpOnly: true,
  },
};

app.use(session(sessionOptions));
app.use(express.json({ limit: "3mb" }));
app.use(rateLimiter);
app.use("/api/v1/all", imageRoute);
app.use("/api/v1/user", userRoute);
app.use("/api/v1/user-stats", statsRoute);
app.use("/api/v1/pyqs", questionRoute);
app.use("/api/v1/notes", notesRoute);
app.use("/api/v1/feedback", feedbackRoute);
app.use("/api/v1/importantQues", importantQuesRoute);
app.use("/api/v1/updateQues", updateQuestionRoute);
app.use("/api/v1/admin", adminQuesRoute);
app.use("/api/v1/editProfileApi", editProfileRoute);
app.use("/api/v1/report", reportQuestionRoute);
app.use("/api/v1/community", postRoute);
app.use("/api/v1/notifications", notificationRoute);
app.use("/api/v1/payments", paymentRoute);

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../acad-front/dist/index.html"));
});

app.get("sitemap.xml", (req, res) => {
  res.sendFile(path.join(__dirname, "../acad-front/dist/sitemap.xml"));
});

app.listen(port, () => {
  connect();
  console.log(`Server listening on port ${port}`);
});
