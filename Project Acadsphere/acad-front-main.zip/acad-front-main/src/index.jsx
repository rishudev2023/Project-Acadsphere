import React from "react";
import ReactDOM from "react-dom";
import "./main";

ReactDOM.createRoot(document.getElementById("root")).render(<main />);
