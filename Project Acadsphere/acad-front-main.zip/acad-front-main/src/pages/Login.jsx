import React, { useState } from "react";
import logo from "../assets/images/logo.svg";
import { NavLink, Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { useUserContext } from "../../context/userContext";

const Login = () => {
  const { user } = useUserContext();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handlePasswordVisibilityToggle = () => {
    setShowPassword(!showPassword);
  };

  const handleOnSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); // Set loading state to true
    const from = e.target;
    const email = from.email.value;
    const password = from.password.value;
    const userData = { email, password };

    fetch(`https://acad-server-1.onrender.com/api/v1/user/login`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(userData),
    })
      .then((res) => res.json())
      .then((data) => {
        setLoading(false); // Set loading state to false
        if (data.success) {
          localStorage.setItem("token", data.data.token);
          toast.success(data.message);
          from.reset();
          if (user?.user?.role !== "admin") {
            navigate("/study-mode");
          } else {
            navigate("/");
          }
        } else {
          toast.error(data.message);
        }
      })
      .catch((error) => {
        setLoading(false);
        toast.error("Something went wrong. Please try again.");
      });
  };

  return (
    <div className="login">
      <div className="h-screen pt-[16vh]">
        <form
          action=""
          className="ease-in duration-300 w-[80%] sm:w-max shadow-sm backdrop-blur-md bg-white/80 lg:w-max mx-auto flex flex-col item-center rounded-md px-8 py-5"
          onSubmit={handleOnSubmit}
        >
          <NavLink to="/" className="flex mb-4 items-center justify-center">
            <img
              src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgdZPjmVZIjumxmsOsENuliphIkXFOykMdtYkfFJyZlkGiQmnab3nQPhKYEji9G28wORKLx5wzWirQq8Yc8mzOPq8bFsroyKe7Uv_9onP406X7VXtlw1R5oYhkErM-vphB_3Kw5vmwJ1hfcGYXOfzlN5DkqE-ZEG8k2RGK25mfjw5AC2pqKG3xRSI6siMY/s1600/logo.webp"
              alt="logo"
              className="logo h-14 w-14 cursor-pointer text-center"
            />
            <h1 className="text-[#191919] text-2xl font-mono">Acadsphere</h1>
          </NavLink>
          <div className="mb-4">
            <label htmlFor="email" className="block text-gray-700 text-sm mb-2">
              Email
            </label>
            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              className="shadow-sm bg-white appearance-none border rounded w-full py-2 px-3 sm:w-[20rem] text-gray-700 leading-tight focus:outline-none focusshadow-outline"
            />
          </div>
          <div className="mb-2">
            <label
              htmlFor="password"
              className="block text-gray-700 text-sm mb-2"
            >
              Password
            </label>
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              placeholder="**********"
              className="shadow-sm bg-white appearance-none border rounded w-full py-2 px-3 sm:w-[20rem] text-gray-700 leading-tight focus:outline-none focusshadow-outline"
            />
            <button
              type="button"
              className="fixed top-[13.3rem] right-10 text-gray-400 focus:outline-none"
              onClick={handlePasswordVisibilityToggle}
            >
              {showPassword ? <FaEyeSlash /> : <FaEye />}{" "}
            </button>
          </div>
          <Link
            to="/accounts/forgot-password"
            className="text-[#408EC6] text-left ml-[-0.85rem] font-semibold text-md w-full mb-3 px-4 rounded"
          >
            Forgot password?
          </Link>
          <button
            className="bg-[#1E2761] active:scale-90 transition duration-150 transform hover:shadow-xl shadow-md w-full rounded-full px-8 py-2 text-xl font-medium text-white mx-auto text-center"
            type="submit"
            disabled={loading} // Disable button when loading
          >
            {loading ? "Signing In..." : "Sign In"}
          </button>

          <div className=" text-center pt-7 text-sm">
            By Continue you agree to
            <Link to="/" className="text-[#1e2761]">
              {" "}
            </Link>
            Acadsphere's <br />
            <Link to="/privacy-policy" className="text-[#1e2761]">
              Privacy Policy
            </Link>{" "}
            and{" "}
            <Link to="/terms&conditions" className="text-[#1e2761]">
              Terms & Conditions
            </Link>
          </div>

          <ToastContainer />
        </form>
        <div className="flex justify-center items-center ease-in duration-300 w-full sm:w-max shadow-sm backdrop-blur-md  lg:w-max mx-auto rounded-md px-8 py-5 mt-5">
          <span>New to Acadsphere?</span>
          <Link
            to="/user/register"
            className="text-[#408EC6] text-center font-semibold py-2 px-4 rounded"
          >
            Register
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
