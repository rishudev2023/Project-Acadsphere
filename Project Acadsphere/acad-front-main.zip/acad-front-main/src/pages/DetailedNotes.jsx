import React, { useEffect, useState } from "react";
import axios from "axios";
import { MathJax, MathJaxContext } from "better-react-mathjax";
import Loading from "../components/Loading";

const DetailedNotes = () => {
  const [notes, setNotes] = useState();
  const [activeSubject, setActiveSubject] = useState("Maths");
  const [activeModule, setActiveModule] = useState("Module 1");
  const [modules, setModules] = useState([]);
  const [index, setIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  const module = [
    { id: 0, name: "Module 1", moduleValue: "Module 1" },
    { id: 1, name: "Module 2", moduleValue: "Module 2" },
    { id: 2, name: "Module 3", moduleValue: "Module 3" },
    { id: 3, name: "Module 4", moduleValue: "Module 4" },
    { id: 4, name: "Module 5", moduleValue: "Module 5" },
    { id: 5, name: "Module 6", moduleValue: "Module 6" },
    { id: 6, name: "Module 7", moduleValue: "Module 7" },
    { id: 7, name: "Module 8", moduleValue: "Module 8" },
    { id: 8, name: "Module 9", moduleValue: "Module 9" },
    { id: 9, name: "Module 10", moduleValue: "Module 10" },
  ];

  const subject = [
    { id: 0, name: "Maths", subjectValue: "Maths" },
    { id: 1, name: "PPS", subjectValue: "PPS" },
    { id: 2, name: "Chemistry", subjectValue: "Chemistry" },
    { id: 3, name: "Workshop", subjectValue: "Workshop" },
  ];

  useEffect(() => {
    fetchNotes(activeSubject, activeModule);
    const maxModule = {
      Maths: 4,
      PPS: 9,
      Chemistry: 6,
      Workshop: 0,
    }[activeSubject];
    setModules(module.filter((mod) => mod.id <= maxModule));
  }, [activeSubject, activeModule]);

  const handleSubjectClick = (subjectValue) => {
    setActiveSubject(subjectValue);
    setActiveModule("Module 1");
    const maxModule = {
      Maths: 4,
      PPS: 9,
      Chemistry: 6,
      Workshop: 0,
    }[subjectValue];
    setModules(module.filter((mod) => mod.id <= maxModule));
  };

  const handleModuleClick = (moduleValue) => {
    setActiveModule(moduleValue);
  };

  const fetchNotes = async (subjectValue, moduleValue) => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/notes/getNotesBySubjectAndModule?subject=${subjectValue}&module=${moduleValue}`
      );

      if (res.data.success) {
        setNotes(res.data.data.notes);
        setIndex(9);
      }
    } catch (error) {
      console.error("Error fetching notes:", error);
    } finally {
      setLoading(false);
    }
  };

  const mathJaxConfig = {
    loader: { load: ["[tex]/ams"] },
    tex: {
      packages: { "[+]": ["ams"] },
      inlineMath: [
        ["$", "$"],
        ["\\(", "\\)"],
      ],
      displayMath: [
        ["$$", "$$"],
        ["\\[", "\\]"],
      ],
      processEscapes: true,
      processEnvironments: true,
    },
  };

  return (
    <div className="pt-[16vh]">
      <div className="container mx-auto">
        <div className="mb-14 flex flex-col items-center">
          <div className="flex justify-center gap-4 mb-5">
            {subject?.map((subject) => (
              <button
                key={subject.id}
                className={`text-xl px-4 py-3 border-2 rounded-md font-medium ${
                  activeSubject === subject.name
                    ? "text-white bg-[#1E2761] border-[#1E2761]"
                    : "text-[#1E2761] bg-white"
                }`}
                onClick={() => handleSubjectClick(subject.name)}
              >
                {subject.name}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap justify-center gap-2 bg-[#1E2761] rounded-full p-2">
            {modules.map((module) => (
              <button
                key={module.id}
                className={`text-xl px-4 py-3 rounded-full font-medium ${
                  activeModule === module.name
                    ? "text-[#1E2761] bg-white"
                    : "text-white bg-[#1E2761]"
                }`}
                onClick={() => handleModuleClick(module.name)}
              >
                {module.name}
              </button>
            ))}
          </div>
        </div>
        <div>
          <div className="topic">
            {notes?.map((curElem) => (
              <div key={curElem.id}>
                <MathJaxContext config={mathJaxConfig}>
                  {/* <MathJax>{curElem.topic}</MathJax> */}
                </MathJaxContext>
              </div>
            ))}
          </div>
        </div>
      </div>
      {loading ? (
        <Loading />
      ) : (
        <div className="notes mx-4 mx-auto p-4 md:p-8 bg-white rounded-lg shadow-lg">
          <div>
            {notes?.slice(0, index).map((curElem, index) => (
              <div
                key={index}
                className="my-6 p-6 border border-[#1E2761] rounded-lg shadow-sm bg-[#B0E0E6]"
              >
                <div className="font-bold text-lg">Topic:</div>
                <MathJaxContext config={mathJaxConfig}>
                  <MathJax>{curElem.topic}</MathJax>
                </MathJaxContext>
                <div className="font-bold text-lg">Explanation:</div>
                <MathJaxContext config={mathJaxConfig}>
                  <MathJax>{curElem.topicExplanation}</MathJax>
                </MathJaxContext>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default DetailedNotes;
