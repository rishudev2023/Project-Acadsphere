import React, { useEffect, useState } from "react";
import axios from "axios";
import { useQuestionContext } from "../../context/questionContext";
import { MathJax, MathJaxContext } from "better-react-mathjax";
import Loading from "../components/Loading";
import { MdArrowBackIos } from "react-icons/md";
import { useSubjectContext } from "../../context/subjectsContext";
import { useUserContext } from "../../context/userContext";
import SpinLoading from "../components/SpinLoading";
import { useNavigate } from "react-router-dom";
import ReportModal from "../components/ReportModal";
import hljs from "highlight.js";
import c from "highlight.js/lib/languages/c";
import DisplayContent from "../components/DisplayContent";

// Then register the languages you need
hljs.registerLanguage("c", c);

const YearlyPYQs = () => {
  const navigate = useNavigate();
  const { user } = useUserContext();
  const { subjects } = useSubjectContext();
  const { Question, setQuestion } = useQuestionContext();

  const [activeSubject, setActiveSubject] = useState("");
  const [activeYear, setActiveYear] = useState("2023");
  const [index, setIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [noQuestions, setNoQuestions] = useState(false);
  const [importantQuestions, setImportantQuestions] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentQuestionId, setCurrentQuestionId] = useState(null);

  const openModal = (questionId) => {
    setCurrentQuestionId(questionId);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentQuestionId(null);
  };

  const year = [
    { id: 0, name: "2023", yearValue: "2023" },
    { id: 1, name: "2022", yearValue: "2022" },
    { id: 2, name: "2021", yearValue: "2021" },
    { id: 3, name: "2020", yearValue: "2020" },
    { id: 4, name: "2019", yearValue: "2019" },
    { id: 5, name: "2018", yearValue: "2018" },
  ];

  useEffect(() => {
    if (user) {
      const semesterSubjects = subjects[user?.user?.semester];
      const semAndBranchWiseSubject = semesterSubjects[user?.user?.branch];
      setActiveSubject(semAndBranchWiseSubject[0].name);
    }
  }, [user]);

  useEffect(() => {
    if (activeSubject) {
      fetchQuestions(activeSubject, activeYear);
    }
  }, [activeSubject, activeYear]);

  useEffect(() => {
    if (activeSubject) {
      const userId = user?.user._id;
      fetchImportantQuestions(userId, activeSubject);
    }
  }, [activeSubject]);

  const handleSubjectClick = (subjectValue) => {
    setActiveSubject(subjectValue);
    setActiveYear("2023");
    setLoading(true);
  };

  const handleYearClick = (yearValue) => {
    setActiveYear(yearValue);
    setLoading(true);
    if (window.innerWidth < 768) {
      setSidebarCollapsed(true);
    }
  };

  const fetchImportantQuestions = async (userId, subjectValue) => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/importantQues/getImpQues?userId=${userId}&subject=${subjectValue}`
      );
      if (res.data.success) {
        setImportantQuestions(res.data.data);
      }
    } catch (error) {
      console.error("Error fetching important questions", error);
    }
  };

  const handleStarClick = async (questionId) => {
    try {
      const userId = user?.user?._id;
      const isImportant = importantQuestions.some((q) => q._id === questionId);

      if (isImportant) {
        // Remove from importantQues
        await fetch(
          `https://acad-server-1.onrender.com/api/v1/importantQues/removeImpQues`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ userId, questionId }),
          }
        );
        setImportantQuestions((prev) =>
          prev.filter((q) => q._id !== questionId)
        );
      } else {
        // Add to importantQues
        await fetch(
          `https://acad-server-1.onrender.com/api/v1/importantQues/addImpQues`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ userId, questionId }),
          }
        );
        setImportantQuestions((prev) => [...prev, { _id: questionId }]);
      }
    } catch (error) {
      console.error("Error updating important questions", error);
    }
  };

  const fetchQuestions = async (subjectValue, yearValue) => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/pyqs/getQuestionByYear&Subject?year=${yearValue}&subject=${subjectValue}`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data.success) {
        const questions = res.data.data.questions;
        setQuestion(questions);
        setIndex(50);
        setNoQuestions(questions.length === 0); // Set noQuestions state based on the fetched questions
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  const mathJaxConfig = {
    loader: { load: ["[tex]/ams"] },
    tex: {
      packages: { "[+]": ["ams"] },
      inlineMath: [
        ["$", "$"],
        ["\\(", "\\)"],
      ],
      displayMath: [
        ["$$", "$$"],
        ["\\[", "\\]"],
      ],
      processEscapes: true,
      processEnvironments: true,
    },
  };

  function preprocessTextForMathJax(inputText) {
    // Replace text between ** with a span element for highlighting
    return inputText.replace(
      /\*\*(.*?)\*\*/g,
      '<span class="highlighted">$1</span>'
    );
  }

  if (!user) {
    return (
      <div className="pt-[16vh] h-screen">
        <div className="mt-[4rem]">
          <SpinLoading />
        </div>
        <div className="text-3xl font-bold text-[#1E2761] text-center">
          Loading Questions...
        </div>
      </div>
    );
  }

  const allowedEmails = [
    "rishugren03@gmail.com",
    "tdbnewschampbth@gmail.com",
    "rishukumardps11a@gmail.com",
    "ristartup02@gmail.com",
  ];

  return (
    <div className="flex pt-[10vh]">
      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-screen bg-gray-200 p-4 overflow-y-auto pt-[14vh] transform transition-transform ease-in-out duration-0 ${
          sidebarCollapsed
            ? "-translate-x-full md:-translate-x-0 w-full md:w-1/5"
            : "w-full md:w-1/5"
        }`}
      >
        <h2 className="text-lg font-bold mb-4">Subjects</h2>
        <ul>
          {subjects[user?.user?.semester][user?.user?.branch].map((subject) => (
            <li key={subject.id} className="mb-2">
              <button
                className={`text-[#1E2761] font-medium hover:text-white hover:bg-[#1E2761] py-2 px-4 rounded-md w-full transition duration-0 ${
                  activeSubject === subject.name && "bg-[#1E2761] text-white"
                }`}
                onClick={() => handleSubjectClick(subject.name)}
              >
                {subject.name}
              </button>
            </li>
          ))}
        </ul>
        <h2 className="text-lg font-bold mb-4 mt-8">Years</h2>
        <ul>
          {year.map((year) => (
            <li key={year.id} className="mb-2">
              <button
                className={`text-[#1E2761] font-medium hover:text-white hover:bg-[#1E2761] py-2 px-4 rounded-md w-full transition duration-300 ${
                  activeYear === year.name && "bg-[#1E2761] text-white"
                }`}
                onClick={() => handleYearClick(year.name)}
              >
                {year.name}
              </button>
            </li>
          ))}
        </ul>
      </div>
      {/* Content */}
      <div
        className={`transition-all duration-300 w-full md:w-4/5 p-4 ml-auto ${
          sidebarCollapsed ? "" : "hidden md:block"
        }`}
      >
        <button
          className="fixed block left-[-0.5rem] bg-[#1E2761] py-3 px-[0.32rem] rounded-full shadow-lg md:hidden"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
        >
          <MdArrowBackIos
            className={`text-white ${sidebarCollapsed ? "rotate-180" : ""}`}
          />
        </button>
        <div className="notes rounded-lg shadow-lg">
          {loading ? (
            <Loading />
          ) : noQuestions ? (
            <div className="text-center text-xl h-screen text-[#1E2761] font-bold">
              No questions found for {activeSubject} in {activeYear}.
            </div>
          ) : (
            <MathJaxContext config={mathJaxConfig}>
              <div>
                {Question?.slice(0, index).map((curElem, index) => (
                  <div
                    key={index}
                    className="relative my-6 p-6 border border-[#1E2761] rounded-lg shadow-sm bg-[#B0E0E6]"
                  >
                    {allowedEmails.includes(user?.user?.email) && (
                      <button
                        className="absolute right-20 bg-[#1E2761] border rounded-md text-white h-10 w-20"
                        onClick={() => {
                          navigate(`/questions/${curElem?._id}/edit`);
                        }}
                      >
                        Edit
                      </button>
                    )}
                    <button
                      className="tooltip text-[#1E2761] text-3xl absolute right-10"
                      onClick={() => handleStarClick(curElem._id)}
                    >
                      {importantQuestions.some((q) => q._id === curElem._id)
                        ? "★"
                        : "☆"}
                      {importantQuestions.some((q) => q._id === curElem._id) ? (
                        <span className="tooltiptext bg-[#7A2048] text-white text-sm">
                          unmark as important
                        </span>
                      ) : (
                        <span className="tooltiptext bg-[#7A2048] text-white text-sm">
                          mark important
                        </span>
                      )}
                    </button>
                    <MathJax
                      dynamic
                      className={`${
                        activeSubject === "Chemistry" || "PPS"
                          ? "whitespace-pre-wrap"
                          : "whitespace-pre-wrap"
                      }`}
                    >
                      <div className="font-bold text-xl mb-2 text-[#1E2761]">
                        Question:
                      </div>
                      {activeSubject === "PPS" ? (
                        <pre>
                          <code className="language-c">
                            {" "}
                            <div className="text-md md:text-lg overflow-x-auto">
                              <DisplayContent htmlContent={curElem.question} />
                            </div>
                          </code>
                        </pre>
                      ) : (
                        <div className="text-md md:text-lg overflow-x-auto">
                          <DisplayContent htmlContent={curElem.question} />
                        </div>
                      )}
                    </MathJax>
                    &nbsp; &nbsp;
                    <MathJax
                      dynamic
                      className={`${
                        activeSubject === "Chemistry" || "PPS"
                          ? "whitespace-pre-wrap"
                          : "whitespace-pre-wrap"
                      }`}
                    >
                      <div className="font-bold text-xl mb-2 text-[#1E2761]">
                        Solution:
                      </div>
                      {activeSubject === "PPS" ? (
                        <pre>
                          <code className="language-c">
                            <div className="text-md md:text-lg overflow-x-auto ">
                              <DisplayContent htmlContent={curElem.answer} />
                            </div>
                          </code>
                        </pre>
                      ) : (
                        <div className="text-md md:text-lg overflow-x-auto ">
                          <DisplayContent htmlContent={curElem.answer} />
                        </div>
                      )}
                    </MathJax>
                    <button
                      onClick={() => openModal(curElem._id)}
                      className="mt-4 bg-red-600 text-white px-4 py-2 rounded"
                    >
                      Report
                    </button>
                  </div>
                ))}
              </div>
            </MathJaxContext>
          )}
        </div>
      </div>
      {isModalOpen && (
        <ReportModal
          isOpen={isModalOpen}
          onRequestClose={closeModal}
          questionId={currentQuestionId}
          userId={user?.user._id}
        />
      )}
    </div>
  );
};

export default YearlyPYQs;
