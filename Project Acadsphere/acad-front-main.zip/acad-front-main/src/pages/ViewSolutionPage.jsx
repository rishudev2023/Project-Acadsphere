import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { MathJax, MathJaxContext } from "better-react-mathjax";
import Loading from "../components/Loading";
import { useUserContext } from "../../context/userContext";
import { useNavigate } from "react-router-dom";
import DisplayContent from "../components/DisplayContent";

const ViewSolutionPage = () => {
  const navigate = useNavigate();
  const { user } = useUserContext();
  const { questionId } = useParams();
  const [loading, setLoading] = useState(true);
  const [questionData, setQuestionData] = useState(null);

  const fetchQuestion = async (questionId) => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/pyqs/getQuestionByID?questionId=${questionId}`
      );
      if (res.data.success) {
        setQuestionData(res.data.data.question);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (questionId) {
      fetchQuestion(questionId);
    }
  }, [questionId]);

  const mathJaxConfig = {
    loader: { load: ["[tex]/ams"] },
    tex: {
      packages: { "[+]": ["ams"] },
      inlineMath: [
        ["$", "$"],
        ["\\(", "\\)"],
      ],
      displayMath: [
        ["$$", "$$"],
        ["\\[", "\\]"],
      ],
      processEscapes: true,
      processEnvironments: true,
    },
  };

  if (loading) {
    return <Loading />;
  }

  if (!questionData) {
    return <div>Question not found.</div>;
  }

  const allowedEmails = [
    "rishugren03@gmail.com",
    "tdbnewschampbth@gmail.com",
    "rishukumardps11a@gmail.com",
    "ristartup02@gmail.com",
  ];

  return (
    <MathJaxContext config={mathJaxConfig}>
      <div className="relative my-6 p-6 rounded-lg shadow-sm pt-[12vh]">
        <div
          key={questionId}
          className="relative my-6 p-6 border border-[#1E2761] rounded-lg shadow-sm bg-[#B0E0E6]"
        >
          {allowedEmails.includes(user?.user?.email) && (
            <button
              className="absolute right-10 bg-[#1E2761] border rounded-md text-white h-10 w-20"
              onClick={() => {
                navigate(`/questions/${questionData._id}/edit`);
              }}
            >
              Edit
            </button>
          )}
          <MathJax dynamic className="whitespace-pre-wrap">
            <div className="font-bold text-xl mb-2 text-[#1E2761]">
              Question:
            </div>
            <div className="text-md md:text-lg">
              <DisplayContent htmlContent={questionData.question} />
            </div>
          </MathJax>
          &nbsp; &nbsp;
          <MathJax dynamic className="whitespace-pre-wrap">
            <div className="font-bold text-xl mb-2 text-[#1E2761]">
              Solution:
            </div>
            <div className="text-md md:text-lg">
              <DisplayContent htmlContent={questionData.answer} />
            </div>
          </MathJax>
        </div>
      </div>
    </MathJaxContext>
  );
};

export default ViewSolutionPage;
