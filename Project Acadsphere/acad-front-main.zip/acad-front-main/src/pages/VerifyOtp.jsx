import React, { useState, useRef } from "react";
import { useUserContext } from "../../context/userContext";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const VerifyOtp = () => {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const { user } = useUserContext();
  const navigate = useNavigate();
  const inputRefs = useRef([]);

  const handleInputChange = (index, value) => {
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Move focus to the next input field
    if (value !== "" && index < otp.length - 1) {
      inputRefs.current[index + 1].focus();
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === "Backspace" && otp[index] === "") {
      if (index > 0) {
        inputRefs.current[index - 1].focus();
      }
    }
  };

  const handleOnSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const email = user?.user?.email;
    const combineOtp = parseInt(otp.join(""));
    const dataOtp = { email, combineOtp };

    fetch(`https://acad-server-1.onrender.com/api/v1/user/verify-otp`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(dataOtp),
    })
      .then((res) => res.json())
      .then((data) => {
        setLoading(false);
        if (data.success) {
          toast.success(data.message);
          navigate("/");
          location.reload();
        } else {
          toast.error(data.message);
        }
      })
      .catch((error) => {
        setLoading(false);
        console.error("Error:", error);
      });
  };

  return (
    <div className="relative pt-[10vh] flex min-h-screen flex-col justify-center overflow-hidden py-8 px-4 sm:px-6 lg:px-8">
      <div className="relative bg-white px-6 py-8 shadow-xl mx-auto w-full max-w-xs sm:max-w-sm lg:max-w-md rounded-lg">
        <div className="flex flex-col space-y-8">
          <div className="text-center">
            <h2 className="text-2xl font-semibold text-gray-900 sm:text-3xl">
              Email Verification
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              A verification email has been sent to your registered email.
            </p>
          </div>

          <div>
            <form onSubmit={handleOnSubmit}>
              <div className="flex justify-center space-x-2">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    type="text"
                    value={digit}
                    maxLength="1"
                    onChange={(e) => handleInputChange(index, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    className="w-10 h-10 sm:w-12 sm:h-12 text-center border border-gray-300 rounded-md text-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    ref={(el) => (inputRefs.current[index] = el)}
                  />
                ))}
              </div>

              <div className="mt-6">
                <button
                  className="w-full py-2 px-4 bg-red-600 hover:bg-red-700 text-white text-lg rounded-md transition duration-200"
                  disabled={loading}
                >
                  {loading ? "Verifying..." : "Verify Account"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default VerifyOtp;
