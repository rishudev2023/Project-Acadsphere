import React, { useState } from "react";
import { FaCheckCircle } from "react-icons/fa";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { useUserContext } from "../../context/userContext";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const SubscriptionPage = () => {
  const { user, setUser } = useUserContext();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [error, setError] = useState("");

  const benefits = {
    premium: [
      "Yearwise PYQs with detailed solution",
      "Chapterwise PYQs with detailed solution",
      "Bookmark Important Questions",
    ],
  };

  const initiatePayment = async () => {
    setLoading(true);
    try {
      const response = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/payments/initiate`,
        {
          userId: user?.user._id,
          amount: 25, // Amount in rupees
        }
      );
      const { orderId } = response.data;
      setOrderId(orderId);
      handleRazorpayPayment(orderId);
    } catch (error) {
      console.error("Failed to initiate payment:", error);
      if (error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        console.error("Response data:", error.response.data);
        console.error("Response status:", error.response.status);
        console.error("Response headers:", error.response.headers);
        setError(
          `Failed to initiate payment: ${
            error.response.data.message || error.response.status
          }`
        );
      } else if (error.request) {
        // The request was made but no response was received
        console.error("Request data:", error.request);
        setError("Failed to initiate payment: No response from server");
      } else {
        // Something happened in setting up the request that triggered an Error
        console.error("Error message:", error.message);
        setError(`Failed to initiate payment: ${error.message}`);
      }
      setLoading(false);
    }
  };

  const handleRazorpayPayment = (orderId) => {
    const options = {
      key: "rzp_live_IdaNSwizx98ef9", // Razorpay key ID
      amount: 25 * 100, // Amount in paisa
      currency: "INR",
      name: "Acadsphere",
      description: "Premium Plan Subscription",
      order_id: orderId,
      handler: async function (response) {
        const { razorpay_payment_id, razorpay_order_id, razorpay_signature } =
          response;
        console.log(response);
        await capturePayment(
          razorpay_payment_id,
          razorpay_order_id,
          razorpay_signature
        );
      },
      prefill: {
        name: user?.user.name,
        email: user?.user.email,
        contact: "",
      },
      notes: {
        address: "BCE Patna",
      },
      theme: {
        color: "#1E2761",
      },
    };

    const rzp = new window.Razorpay(options);
    rzp.open();
    rzp.on("payment.failed", function (response) {
      console.error(response.error);

      setError("Payment failed");
      toast.error("Payment failed!");
      setLoading(false);
    });
  };

  const capturePayment = async (paymentId, orderId, signature) => {
    try {
      const response = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/payments/success`,
        {
          razorpay_payment_id: paymentId,
          razorpay_order_id: orderId,
          razorpay_signature: signature,
        }
      );
      console.log("Payment captured successfully:", response.data);
      toast.success("Payment successful");
      setPaymentSuccess(true);
      setLoading(false);
      navigate("/study-mode");
      window.location.reload();
    } catch (error) {
      console.error("Failed to capture payment:", error);
      setError("Failed to capture payment");
      setLoading(false);
    }
  };

  return (
    <div className="pt-[13vh] flex flex-col items-center justify-center min-h-screen">
      {user?.user.subscription?.status === "active" ? (
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-4">
            You are already subscribed!
          </h2>
          <Link
            to="/study-mode"
            className="text-center bg-[#1E2761] text-white p-3 border rounded-lg"
          >
            Go to Study Mode
          </Link>
        </div>
      ) : (
        <div className="flex flex-col sm:flex-row gap-8">
          <div className="bg-white/80 p-8 rounded-lg shadow-md w-full sm:w-auto">
            <h2 className="text-lg font-semibold mb-4">Subscribe to Premium</h2>
            <h1 className="text-3xl font-semibold mb-4">
              ₹25<span className="font-[600]">/month</span>
            </h1>
            <ul>
              {/* Assuming `benefits.premium` is defined */}
              {benefits.premium.map((benefit, index) => (
                <li key={index} className="flex gap-2 items-center">
                  <FaCheckCircle /> {benefit}
                </li>
              ))}
            </ul>

            <div className="mt-4">
              <hr />
              By continuing you agree to our{" "}
              <span
                className="text-blue-500 cursor-pointer"
                onClick={() => {
                  navigate("/subscription-policy");
                }}
              >
                subscription policy
              </span>
            </div>
            {paymentSuccess ? (
              <p className="text-green-500 mb-2">Payment successful!</p>
            ) : (
              <button
                className={`mt-4 bg-[#1E2761] active:scale-90 transition duration-500 transform hover:shadow-xl shadow-md rounded-md px-4 py-2 text-md font-medium text-white ${
                  loading && "opacity-50 cursor-not-allowed"
                }`}
                onClick={initiatePayment}
                disabled={loading}
              >
                {loading ? "Loading..." : "Subscribe"}
              </button>
            )}
            {error && <p className="text-red-500 mt-2">{error}</p>}
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionPage;
