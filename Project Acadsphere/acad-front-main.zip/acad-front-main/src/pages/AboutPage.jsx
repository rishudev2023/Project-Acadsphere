import React from "react";

const AboutPage = () => {
  return (
    <div className="pt-[16vh] container mx-auto py-8 px-4 text-lg">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden p-5">
        <div className="px-6 py-4 ">
          <h2 className="text-2xl font-semibold m-4 text-center">
            About Acadsphere
          </h2>
          <p className="text-gray-700 leading-relaxed">
            Acadsphere is a pioneering EdTech platform dedicated to meeting the
            educational needs of students at Bihar Engineering University. Our
            platform aims to provide comprehensive study materials and solutions
            to previous years' question papers (PYQs), addressing a crucial gap
            in online educational resources available to students.
          </p>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">Our Mission:</h3>
            <p className="text-gray-700 leading-relaxed">
              Our mission at Acadsphere is to empower students by providing them
              with high-quality study materials and solutions to PYQs, thus
              enabling them to excel in their academic endeavors. We are
              committed to supporting the educational journey of Bihar
              Engineering University students and facilitating their success.
            </p>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">Current Services:</h3>
            <p className="text-gray-700 leading-relaxed">
              In our testing phase, we are currently offering comprehensive
              study materials and PYQ solutions first semester. We aim to expand
              our services based on the feedback and interests of students, with
              plans to cover all branches and semesters of Bihar Engineering
              University in the future.
            </p>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">Future Features:</h3>
            <p className="text-gray-700 leading-relaxed">
              In the near future, Acadsphere will introduce additional features
              to enhance the learning experience of students at Bihar
              Engineering University. These features include video lectures, a
              discussion forum for students from different colleges within Bihar
              Engineering University, and other innovative features tailored to
              the specific needs of students across all branches.
            </p>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              Meet Our Team: BCE PATNA
            </h3>
            <div className="flex flex-wrap gap-4">
              <div>RJ Aman</div>
              <div>Utkarsh Kumar</div>
              <div>Nikita Rani</div>
              <div>Aman Kumar</div>
              <div>Golden Kumar</div>
              <div>Anmol Pandey</div>
              <div>Alok Kumar</div>
              <div>Priya </div>
              <div>Rishu Kumar</div>
            </div>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              Join Us on Our Journey:
            </h3>
            <p className="text-gray-700 leading-relaxed">
              We invite students of Bihar Engineering University to join us on
              this journey towards academic excellence. You are welcome if you
              want to join us even as a team member. Explore Acadsphere, access
              our study materials, and provide us with your valuable feedback to
              help us improve and expand our services.
            </p>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">Contact Us:</h3>
            <p className="text-gray-700 leading-relaxed">
              If you have any questions or suggestions, please feel free to
              reach out to us at{" "}
              <a href="mailto:acadsphere@gmail.com">
                acadsphere@gmail.com or text us on LinkedIn.
              </a>
            </p>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-4">Operational Address</h3>
            <p className="text-gray-700 leading-relaxed">
              Boy's Hostel-2, Bakhtiyarpur College of Engineering, Patna -
              803212, Bihar India.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
