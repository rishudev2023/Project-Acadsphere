import React, { useEffect, useState } from "react";
import { useUserContext } from "../../context/userContext";
import { Navigate } from "react-router-dom";
import axios from "axios";
import SpinLoading from "../components/SpinLoading";

export default function ProtectedSubscriptionRoute({ children }) {
  const { user, setUser } = useUserContext();
  const [loading, setLoading] = useState(true);
  const [hasActiveSubscription, setHasActiveSubscription] = useState(null);

  const FORTY_EIGHT_HOURS_IN_MS = 48 * 60 * 60 * 1000; // 48 hours in milliseconds

  const getUserSubscriptionStatus = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      setHasActiveSubscription("inactive");
      setLoading(false);
      return;
    }

    try {
      const res = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/user/get-user`,
        { token },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (res.data.success) {
        const userData = res.data.data.user;
        setUser(userData);

        // Calculate the time since registration
        const registrationDate = new Date(userData.createdAt); // Assuming createdAt is the registration date
        const currentDate = new Date();
        const timeSinceRegistration = currentDate - registrationDate;

        // Apply subscription check if user has completed 48 hours
        if (timeSinceRegistration >= FORTY_EIGHT_HOURS_IN_MS) {
          if (userData.semester === 2) {
            setHasActiveSubscription(userData.subscription.status);
          } else {
            // If the user is not in the 2nd semester, allow access without subscription check
            setHasActiveSubscription("active");
          }
        } else {
          // If the user hasn't completed 48 hours, allow access
          setHasActiveSubscription("active");
        }
      } else {
        setHasActiveSubscription("inactive");
        localStorage.clear();
      }
    } catch (error) {
      console.error("Error fetching subscription status:", error);
      setHasActiveSubscription("inactive");
      localStorage.clear();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user) {
      getUserSubscriptionStatus();
    } else {
      // Calculate the time since registration
      const registrationDate = new Date(user?.user?.createdAt);
      const currentDate = new Date();
      const timeSinceRegistration = currentDate - registrationDate;

      // Apply subscription check if user has completed 48 hours
      if (timeSinceRegistration >= FORTY_EIGHT_HOURS_IN_MS) {
        if (user?.user?.semester === "Second") {
          setHasActiveSubscription(
            user?.user?.subscription?.status || "inactive"
          );
        } else {
          setHasActiveSubscription("active");
        }
      } else {
        setHasActiveSubscription("active");
      }
      setLoading(false);
    }
  }, [user]);

  if (loading) {
    return (
      <div className="pt-[16vh] h-screen">
        <div className="mt-[4rem]">
          <SpinLoading />
        </div>
        <div className="text-3xl font-bold text-[#1E2761] text-center">
          Loading Questions...
        </div>
      </div>
    );
  }

  if (hasActiveSubscription === "active") {
    return children;
  }

  if (hasActiveSubscription === "inactive") {
    return <Navigate to="/subscription-premium" />;
  }

  return <Navigate to="/login" />;
}
