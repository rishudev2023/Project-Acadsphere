import React from "react";
import { Link } from "react-router-dom";

function NotFoundPage() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-[#1E2761] text-white">
      <div className="bg-[#408EC6] p-8 rounded-lg shadow-lg text-center">
        <h1 className="text-4xl mb-4">404 - Page Not Found</h1>
        <p className="text-3xl mb-8">OOPS!</p>
        <Link
          to="/"
          className="text-lg font-bold text-white hover:text-purple-800 transition-colors"
        >
          Go to Home
        </Link>
      </div>
    </div>
  );
}

export default NotFoundPage;
