import React, { useState } from "react";
import avatar from "../assets/images/avatar.jpg";
import { Link, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import { FaEye, FaEyeSlash } from "react-icons/fa";

const Register = () => {
  const [image, setImage] = useState({});
  const [uploading, setUploading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handlePasswordVisibilityToggle = () => {
    setShowPassword(!showPassword);
  };

  const handleImage = async (e) => {
    const file = e.target.files[0];
    let formData = new FormData();
    formData.append("image", file);
    setUploading(true);
    try {
      const { data } = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/all/upload-image`,
        formData
      );
      setImage({
        url: data.url,
        public_id: data.public_id,
      });
      setUploading(false);
      toast.success("Profile image uploaded.");
    } catch (error) {
      console.log(error);
      setUploading(false);
      toast.error("Image upload failed.");
    }
  };

  const handleOnSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const form = e.target;
    const name = form.name.value;
    const email = form.email.value;
    const college = form.college.value;
    const semester = form.semester.value;
    const branch = form.branch.value;
    const password = form.password.value;
    const passwordConfirm = form.confirmPassword.value;
    const profileImage = image?.url;
    const userData = {
      name,
      email,
      college,
      semester,
      branch,
      password,
      passwordConfirm,
      profileImage,
    };

    if (!name || !email || !college || !semester || !branch) {
      toast.error("All fields are required!");
      form.reset();
      setLoading(false);
      return;
    }

    if (semester === "select semester" || branch === "select branch") {
      toast.error("Either semester or branch is not selected!");
      form.reset();
      setLoading(false);
      return;
    }

    try {
      const response = await fetch(
        `https://acad-server-1.onrender.com/api/v1/user/register`,
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
          },
          body: JSON.stringify(userData),
        }
      );
      const data = await response.json();
      if (data.success) {
        localStorage.setItem("token", data.data.token);
        toast.success(data.message);
        form.reset();
        navigate("/accounts/verifyOtp");
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error("Registration failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="register">
      <div className="w-full mx-auto pt-[16vh]">
        <form
          action=""
          className="ease-in duration-300 w-[80%] sm:w-max shadow-sm backdrop-blur-md bg-white/80 lg:w-max mx-auto rounded-md px-6 py-5 mb-10"
          onSubmit={handleOnSubmit}
        >
          <label htmlFor="file-upload" className="custom-file-upload">
            <img
              src={
                image?.url ||
                "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEij_QwxFJUVyCwcPaECXCGiR7sLfuLj7xgfbujN_SRYUh6_ff4Qdst8mRlUsL8Ksd8CgKRDeGCEALDtxD_2OecpXyPSKs86_adG3a-T0SmdZ9tI12usAvmnnG6rLkOwWFlvsqD-_eQJunkzGSdwTXVkRKj0OGte8gLpTiD6Wv7lSmOu843JTCtTy-I-dHU/s320/de6e8d53598eecfb6a2d86919b267791.jpg"
              }
              alt=""
              className="h-32 w-32 bg-contain rounded-full mx-auto cursor-pointer"
            />
          </label>
          <label className="block text-center text-gray-900 text-base mb-2">
            Profile Picture
          </label>
          <input
            type="file"
            label="Image"
            name="myFile"
            id="file-upload"
            className="hidden"
            accept=".jpeg, .png, .jpg"
            onChange={handleImage}
          />

          <div className="mb-3">
            <label htmlFor="name" className="block text-gray-700 text-sm mb-2">
              Name
            </label>
            <input
              type="name"
              name="name"
              placeholder="Enter your Name"
              className="shadow-sm bg-white appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focusshadow-outline"
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="block text-gray-700 text-sm mb-2">
              Email
            </label>
            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              className="shadow-sm bg-white appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focusshadow-outline"
              required
            />
          </div>
          <div className="mb-3">
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
              name="college"
            >
              <option selected disabled>
                select college
              </option>

              <option> BHAGALPUR COLLEGE OF ENGINEERING, BHAGALPUR</option>
              <option>GAYA COLLEGE OF ENGINEERING, GAYA</option>
              <option>DARBHANGA COLLEGE OF ENGINEERING, DARBHANGA</option>
              <option>MOTIHARI COLLEGE OF ENGINEERING, MOTIHARI</option>
              <option>
                LOK NAYAK JAI PRAKASH INSTITUTE OF TECHNOLOGY, CHAPRA
              </option>
              <option>SERSHAH ENGINEERING COLLEGE, SASARAM, ROHTAS</option>
              <option>
                RASHTRAKAVI RAMDHARI SINGH DINKAR COLLEGE OF ENGINEERING,
                BEGUSARAI
              </option>
              <option>SUPAUL COLLEGE OF ENGINEERING, SUPAUL</option>
              <option>BAKHTIYARPUR COLLEGE OF ENGINEERING, PATNA</option>
              <option>SITAMARHI INSTITUTE OF TECHNOLOGY, SITAMARHI</option>
              <option> PURNEA COLLEGE OF ENGINEERING, PURNEA</option>
              <option>B. P. MANDAL COLLEGE OF ENGINEERING, MADHEPURA</option>
              <option>KATIHAR ENGINEERING COLLEGE, KATIHAR</option>
              <option>SAHARSA COLLEGE OF ENGINEERING, SAHARSA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, JAMUI</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, BANKA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, VAISHALI</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, NAWADA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, KISHANGANJ</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, MUNGER</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, SHEOHAR</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, WEST CHAMPARAN</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, AURANGABAD</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, KAIMUR</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, GOPALGANJ</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, MADHUBANI</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, SIWAN</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, JEHANABAD</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, ARWAL</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, KHAGARIA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, BUXAR</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, BHOJPUR</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, SHEIKHPURA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, LAKHISARAI</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, SAMASTIPUR</option>
              <option> MUZAFFARPUR INSTITUTE OF TECHNOLOGY, MUZAFFARPUR</option>
              <option>
                Shri Phanishwar Nath Renu Engineering College, Araria
              </option>
              <option>VIDYA VIHAR INSTITUTE OF TECHNOLOGY,PURNIA</option>
              <option>NETAJI SUBHAS INSTITUTE OF TECHNOLOGY,BIHTA</option>
              <option> SITYOG INSTITUTE OF TECHNOLOGY,AURANGABAD</option>
              <option>AZMET INSTITUTE OF TECHNOLOGY,KISHENGANJ</option>
              <option>ADWAITA MISSION INSTITUTE OF TECHNOLOGY,BANKA</option>
              <option> MOTI BABU INSTITUTE OF TECHNOLOGY,FORBISGANJ</option>
              <option>EXALT COLLEGE OF ENGG. & TECHNOLOGY,VAISHALI</option>
              <option>MOTHERS INSTITUTE OF TECHNOLOGY,BIHTA</option>
              <option> R.P. SHARMA INSTITUTE OF TECHNOLOGY, PATNA</option>
              <option>
                MAULANA AZAD COLLEGE OF ENGINEERING &
                TECHNOLOGY,NEORAGANJ,NEORA,PATNA
              </option>
              <option> NALANDA COLLEGE OF ENGINEERING, CHANDI</option>
              <option>
                Millia Kishanganj College of Engineering & Technology,
                Kishanganj
              </option>
              <option> Millia Institute of Technology, Purnia</option>
              <option> Prabhu Kailash Engineering College, Aurangabad</option>
              <option>
                Siwan College of Engineering and Management, Siwan
              </option>
            </select>
          </div>
          <div className="flex items-center gap-8">
            <div className="mb-3">
              <select
                className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
                name="semester"
              >
                <option>select semester</option>
                <option>First</option>
                <option>Second</option>
                <option>Third</option>
                <option>Fourth</option>
                <option>Fifth</option>
                <option>Sixth</option>
                <option>Seventh</option>
                <option>Eighth</option>
              </select>
            </div>
            <div className="mb-3">
              <select
                className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
                name="branch"
              >
                <option>select branch</option>
                <option>CSE</option>
                <option>EEE</option>
                <option>CIVIL</option>
                <option>MECH</option>
                <option>ELECTRICAL</option>
                <option>ECE</option>
                <option>IE</option>
                <option>FT</option>
              </select>
            </div>
          </div>
          <div className="flex flex-col md:flex-row md:gap-4">
            <div className="mb-3">
              <label
                htmlFor="password"
                className="block text-gray-700 text-sm mb-2"
              >
                Password
              </label>
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="**********"
                className="shadow-sm bg-white appearance-none border rounded w-full py-2 px-3 sm:w-[20rem]  text-gray-700 leading-tight focus:outline-none focusshadow-outline"
              />
            </div>
            <div className="mb-3">
              <label
                htmlFor="password"
                className="block text-gray-700 text-sm mb-2"
              >
                Confirm Password
              </label>
              <input
                type={showPassword ? "text" : "password"}
                name="confirmPassword"
                placeholder="**********"
                className="shadow-sm bg-white appearance-none border rounded w-full py-2 px-3 sm:w-[20rem] text-gray-700 leading-tight focus:outline-none focusshadow-outline"
              />
              <button
                type="button"
                className="fixed top-[33.15rem] right-10 text-gray-400 focus:outline-none"
                onClick={handlePasswordVisibilityToggle}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}{" "}
              </button>
            </div>
          </div>
          <div className="text-gray">
            <p>Please enter a password of at least 8 characters.</p>
          </div>
          <button
            className="bg-[#1E2761] active:scale-90 transition duration-150 transform hover:shadow-xl shadow-md w-full rounded-full px-6 py-2 text-xl font-medium text-white mx-auto text-center mb-3 mt-5"
            type="submit"
            disabled={loading}
          >
            {loading ? "Registering..." : "Register"}
          </button>

          <Link
            to="/login"
            className=" text-[#408EC6] text-center font-semibold w-full mb-3 py-2 px-4 rounded"
          >
            Already have an account?
          </Link>
          <ToastContainer />
        </form>
      </div>
    </div>
  );
};

export default Register;
