import React from "react";
import Header from "../components/Header";
import SpinLoading from "../components/SpinLoading";
import { useUserContext } from "../../context/userContext";
import ProtectedRoute from "../pages/ProtectedRoute";
import { useNavigate } from "react-router-dom";
import CommunityFeaturesBanner from "../components/community-components/CommunityFeatureBanner";
useNavigate;

const Home = () => {
  const navigate = useNavigate();
  const { user } = useUserContext();

  return (
    <>
      <CommunityFeaturesBanner />
      <Header></Header>
    </>
  );
};

export default Home;
