import React, { useEffect, useState } from "react";
import axios from "axios";
import { useQuestionContext } from "../../context/questionContext";
import { MathJax, MathJaxContext } from "better-react-mathjax";
import Loading from "../components/Loading";
import { MdArrowBackIos } from "react-icons/md";
import { useSubjectContext } from "../../context/subjectsContext";
import { useUserContext } from "../../context/userContext";
import SpinLoading from "../components/SpinLoading";
import "./StarButton.css";
import { useNavigate } from "react-router-dom";
import ReportModal from "../components/ReportModal";
import hljs from "highlight.js";
import c from "highlight.js/lib/languages/c";
import DisplayContent from "../components/DisplayContent";

// Then register the languages you need
hljs.registerLanguage("c", c);

const ChapterwisePYQs = () => {
  const { user } = useUserContext();
  const { subjects } = useSubjectContext();
  const { Question, setQuestion } = useQuestionContext();
  const navigate = useNavigate();

  const [activeSubject, setActiveSubject] = useState(null);
  const [activeModule, setActiveModule] = useState(null);
  const [modules, setModules] = useState([]);
  const [index, setIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [noQuestions, setNoQuestions] = useState(false);
  const [importantQuestions, setImportantQuestions] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentQuestionId, setCurrentQuestionId] = useState(null);

  const openModal = (questionId) => {
    setCurrentQuestionId(questionId);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentQuestionId(null);
  };

  useEffect(() => {
    if (user && subjects) {
      const semesterSubjects = subjects[user?.user?.semester];
      const branchSubjects = semesterSubjects
        ? semesterSubjects[user?.user.branch]
        : [];
      const subject1 = branchSubjects[0]?.name;

      setActiveSubject(subject1);
      setModules(branchSubjects[0]?.modules || []);
      setActiveModule(branchSubjects[0]?.modules[0]);
    }
  }, [user, subjects]);

  useEffect(() => {
    if (activeSubject && activeModule) {
      fetchQuestions(activeSubject, activeModule);
    }
  }, [activeSubject, activeModule]);

  useEffect(() => {
    if (activeSubject) {
      const userId = user?.user._id;
      fetchImportantQuestions(userId, activeSubject);
    }
  }, [activeSubject]);

  const handleSubjectClick = (subjectValue) => {
    const subject = branchSubjects.find((sub) => sub.name === subjectValue);
    setActiveSubject(subjectValue);
    setActiveModule(subject.modules[0]);
    setModules(subject.modules);
    setLoading(true);
  };

  const handleModuleClick = (moduleValue) => {
    setActiveModule(moduleValue);
    setLoading(true);
    if (window.innerWidth < 768) {
      setSidebarCollapsed(true);
    }
  };

  const fetchQuestions = async (subjectValue, moduleValue) => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/pyqs/getQuestionBySubjectAndModule?subject=${subjectValue}&module=${moduleValue}`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      if (res.data.success) {
        const questions = res.data.data.question;
        setQuestion(questions);
        setIndex(50);
        setNoQuestions(questions.length === 0);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchImportantQuestions = async (userId, subjectValue) => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/importantQues/getImpQues?userId=${userId}&subject=${subjectValue}`
      );
      if (res.data.success) {
        setImportantQuestions(res.data.data);
      }
    } catch (error) {
      console.error("Error fetching important questions", error);
    }
  };

  const handleStarClick = async (questionId) => {
    try {
      const userId = user?.user?._id;
      const isImportant = importantQuestions.some((q) => q._id === questionId);

      if (isImportant) {
        // Remove from importantQues
        await fetch(
          `https://acad-server-1.onrender.com/api/v1/importantQues/removeImpQues`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ userId, questionId }),
          }
        );
        setImportantQuestions((prev) =>
          prev.filter((q) => q._id !== questionId)
        );
      } else {
        // Add to importantQues
        await fetch(
          `https://acad-server-1.onrender.com/api/v1/importantQues/addImpQues`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ userId, questionId }),
          }
        );
        setImportantQuestions((prev) => [...prev, { _id: questionId }]);
      }
    } catch (error) {
      console.error("Error updating important questions", error);
    }
  };

  const mathJaxConfig = {
    loader: { load: ["[tex]/ams"] },
    tex: {
      packages: { "[+]": ["ams"] },
      inlineMath: [
        ["$", "$"],
        ["\\(", "\\)"],
      ],
      displayMath: [
        ["$$", "$$"],
        ["\\[", "\\]"],
      ],
      processEscapes: true,
      processEnvironments: true,
    },
  };

  if (!user) {
    return (
      <div className="pt-[16vh] h-screen">
        <div className="text-3xl font-bold text-[#1E2761] text-center">
          Loading Questions...
        </div>
        <div className="mt-4">
          <SpinLoading />
        </div>
      </div>
    );
  }

  const semesterSubjects = subjects[user?.user?.semester];
  const branchSubjects = semesterSubjects
    ? semesterSubjects[user?.user?.branch]
    : [];

  return (
    <div className="flex pt-[10vh]">
      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-screen bg-gray-200 p-4 overflow-y-auto pt-[14vh] transform transition-transform duration-0 ${
          sidebarCollapsed
            ? "-translate-x-full md:-translate-x-0 w-full md:w-1/5"
            : "w-full md:w-1/5"
        }`}
      >
        <h2 className="text-lg font-bold mb-4">Subjects</h2>
        <ul>
          {branchSubjects
            .filter((subject) => subject.name !== "Workshop")
            .map((subject) => (
              <li key={subject.id} className="mb-2">
                <button
                  className={`text-[#1E2761] font-medium hover:text-white hover:bg-[#1E2761] py-2 px-4 rounded-md w-full transition duration-0 ${
                    activeSubject === subject.name && "bg-[#1E2761] text-white"
                  }`}
                  onClick={() => handleSubjectClick(subject.name)}
                >
                  {subject.name}
                </button>
              </li>
            ))}
        </ul>
        <h2 className="text-lg font-bold mb-4 mt-8">Modules</h2>
        <ul>
          {modules.map((module, index) => (
            <li key={index} className="mb-2">
              <button
                className={`text-[#1E2761] font-medium hover:text-white hover:bg-[#1E2761] py-2 px-4 rounded-md w-full transition duration-300 ${
                  activeModule === module && "bg-[#1E2761] text-white"
                }`}
                onClick={() => handleModuleClick(module)}
              >
                {module}
              </button>
            </li>
          ))}
        </ul>
      </div>
      {/* Main Content */}
      <div
        className={`transition-all duration-300 w-full md:w-4/5 p-4 ml-auto ${
          sidebarCollapsed ? "" : "hidden md:block"
        }`}
      >
        {/* Toggle Sidebar Button */}
        <button
          className="fixed block left-[-0.5rem] bg-[#1E2761] py-3 px-[0.32rem] rounded-full shadow-lg md:hidden"
          style={{ top: "14vh" }}
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
        >
          <MdArrowBackIos
            className={`text-white ${sidebarCollapsed ? "rotate-180" : ""}`}
          />
        </button>

        <div className="notes rounded-lg shadow-lg">
          {loading ? (
            <Loading />
          ) : noQuestions ? (
            <div className="text-center text-xl h-screen text-[#1E2761] font-bold">
              No questions found for {activeSubject} in {activeModule}.
            </div>
          ) : (
            <MathJaxContext config={mathJaxConfig}>
              <div>
                {Question?.slice(0, index).map((curElem, index) => (
                  <div
                    key={index}
                    className="my-6 p-6 border border-[#1E2761] rounded-lg shadow-sm bg-[#B0E0E6]"
                  >
                    <button
                      className="tooltip text-[#1E2761] text-3xl absolute right-10"
                      onClick={() => handleStarClick(curElem._id)}
                    >
                      {importantQuestions.some((q) => q._id === curElem._id)
                        ? "★"
                        : "☆"}
                      {importantQuestions.some((q) => q._id === curElem._id) ? (
                        <span className="tooltiptext bg-[#7A2048] text-white text-sm">
                          unmark as important
                        </span>
                      ) : (
                        <span className="tooltiptext bg-[#7A2048] text-white text-sm">
                          mark important
                        </span>
                      )}
                    </button>
                    <MathJax
                      dynamic
                      className={`${
                        activeSubject === "Chemistry" || activeSubject === "PPS"
                          ? "whitespace-pre text-wrap"
                          : "whitespace-pre-line"
                      }`}
                    >
                      <div className="font-bold text-xl mb-2 text-[#1E2761]">
                        Question:
                      </div>
                      {activeSubject === "PPS" ? (
                        <pre>
                          <code className="language-c">
                            <div className="text-md md:text-lg overflow-x-auto">
                              <DisplayContent htmlContent={curElem.question} />

                              <p className="text-[#7A2048] font-bold relative bottom-0 right-0 py-5 mb-2 mr-2">
                                Year: {curElem.year}
                              </p>
                            </div>
                          </code>
                        </pre>
                      ) : (
                        <div className="text-md md:text-lg overflow-x-auto">
                          <DisplayContent htmlContent={curElem.question} />

                          <p className="text-[#7A2048] font-bold relative bottom-0 right-0 py-5 mb-2 mr-2">
                            Year: {curElem.year}
                          </p>
                        </div>
                      )}
                    </MathJax>
                    &nbsp; &nbsp;
                    <MathJax
                      dynamic
                      className={`${
                        activeSubject === "Chemistry" || activeSubject === "PPS"
                          ? "whitespace-pre text-wrap"
                          : "whitespace-pre-line"
                      }`}
                    >
                      <div className="font-bold text-xl mb-2 text-[#1E2761]">
                        Solution:
                      </div>
                      {activeSubject === "PPS" ? (
                        <pre>
                          <code>
                            <div className="text-md md:text-lg overflow-x-auto">
                              <DisplayContent htmlContent={curElem.answer} />
                            </div>
                          </code>
                        </pre>
                      ) : (
                        <div className="text-md md:text-lg overflow-x-auto">
                          <DisplayContent htmlContent={curElem.answer} />
                        </div>
                      )}
                    </MathJax>
                    <button
                      onClick={() => openModal(curElem._id)}
                      className="mt-4 bg-red-600 text-white px-4 py-2 rounded"
                    >
                      Report
                    </button>
                  </div>
                ))}
              </div>
            </MathJaxContext>
          )}
        </div>
      </div>
      {/* Report Modal */}
      {isModalOpen && (
        <ReportModal
          isOpen={isModalOpen}
          onRequestClose={closeModal}
          questionId={currentQuestionId}
          userId={user?.user._id}
        />
      )}
    </div>
  );
};

export default ChapterwisePYQs;
