import React, { useState } from "react";
import PostList from "../../components/community-components/PostList";
import CreatePost from "../../components/community-components/CreatePost";
import Feed from "../../components/community-components/Feed";
import MyPost from "../../components/community-components/MyPosts";

const CommunityPage = () => {
  const [activeTab, setActiveTab] = useState("feed"); // State to track active tab

  const handleTabChange = (tab) => {
    setActiveTab(tab); // Update active tab
  };

  return (
    <div className="container mx-auto pt-[14vh] h-auto">
      <div className="flex items-center justify-center gap-12">
        <button
          onClick={() => handleTabChange("feed")}
          className={`px-6 py-2 rounded-lg shadow-md transition duration-300 ${
            activeTab === "feed"
              ? "bg-[#1E2761] text-white hover:bg-[#1E2761]-500"
              : "bg-gray-200 text-gray-800 hover:bg-gray-300"
          }`}
        >
          Feed
        </button>
        <button
          onClick={() => handleTabChange("my-posts")}
          className={`px-6 py-2 rounded-lg shadow-md transition duration-300 ${
            activeTab === "my-posts"
              ? "bg-[#1E2761] text-white hover:bg-[#1E2761]-500"
              : "bg-gray-200 text-gray-800 hover:bg-gray-300"
          }`}
        >
          My Post
        </button>
      </div>

      {/* Conditional rendering of components based on the active tab */}
      {activeTab === "feed" ? <Feed /> : <MyPost />}
    </div>
  );
};

export default CommunityPage;
