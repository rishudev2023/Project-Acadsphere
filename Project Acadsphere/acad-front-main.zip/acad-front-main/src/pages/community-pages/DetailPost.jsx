import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import axios from "axios";
import {
  AiOutlineShareAlt,
  AiOutlineEdit,
  AiOutlineDelete,
} from "react-icons/ai";
import { FaRegHeart, FaHeart } from "react-icons/fa";
import { FaArrowLeftLong } from "react-icons/fa6";
import { MdOutlineInsertComment } from "react-icons/md";
import SpinLoading from "../../components/SpinLoading";
import { useUserContext } from "../../../context/userContext";
import CommentBox from "../../components/community-components/CommentBox";
import DeleteModal from "../../components/community-components/DeleteModal";
import ShareModal from "../../components/community-components/ShareModal";
import { timeSince } from "../../utils/timeSince";
import CommentList from "../../components/community-components/CommentList";
import { useCommentContext } from "../../../context/commentContext";

// Function to handle new comments
const handleNewComment = (newComment) => {
  setComment((prevComments) => [newComment, ...prevComments]);
};

const DetailPost = () => {
  const { postId } = useParams();
  const navigate = useNavigate();
  const { user } = useUserContext(); // Access logged-in user details
  const [post, setPost] = useState(null); // State to hold post details
  const [loading, setLoading] = useState(true);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [Comment, setComment] = useState([]);

  const [showShareModal, setShowShareModal] = useState(false); // State for controlling the share modal visibility

  // Function to open the share modal
  const openShareModal = () => setShowShareModal(true);

  // Function to close the share modal
  const closeShareModal = () => setShowShareModal(false);

  const openDeleteModal = () => setShowDeleteModal(true);

  // Function to close the delete modal
  const closeDeleteModal = () => setShowDeleteModal(false);

  const postLink = `${window.location.origin}/community/post/${postId}`; // Dynamic post link

  // Fetch the detailed post on component mount
  const fetchDetailedPost = async () => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/community/post/${postId}`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      if (res.status === 200) {
        setPost(res.data);
      }
    } catch (error) {
      console.error("Error fetching detailed post:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCommentAdded = () => {
    const fetchComments = async () => {
      try {
        const response = await axios.get(
          `https://acad-server-1.onrender.com/api/v1/community/post/${postId}`
        );
        if (response.data.success) {
          setComments(response.data.data.post.comments);
        }
      } catch (error) {
        console.error("Error fetching comments:", error);
      }
    };

    fetchComments();
  };

  useEffect(() => {
    fetchDetailedPost();
  }, [postId]);

  if (loading) {
    return (
      <div className="h-screen mt-[26vh]">
        <SpinLoading />
        <h1 className="text-2xl text-center">Please wait...</h1>
      </div>
    );
  }

  if (!post) {
    return <p className="text-center text-gray-500">Post not found.</p>;
  }

  // Like a post
  const likePost = async (postId) => {
    try {
      const res = await axios.put(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}/like`,
        {},
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data.success) {
        // Directly update the post object
        setPost((prevPost) => ({
          ...prevPost,
          likes: res.data.likes, // Update likes for the post
        }));
      }
    } catch (error) {
      console.log("Error liking post:", error);
    }
  };

  // Share a post
  const sharePost = async (postId) => {
    try {
      const res = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}/share`,
        {},
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data.success) {
        // Optionally, you can show a success message
        console.log("Post shared successfully");
      }
    } catch (error) {
      console.log("Error sharing post:", error);
    }
  };

  // Edit a post
  const editPost = async (postId, updatedText) => {
    try {
      const res = await axios.put(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}/edit`,
        { text: updatedText },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data.success) {
        // Directly update the post object
        setPost((prevPost) => ({
          ...prevPost,
          text: res.data.post.text, // Update the post text
        }));
      }
    } catch (error) {
      console.log("Error editing post:", error);
    }
  };

  // Delete a post
  const deletePost = async () => {
    try {
      const res = await axios.delete(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        // Navigate back to the community page or another route after deletion
        navigate("/community/feeds");
      }
    } catch (error) {
      console.log("Error deleting post:", error);
    } finally {
      closeDeleteModal(); // Close the modal after the action is completed
    }
  };

  return (
    <div className="bg-white">
      <div className="max-w-2xl mx-auto pt-[14vh] text-xl flex items-center gap-4 bg-white p-4">
        <FaArrowLeftLong
          className="cursor-pointer text-blue-600 hover:text-blue-800 transition duration-300"
          size={25}
          onClick={() => {
            navigate(-1);
          }}
        />
        <span className="text-3xl font-bold text-gray-800">Post</span>
      </div>

      <div className="max-w-2xl mx-auto border p-4 mt-6 bg-white rounded-md shadow-md">
        {/* Post header with user info */}

        <div className="flex items-center gap-2">
          {post.createdBy.profileImage ? (
            <img
              src={post.createdBy.profileImage}
              alt={post.createdBy.name}
              className="w-12 h-12 rounded-full object-cover mr-4"
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center text-gray-700">
              {post.createdBy.name.charAt(0).toUpperCase()}
            </div>
          )}
          <div>
            <p className="font-bold text-gray-900">{post.createdBy.name}</p>
            <p className="text-sm text-gray-500">
              {post.createdBy
                ? post.createdBy.college.charAt(0).toUpperCase() +
                  post.createdBy.college.slice(1).toLowerCase()
                : ""}
            </p>
          </div>
        </div>

        {/* Post content */}
        <div className="mt-4 border rounded-md p-4">
          <p className="text-gray-700">{post.text}</p>
        </div>

        {/* Timestamp */}

        {/* Action Buttons */}
        <div className="flex items-center mt-4 space-x-4">
          <button
            onClick={() => likePost(post._id)}
            className="flex items-center text-gray-500 hover:text-blue-600"
          >
            {post.likes.includes(user?.user._id) ? (
              <FaHeart className="mr-1 text-red-500" size={23} />
            ) : (
              <FaRegHeart className="mr-1" size={20} />
            )}
            {post.likes.length}
          </button>

          <button
            onClick={openShareModal}
            className="flex items-center text-gray-500 hover:text-blue-600"
          >
            <AiOutlineShareAlt className="mr-1" />
            Share
          </button>

          {/* Render the ShareModal */}
          <ShareModal
            showModal={showShareModal}
            onClose={closeShareModal}
            postLink={postLink} // Pass the dynamic post link to the modal
          />

          {user?.user._id === post.createdBy._id && (
            <div className="flex items-center space-x-4">
              <button className="hover:text-blue-600 transition duration-200">
                <Link to={`/community/post/${post._id}/edit`}>
                  <AiOutlineEdit className="mr-1" />
                </Link>
              </button>
              <button
                onClick={() => openDeleteModal(post._id)}
                className="hover:text-red-600 transition duration-200"
              >
                <AiOutlineDelete className="mr-1" />
              </button>

              {/* Delete Modal */}
              <DeleteModal
                showModal={showDeleteModal}
                onClose={closeDeleteModal}
                onConfirm={() => deletePost(post._id)}
              />
            </div>
          )}
          <p className="text-sm text-gray-500 ml-2">
            {timeSince(post.createdAt)}
          </p>
        </div>
        <CommentBox
          postId={post._id}
          onCommentAdded={handleCommentAdded}
          onNewComment={handleNewComment}
        />

        <div>
          <hr className="mt-4" />
          <h1 className="text-xl mt-4 p-4 text-center">Comments</h1>
          <hr />
          <CommentList omments={Comment} onNewComment={handleNewComment} />
        </div>
      </div>
    </div>
  );
};

export default DetailPost;
