import React from "react";

const CookiePolicy = () => {
  return (
    <div className="pt-[16vh] container mx-auto py-8 px-4 text-lg">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden p-5">
        <div className="px-6 py-4 ">
          <h2 className="text-2xl font-semibold m-4 text-center">
            Cookie Policy for Acadsphere
          </h2>
          <p className="text-gray-700 leading-relaxed">
            This Cookie Policy explains how Acadsphere uses cookies and similar
            tracking technologies on our website and platform.
          </p>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              1. What are Cookies:
            </h3>

            <ul>
              <li className="py-2">
                Cookies are small text files that are stored on your device
                (computer, tablet, or mobile phone) when you visit a website.
                They are widely used to make websites work more efficiently and
                to provide information to the owners of the website.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              2. Types of Cookies We Use:
            </h3>

            <ul>
              <li className="py-2">
                1. Essential Cookies: These cookies are necessary for the
                functioning of our website and platform. They enable you to
                navigate our site and use its features.
              </li>
              <li className="py-2">
                2. Analytics Cookies: These cookies allow us to analyze how
                visitors use our website, which helps us improve the user
                experience and optimize our services.
              </li>
              <li className="py-2">
                3. Preference Cookies: These cookies are used to remember your
                preferences and settings, such as language preferences or
                region.
              </li>
              <li className="py-2">
                4. Marketing Cookies: These cookies are used to track your
                browsing habits and deliver targeted advertisements based on
                your interests.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              3. How We Use Cookies:
            </h3>
            <ul>
              <li className="py-2">
                1. We use cookies to personalize your experience on Acadsphere,
                remember your preferences, and analyze how you interact with our
                platform.
              </li>
              <li className="py-2">
                2. We may also use cookies from third-party service providers to
                assist us in analytics, advertising, and other functions.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              4. Your Cookie Choices:
            </h3>
            <ul>
              <li className="py-2">
                1. You can control and manage cookies in your browser settings.
                Most web browsers allow you to block or delete cookies, as well
                as set preferences for certain websites.
              </li>
              <li className="py-2">
                2. Please note that blocking or disabling certain cookies may
                affect the functionality of our website and your user
                experience.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              5. Third-Party Cookies:
            </h3>
            <ul>
              <li className="py-2">
                Some of our pages may contain cookies from third-party services,
                such as Google Analytics, Facebook, or Twitter. These cookies
                are governed by the privacy policies of the respective third
                parties.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              6. Updates to this Cookie Policy:
            </h3>
            <ul>
              <li className="py-2">
                We may update this Cookie Policy from time to time to reflect
                changes in our practices or for other operational, legal, or
                regulatory reasons. We will notify you of any changes by posting
                the updated Cookie Policy on our website.
              </li>
            </ul>
          </div>

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">7. Contact Us:</h3>
            <ul>
              <li className="py-2">
                If you have any questions or concerns about our use of cookies
                or this Cookie Policy, please contact us at{" "}
                <a href="">rishugren03@gmail.com</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookiePolicy;
