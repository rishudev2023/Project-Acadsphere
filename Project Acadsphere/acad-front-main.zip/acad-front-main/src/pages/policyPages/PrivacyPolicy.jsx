import React from "react";

const PrivacyPolicy = () => {
  return (
    <div className="pt-[16vh] container mx-auto py-8 px-4 text-lg">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden p-5">
        <div className="px-6 py-4 ">
          <h2 className="text-2xl font-semibold m-4 text-center">
            Privacy Policy for Acadsphere
          </h2>
          <p className="text-gray-700 leading-relaxed">
            Thank you for using Acadsphere! This Privacy Policy explains how we
            collect, use, disclose, and protect your personal information when
            you use our platform.
          </p>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              1. Information We Collect:
            </h3>
            <p className="text-gray-700 leading-relaxed">
              When you register for an account on Acadsphere, we collect the
              following information:
            </p>
            <ul>
              <li className="py-2">1. Name</li>
              <li className="py-2">2. Email</li>
              <li className="py-2">3. Semester</li>
              <li className="py-2">4. Branch of study</li>
              <li className="py-2">5. College name</li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              2. How We Use Your Information:
            </h3>

            <ul>
              <li className="py-2">1. Create and maintain your account.</li>
              <li className="py-2">
                2. Personalize your experience on Acadsphere.
              </li>
              <li className="py-2">
                3. Communicate with you regarding your account and platform
                updates.
              </li>
              <li>4. Improve our services and develop new features.</li>
              <li className="py-2">
                5. Ensure compliance with our Terms and Conditions and legal
                obligations.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              3. Information Sharing:
            </h3>
            <ul>
              <li className="py-2">
                1. We do not sell, trade, or rent your personal information to
                third parties.
              </li>
              <li className="py-2">
                2. We may share your information with trusted third-party
                service providers who assist us in operating our platform,
                conducting our business, or servicing you, as long as those
                parties agree to keep this information confidential.
              </li>
              <li className="py-2">
                3. We may also disclose your information when we believe release
                is appropriate to comply with the law, enforce our site
                policies, or protect ours or others' rights, property, or
                safety.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">4. Data Security:</h3>
            <ul>
              <li className="py-2">
                1. We implement a variety of security measures to maintain the
                safety of your personal information when you enter, submit, or
                access your information.
              </li>
              <li className="py-2">
                2. Your personal information is stored in secure databases
                protected by industry-standard encryption techniques.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">5. Your Rights:</h3>
            <ul>
              <li className="py-2">
                1. You have the right to review, update, or delete the personal
                information we hold about you.
              </li>
              <li className="py-2">
                2. You can exercise these rights by contacting us using the
                contact information provided below.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              6. Changes to this Privacy Policy:
            </h3>
            <ul>
              <li className="py-2">
                We reserve the right to modify this Privacy Policy at any time.
                We will notify you of any changes by posting the new Privacy
                Policy on this page.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">7. Contact Us:</h3>
            <ul>
              <li className="py-2">
                If you have any questions or concerns regarding this Privacy
                Policy or our data practices, please contact us at{" "}
                <a href="">rishugren03@gmail.com</a>
              </li>
            </ul>
          </div>
          By using Acadsphere, you consent to the terms of this Privacy Policy.
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
