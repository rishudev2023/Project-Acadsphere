import React from "react";

const RefundPolicy = () => {
  return (
    <div className="pt-[16vh] container mx-auto py-8 px-4 text-lg h-screen">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden p-5">
        <div className="px-6 py-4 ">
          <h2 className="text-2xl font-semibold m-4 text-center">
            Refund and Cancelation Policy for Acadsphere
          </h2>
          <p className="text-gray-700 leading-relaxed">
            There is a strict no refund & no cancellation policy. You are
            entitled to a refund only in the case where you have not been
            allotted the contents after the payment.
          </p>
        </div>
      </div>
    </div>
  );
};

export default RefundPolicy;
