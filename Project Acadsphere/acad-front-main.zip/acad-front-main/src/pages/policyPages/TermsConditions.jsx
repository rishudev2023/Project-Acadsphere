import React from "react";

const TermsConditions = () => {
  return (
    <div className="pt-[16vh] container mx-auto py-8 px-4 text-lg">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden p-5">
        <div className="px-6 py-4 ">
          <h2 className="text-2xl font-semibold m-4 text-center">
            Terms and Conditions for Acadsphere
          </h2>
          <p className="text-gray-700 leading-relaxed">
            These Terms and Conditions ("Terms") govern your use of the
            Acadsphere platform. By accessing or using Acadsphere, you agree to
            be bound by these Terms. If you disagree with any part of these
            Terms, you may not use Acadsphere.
          </p>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">1. Content Usage:</h3>

            <ul>
              <li className="py-2">
                1. Users are prohibited from distributing any content provided
                on the Acadsphere platform to anyone without prior permission
                from Acadsphere administrators.
              </li>
              <li className="py-2">
                2. Users may only share content from the platform as permitted
                by Acadsphere to maintain the relevance and integrity of the
                platform.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              2. Prohibited Activities:
            </h3>

            <ul>
              <li className="py-2">
                1. The use of screenshots, screen recorded videos, or any other
                means to share large amounts of content from the platform is
                strictly prohibited.
              </li>
              <li className="py-2">
                2. Users must not engage in any activity that could disrupt or
                undermine the functionality or security of Acadsphere.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              3. User-Generated Content:
            </h3>
            <ul>
              <li className="py-2">
                Since users are not generating any content on the platform, no
                special rules or regulations apply in this regard.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">4. Age Eligibility:</h3>
            <ul>
              <li className="py-2">
                There is no age eligibility requirement for using Acadsphere.
                However, users under the age of 18 should seek parental consent
                before using the platform.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              5. Intellectual Property:
            </h3>
            <ul>
              <li className="py-2">
                All content, trademarks, logos, and intellectual property rights
                on Acadsphere are owned by or licensed to Acadsphere. Users may
                not use, reproduce, or distribute any content from Acadsphere
                without prior authorization.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              6. Limitation of Liability:
            </h3>
            <ul>
              <li className="py-2">
                Acadsphere shall not be liable for any direct, indirect,
                incidental, special, or consequential damages arising out of or
                in any way connected with your use of Acadsphere.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              7. Indemnification:{" "}
            </h3>
            <ul>
              <li className="py-2">
                Users agree to indemnify and hold Acadsphere harmless from any
                claim or demand, including reasonable attorneys' fees, made by
                any third party due to or arising out of your use of Acadsphere
                or violation of these Terms.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              8. Changes to Terms:{" "}
            </h3>
            <ul>
              <li className="py-2">
                Acadsphere reserves the right to update or modify these Terms at
                any time without prior notice. Your continued use of Acadsphere
                after any such changes constitutes your acceptance of the new
                Terms.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">9.Governing Law:</h3>
            <ul>
              <li className="py-2">
                These Terms shall be governed by and construed in accordance
                with the laws of India, without regard to its conflict of law
                provisions.
              </li>
            </ul>
          </div>
          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">7. Contact Us:</h3>
            <ul>
              <li className="py-2">
                If you have any questions or concerns about these Terms, please
                contact us at <a href="">rishugren03@gmail.com</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsConditions;
