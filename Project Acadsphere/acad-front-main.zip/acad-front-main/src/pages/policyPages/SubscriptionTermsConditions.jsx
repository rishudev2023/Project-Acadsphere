import React from "react";

const SubscriptionTermsConditions = () => {
  return (
    <div className="pt-[16vh] container mx-auto py-8 px-4 text-lg">
      <div className="bg-white shadow-lg rounded-lg overflow-hidden p-5">
        <div className="px-6 py-4">
          <h2 className="text-2xl font-semibold m-4 text-center">
            Subscription Terms and Conditions for Acadsphere
          </h2>
          <p className="text-gray-700 leading-relaxed">
            These Subscription Terms and Conditions govern your access to
            Acadsphere's premium contents. By subscribing to Acadsphere, you
            agree to these Terms, including our no-refund policy and guidelines
            for content usage. If you disagree with any part of these Terms, we
            encourage you to explore our free content or reach out to us for
            clarification.
          </p>

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              1. Subscription Access:
            </h3>
            <ul>
              <li className="py-2">
                By subscribing to Acadsphere, you gain exclusive access to
                in-depth, year-wise, chapter-wise solved questions, detailed
                solutions, and other premium resources. Plus, your important
                questions are available for free to help you prepare effectively
                even without a subscription.
              </li>
              <li className="py-2">
                2. Subscription grants a limited, non-transferable license to
                use premium content solely for personal, educational purposes.
              </li>
            </ul>
          </div>

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              2. No Refund Policy:
            </h3>
            <ul>
              <li className="py-2">
                1. All subscription payments are final and non-refundable. We
                are confident in the value of our premium contents, and
                encourage you to explore free content before subscribing.
              </li>
              <li className="py-2">
                2. Once payment is made, you will have immediate access to
                premium content, and no refunds will be provided for unused or
                partially used subscriptions.
              </li>
            </ul>
          </div>

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              3. Question Accuracy Disclaimer:
            </h3>
            <ul>
              <li className="py-2">
                1. Acadsphere strives to provide accurate and well-researched
                solutions. However, given the vast array of subjects and
                complexity, some answers may contain minor inaccuracies.
              </li>
              <li className="py-2">
                2. We encourage users to cross-verify answers and report any
                inaccuracies. Your feedback helps us constantly improve the
                platform.
              </li>
            </ul>
          </div>

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              4. Content Updates and Improvements:
            </h3>
            <ul>
              <li className="py-2">
                1. As part of our continuous efforts to provide quality content,
                we regularly update questions and answers. The accuracy of older
                materials may vary as educational standards evolve.
              </li>
              <li className="py-2">
                2. You will always have access to the latest materials and
                updates as part of your active subscription.
              </li>
            </ul>
          </div>

          {/* <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              5. Premium Benefits:
            </h3>
            <ul>
              <li className="py-2">
                1. Acadsphere’s premium subscription gives you access to
                additional resources, early releases, and exclusive solutions,
                designed to boost your exam preparations. The premium experience
                allows you to save valuable time and effort.
              </li>
              <li className="py-2">
                2. We are committed to making your subscription experience
                worthwhile, ensuring that you gain a competitive edge.
              </li>
            </ul>
          </div> */}

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              6. Limitation of Liability:
            </h3>
            <ul>
              <li className="py-2">
                Acadsphere will not be liable for any inaccuracies or damages
                resulting from your use of the platform. Our content is intended
                to assist your studies but should not be your sole source of
                preparation.
              </li>
            </ul>
          </div>

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">
              7. Subscription Termination:
            </h3>
            <ul>
              <li className="py-2">
                Acadsphere reserves the right to terminate any subscription if
                these Terms are violated, including but not limited to content
                distribution without permission or other activities deemed
                harmful to the platform.
              </li>
            </ul>
          </div>

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">8. Governing Law:</h3>
            <ul>
              <li className="py-2">
                These Terms are governed by the laws of India, and any disputes
                related to these Terms will be resolved exclusively in Indian
                courts.
              </li>
            </ul>
          </div>

          <div className="p-4">
            <h3 className="text-2xl font-semibold mb-4">9. Contact Us:</h3>
            <ul>
              <li className="py-2">
                If you have any questions about these Subscription Terms or wish
                to report any issues, please contact us at{" "}
                <a href="mailto:rishu@acadsphere.in" className="text-blue-500">
                  rishu@acadsphere.in
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionTermsConditions;
