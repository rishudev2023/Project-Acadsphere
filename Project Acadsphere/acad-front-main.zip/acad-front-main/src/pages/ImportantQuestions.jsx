import React, { useEffect, useState } from "react";
import axios from "axios";
import Loading from "../components/Loading";
import { MdArrowBackIos } from "react-icons/md";
import { MathJax, MathJaxContext } from "better-react-mathjax";
import SpinLoading from "../components/SpinLoading";
import { useUserContext } from "../../context/userContext";
import { useSubjectContext } from "../../context/subjectsContext";
import DisplayContent from "../components/DisplayContent";

const ImportantQuestions = () => {
  const { user } = useUserContext();
  const { subjects } = useSubjectContext();

  const [activeSubject, setActiveSubject] = useState("Maths");
  const [importantQuestions, setImportantQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  useEffect(() => {
    if (user) {
      const semesterSubjects = subjects[user?.user?.semester];
      const semAndBranchWiseSubject = semesterSubjects[user?.user.branch];
      setActiveSubject(semAndBranchWiseSubject[0].name);
    }
  }, [user, subjects]);

  useEffect(() => {
    const fetchData = async () => {
      if (user && activeSubject) {
        const userId = user?.user._id;
        try {
          setLoading(true);
          const res = await axios.get(
            `https://acad-server-1.onrender.com/api/v1/importantQues/getImpQues?userId=${userId}&subject=${activeSubject}`
          );
          if (res.data.success) {
            setImportantQuestions(res.data.data);
          }
        } catch (error) {
          console.error("Error fetching important questions", error);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchData();
  }, [user, activeSubject]);

  const handleSubjectClick = (subjectValue) => {
    setActiveSubject(subjectValue);

    setLoading(true);
    if (window.innerWidth < 768) {
      setSidebarCollapsed(true);
    }
  };

  const handleStarClick = async (questionId) => {
    try {
      const userId = user?.user?._id;
      const isImportant = importantQuestions.some((q) => q._id === questionId);

      if (isImportant) {
        // Remove from importantQues
        await axios.post(
          `https://acad-server-1.onrender.com/api/v1/importantQues/removeImpQues`,
          { userId, questionId }
        );
        setImportantQuestions((prev) =>
          prev.filter((q) => q._id !== questionId)
        );
      } else {
        // Add to importantQues
        await axios.post(
          `https://acad-server-1.onrender.com/api/v1/importantQues/addImpQues`,
          {
            userId,
            questionId,
          }
        );
        setImportantQuestions((prev) => [...prev, { _id: questionId }]);
      }
    } catch (error) {
      console.error("Error updating important questions", error);
    }
  };

  const mathJaxConfig = {
    loader: { load: ["[tex]/ams"] },
    tex: {
      packages: { "[+]": ["ams"] },
      inlineMath: [
        ["$", "$"],
        ["\\(", "\\)"],
      ],
      displayMath: [
        ["$$", "$$"],
        ["\\[", "\\]"],
      ],
      processEscapes: true,
      processEnvironments: true,
    },
  };

  if (!user) {
    return (
      <div className="pt-[16vh] h-screen">
        <div className="text-3xl font-bold text-[#1E2761] text-center">
          Loading Questions...
        </div>
        <div className="mt-[4rem]">
          <SpinLoading />
        </div>
      </div>
    );
  }

  return (
    <div className="flex pt-[10vh]">
      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-screen bg-gray-200 p-4 overflow-y-auto pt-[14vh] transform transition-transform duration-0 ${
          sidebarCollapsed
            ? "-translate-x-full md:-translate-x-0 w-full md:w-1/5"
            : "w-full md:w-1/5"
        }`}
      >
        <h2 className="text-lg font-bold mb-4">Subjects</h2>
        <ul>
          {subjects[user?.user?.semester][user?.user?.branch].map((subject) => (
            <li key={subject.id} className="mb-2">
              <button
                className={`text-[#1E2761] font-medium hover:text-white hover:bg-[#1E2761] py-2 px-4 rounded-md w-full transition duration-0 ${
                  activeSubject === subject.name && "bg-[#1E2761] text-white"
                }`}
                onClick={() => handleSubjectClick(subject.name)}
              >
                {subject.name}
              </button>
            </li>
          ))}
        </ul>
      </div>
      {/* Content */}
      <div
        className={`transition-all duration-300 w-full md:w-4/5 p-4 ml-auto ${
          sidebarCollapsed ? "" : "hidden md:block"
        }`}
      >
        <button
          className="fixed block left-[-0.5rem] bg-[#1E2761] py-3 px-[0.32rem] rounded-full shadow-lg md:hidden"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
        >
          <MdArrowBackIos
            className={`text-white ${sidebarCollapsed ? "rotate-180" : ""}`}
          />
        </button>
        <div className="notes rounded-lg shadow-lg">
          {loading ? (
            <Loading />
          ) : importantQuestions.length === 0 ? (
            <div className="text-center text-xl h-screen text-[#1E2761] font-bold">
              No important questions found.
            </div>
          ) : (
            <MathJaxContext config={mathJaxConfig}>
              <div>
                {importantQuestions.map((curElem, index) => (
                  <div
                    key={index}
                    className="relative my-6 p-6 border border-[#1E2761] rounded-lg shadow-sm bg-[#B0E0E6]"
                  >
                    <button
                      className="text-[#1E2761] text-2xl absolute right-10"
                      onClick={() => handleStarClick(curElem._id)}
                    >
                      {importantQuestions.some((q) => q._id === curElem._id)
                        ? "★"
                        : "☆"}
                    </button>
                    <MathJax dynamic className={`whitespace-pre-wrap`}>
                      <div className="font-bold text-xl mb-2 text-[#1E2761]">
                        Question:
                      </div>
                      <div className="text-md md:text-lg">
                        <DisplayContent htmlContent={curElem.question} />
                      </div>
                    </MathJax>
                    &nbsp; &nbsp;
                    <MathJax dynamic className={`whitespace-pre-wrap`}>
                      <div className="font-bold text-xl mb-2 text-[#1E2761]">
                        Solution:
                      </div>
                      <div className="text-md md:text-lg">
                        {" "}
                        <DisplayContent htmlContent={curElem.answer} />
                      </div>
                    </MathJax>
                  </div>
                ))}
              </div>
            </MathJaxContext>
          )}
        </div>
      </div>
      {/* Sidebar collapse button */}
    </div>
  );
};

export default ImportantQuestions;
