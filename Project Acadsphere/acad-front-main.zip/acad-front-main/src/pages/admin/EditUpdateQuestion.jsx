import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import SpinLoading from "../../components/SpinLoading";

const EditUpdateQuestion = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [questionData, setQuestionData] = useState({
    semester: "",
    branch: "",
    year: "",
    subject: "",
    module: "",
    question: "",
    answer: "",
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchQuestion = async () => {
      try {
        const res = await axios.get(
          `https://acad-server-1.onrender.com/api/v1/updateQues/${id}/edit`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );
        setQuestionData(res.data);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setLoading(false);
      }
    };

    fetchQuestion();
  }, [id]);

  const onChange = (e) => {
    setQuestionData({ ...questionData, [e.target.name]: e.target.value });
  };

  const handleQuestionChange = (value) => {
    setQuestionData({ ...questionData, question: value });
  };

  const handleAnswerChange = (value) => {
    setQuestionData({ ...questionData, answer: value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(
        `https://acad-server-1.onrender.com/api/v1/updateQues/${id}/edit`,
        questionData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      toast.success("Question updated successfully");
      navigate(-1);
    } catch (err) {
      console.error(err);
      toast.error("Failed to update question. Please try again later.");
    }
  };

  const modules = {
    toolbar: [
      [{ header: "1" }, { header: "2" }, { font: [] }],
      [{ size: [] }],
      ["bold", "italic", "underline", "strike", "blockquote"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link", "image"],
      [{ color: [] }, { background: [] }],
      [{ align: [] }],
      ["clean"],
    ],
  };

  if (loading) {
    return (
      <div className="pt-[16vh] h-screen">
        <div className="text-3xl font-bold text-[#1E2761] text-center">
          Loading question for edit
        </div>
        <div className="mt-[4rem]">
          <SpinLoading />
        </div>
      </div>
    );
  }

  return (
    <div className="addquestion mb-5">
      <div className="w-full mx-auto pt-[16vh]">
        <form
          className="ease-in duration-300 w-full sm:w-max shadow-sm backdrop-blur-md bg-white/80 lg:w-[800px] mx-auto rounded-md px-8 py-5"
          onSubmit={onSubmit}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="semester"
              value={questionData.semester}
              onChange={onChange}
            >
              <option disabled>select semester</option>
              <option>Second</option>
              <option>Third</option>
              <option>Fourth</option>
              <option>Fifth</option>
              <option>Sixth</option>
              <option>Seventh</option>
              <option>Eighth</option>
            </select>

            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="branch"
              value={questionData.branch}
              onChange={onChange}
            >
              <option disabled>select branch</option>
              <option>CIVIL</option>
              <option>MECH</option>
            </select>

            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="year"
              value={questionData.year}
              onChange={onChange}
            >
              <option disabled>select year</option>
              <option>2022</option>
              <option>2021</option>
              <option>2020</option>
              <option>2019</option>
              <option>2018</option>
            </select>
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="subject"
              value={questionData.subject}
              onChange={onChange}
            >
              <option disabled>select subject</option>
              <option>Maths</option>
              <option>PPS</option>
              <option>Chemistry</option>
              <option>BEE</option>
              <option>Physics</option>
              {/* other options */}
            </select>
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
              name="module"
              value={questionData.module}
              onChange={onChange}
            >
              <option disabled>select module</option>
              <option>Module 3a</option>
              <option>Module 3b</option>
              {/* other options */}
            </select>
          </div>

          <div className="space-y-8 py-6">
            <div className="space-y-4">
              <label
                htmlFor="question"
                className="text-lg font-semibold text-gray-800"
              >
                Question (LaTeX Format)
              </label>
              <div className="border-2 border-blue-300 rounded-lg shadow-md overflow-hidden">
                <ReactQuill
                  value={questionData.question}
                  onChange={handleQuestionChange}
                  modules={modules}
                  className="p-4 text-gray-800 h-[20rem]"
                  name="question"
                  placeholder="Type your question here..."
                  style={{
                    minHeight: "20rem",
                    whiteSpace: "pre-wrap",
                    borderRadius: "8px",
                  }}
                />
              </div>
            </div>

            <div className="space-y-4">
              <label
                htmlFor="answer"
                className="text-lg font-semibold text-gray-800"
              >
                Answer (LaTeX Format)
              </label>
              <div className="border-2 border-blue-300 rounded-lg shadow-md overflow-hidden">
                <ReactQuill
                  value={questionData.answer}
                  onChange={handleAnswerChange}
                  modules={modules}
                  className="p-4 text-gray-800 h-[20rem]"
                  name="answer"
                  placeholder="Type your answer here..."
                  style={{
                    minHeight: "20rem",
                    whiteSpace: "pre-wrap",
                    borderRadius: "8px",
                  }}
                />
              </div>
            </div>
          </div>

          <button
            className="bg-[#1E2761] active:scale-90 transition duration-150 transform hover:shadow-xl shadow-md w-full rounded-full px-6 py-2 text-xl font-medium text-white mx-auto text-center mb-3 mt-5 whitespace-pre-line"
            type="submit"
          >
            Update Question
          </button>
          <ToastContainer />
        </form>
      </div>
    </div>
  );
};

export default EditUpdateQuestion;
