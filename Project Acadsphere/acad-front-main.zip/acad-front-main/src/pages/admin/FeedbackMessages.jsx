import React, { useEffect, useState } from "react";
import { useFeedbackContext } from "../../../context/feedbackContext";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import SpinLoading from "../../components/SpinLoading";

const FeedbackMessages = () => {
  const { feedback, setFeedback } = useFeedbackContext();
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5); // Change this value as needed

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  const fetchFeedbacks = async () => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/feedback/get-feedback`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        // Reverse the order of feedback array to display latest message first
        setFeedback(res.data.feedback.reverse());
      }
    } catch (error) {
      console.log(error);
      toast.error("Failed to fetch feedbacks. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Logic to calculate indexes of the current page's items
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentFeedbacks = feedback.slice(indexOfFirstItem, indexOfLastItem);

  // Logic to paginate
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 pt-[14vh]">
      <h1 className="text-3xl font-bold mb-5 text-[#1E2761]">User Feedback</h1>
      {isLoading ? (
        <SpinLoading />
      ) : (
        <div className="w-full max-w-4xl">
          {currentFeedbacks.length > 0 ? (
            currentFeedbacks.map((item) => (
              <div
                key={item._id}
                className="bg-white p-4 mb-4 rounded-lg shadow-md hover:shadow-lg transition duration-300"
              >
                <p className="text-md font-semibold text-[#1E2761]">
                  {item.message}
                </p>
                <div className="mt-2">
                  <p className="text-sm text-[#408EC6]">
                    <span className="font-semibold">Name:</span> {item.name}
                  </p>
                  <p className="text-sm text-[#408EC6]">
                    <span className="font-semibold">Email:</span> {item.email}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-gray-700">No feedback messages found.</p>
          )}
          {/* Pagination */}
          <div className="flex justify-center mt-4">
            {Array.from(
              { length: Math.ceil(feedback.length / itemsPerPage) },
              (_, i) => (
                <button
                  key={i}
                  onClick={() => paginate(i + 1)}
                  className={`mx-1 px-3 py-1 border rounded ${
                    currentPage === i + 1 ? "bg-gray-300" : "bg-gray-200"
                  } hover:bg-gray-400 transition duration-300`}
                >
                  {i + 1}
                </button>
              )
            )}
          </div>
        </div>
      )}
      <ToastContainer />
    </div>
  );
};

export default FeedbackMessages;
