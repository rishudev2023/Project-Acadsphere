import React from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import { NavLink } from "react-router-dom";
import logo from "../../assets/images/logo.svg";

const AddDetailedNotes = () => {
  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.target;
    const subject = form.subject.value;
    const module = form.module.value;
    const topic = form.topic.value;
    const topicExplanation = form.topicExplanation.value;

    // Client-side validation: Check if any required field is empty
    if (!subject || !module || !topic || !topicExplanation) {
      toast.error("Please fill out all fields");
      return;
    }

    const detailedNotesData = {
      subject,
      module,
      topic,
      topicExplanation,
    };

    try {
      const res = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/notes/addDetailedNotes`,
        detailedNotesData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      if (res.data.success) {
        toast.success(res.data.message);
        form.reset();
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      console.error("Error adding detailed notes:", error);
      toast.error("Failed to add notes. Please try again later.");
    }
  };

  return (
    <div className="adddetailednotes mb-5">
      <div className="w-full mx-auto pt-[16vh]">
        <form
          className="ease-in duration-300 w-full sm:w-max shadow-sm backdrop-blur-md bg-white/80 lg:w-[800px] mx-auto rounded-md px-8 py-5"
          onSubmit={handleSubmit}
        >
          <NavLink to="/" className="flex mb-4 items-center justify-center">
            <img
              src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgdZPjmVZIjumxmsOsENuliphIkXFOykMdtYkfFJyZlkGiQmnab3nQPhKYEji9G28wORKLx5wzWirQq8Yc8mzOPq8bFsroyKe7Uv_9onP406X7VXtlw1R5oYhkErM-vphB_3Kw5vmwJ1hfcGYXOfzlN5DkqE-ZEG8k2RGK25mfjw5AC2pqKG3xRSI6siMY/s1600/logo.webp"
              alt=""
              className="logo h-14 w-14 cursor-pointer text-center"
            />
            <h1 className="text-[#191919] text-2xl font-mono">Acadsphere</h1>
          </NavLink>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="subject"
            >
              <option selected disabled>
                select subject
              </option>
              <option>Maths</option>
              <option>PPS</option>
              <option>Chemistry</option>
              <option>Workshop</option>
            </select>

            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
              name="module"
            >
              <option selected disabled>
                select module
              </option>
              <option>Module 1</option>
              <option>Module 2</option>
              <option>Module 3</option>
              <option>Module 4</option>
              <option>Module 5</option>
              <option>Module 6</option>
              <option>Module 7</option>
              <option>Module 8</option>
              <option>Module 9</option>
              <option>Module 10</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <input
              className="shadow-sm bg-white appearance-none border rounded w-full py-3 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              name="topic"
              placeholder="topic"
            />

            <textarea
              className="textarea textarea-ghost shadow-sm bg-white appearance-none border rounded w-full h-[10rem] py-3 px-3 col-span-2 text-gray-700 leading-tight focus:outline-none focusshadow-outline"
              name="topicExplanation"
              placeholder="explain the topic in LaTeX format"
            ></textarea>
          </div>
          <button
            className="bg-[#1E2761] active:scale-90 transition duration-150 transform hover:shadow-xl shadow-md w-full rounded-full px-6 py-2 text-xl font-medium text-white mx-auto text-center mb-3 mt-5"
            type="submit"
          >
            Add Notes
          </button>
          <ToastContainer />
        </form>
      </div>
    </div>
  );
};

export default AddDetailedNotes;
