import React, { useState, useEffect } from "react";
import axios from "axios";
import { MathJax, MathJaxContext } from "better-react-mathjax";
import Loading from "../../components/Loading";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from "react-router-dom";
import { useUserContext } from "../../../context/userContext";
import DisplayContent from "../../components/DisplayContent";

const MyQuestions = () => {
  const navigate = useNavigate();
  const { user } = useUserContext();

  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5); // You can adjust the number of items per page here

  const maxPageNumbersToShow = 5; // Maximum number of page numbers to show at once

  useEffect(() => {
    if (user) {
      fetchQuestions();
    }
  }, [user]);

  const fetchQuestions = async () => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/admin/my-questions`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data) {
        setQuestions(res.data.reverse()); // Reverse the order of questions
      }
    } catch (err) {
      console.log(err);
      toast.error("Failed to load questions. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  // Logic to calculate indexes of the current page's items
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentQuestions = questions.slice(indexOfFirstItem, indexOfLastItem);

  // Total number of pages
  const totalPages = Math.ceil(questions.length / itemsPerPage);

  // Function to handle page change
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  // Logic for displaying the range of page numbers
  const startPage = Math.max(
    currentPage - Math.floor(maxPageNumbersToShow / 2),
    1
  );
  const endPage = Math.min(startPage + maxPageNumbersToShow - 1, totalPages);

  const mathJaxConfig = {
    loader: { load: ["[tex]/ams"] },
    tex: {
      packages: { "[+]": ["ams"] },
      inlineMath: [
        ["$", "$"],
        ["\\(", "\\)"],
      ],
      displayMath: [
        ["$$", "$$"],
        ["\\[", "\\]"],
      ],
      processEscapes: true,
      processEnvironments: true,
    },
  };

  if (loading) return <Loading />;

  return (
    <div className="pt-[16vh] p-10">
      <h1 className="text-2xl text-[#1E2761] text-center font-bold mb-5">
        My Questions
      </h1>
      <div className="notes rounded-lg shadow-lg">
        {currentQuestions.length === 0 ? (
          <div className="text-center text-xl h-screen text-[#1E2761] font-bold">
            No questions found.
          </div>
        ) : (
          <MathJaxContext config={mathJaxConfig}>
            <div>
              {currentQuestions.map((curElem, index) => (
                <div
                  key={index}
                  className="relative my-6 p-6 border border-[#1E2761] rounded-lg shadow-sm bg-[#B0E0E6]"
                >
                  {user?.user && user?.user.role === "admin" && (
                    <button
                      className="absolute right-10 bg-[#1E2761] border rounded-md text-white h-10 w-20"
                      onClick={() => {
                        navigate(`/questions/${curElem?._id}/edit`);
                      }}
                    >
                      Edit
                    </button>
                  )}
                  <MathJax dynamic className="whitespace-pre-wrap">
                    <div className="font-bold text-xl mb-2 text-[#1E2761]">
                      Question:
                    </div>
                    <div className="text-md md:text-lg">
                      {" "}
                      <DisplayContent htmlContent={curElem.question} />
                    </div>
                  </MathJax>
                  &nbsp; &nbsp;
                  <MathJax dynamic className="whitespace-pre-wrap">
                    <div className="font-bold text-xl mb-2 text-[#1E2761]">
                      Solution:
                    </div>
                    <div className="text-md md:text-lg">
                      <DisplayContent htmlContent={curElem.answer} />
                    </div>
                  </MathJax>
                </div>
              ))}
            </div>
          </MathJaxContext>
        )}
      </div>

      {/* Pagination */}
      <div className="flex justify-center mt-4">
        {/* Previous Button */}
        {currentPage > 1 && (
          <button
            onClick={() => paginate(currentPage - 1)}
            className="mx-1 px-3 py-1 border rounded bg-gray-200 hover:bg-gray-400 transition duration-300"
          >
            Prev
          </button>
        )}

        {/* Page Numbers */}
        {Array.from({ length: endPage - startPage + 1 }, (_, i) => {
          const pageNumber = startPage + i;
          return (
            <button
              key={pageNumber}
              onClick={() => paginate(pageNumber)}
              className={`mx-1 px-3 py-1 border rounded ${
                currentPage === pageNumber ? "bg-gray-300" : "bg-gray-200"
              } hover:bg-gray-400 transition duration-300`}
            >
              {pageNumber}
            </button>
          );
        })}

        {/* Next Button */}
        {currentPage < totalPages && (
          <button
            onClick={() => paginate(currentPage + 1)}
            className="mx-1 px-3 py-1 border rounded bg-gray-200 hover:bg-gray-400 transition duration-300"
          >
            Next
          </button>
        )}
      </div>

      <ToastContainer />
    </div>
  );
};

export default MyQuestions;
