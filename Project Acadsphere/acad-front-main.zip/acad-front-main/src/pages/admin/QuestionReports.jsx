import React, { useEffect, useState } from "react";
import { useReportContext } from "../../../context/questionReportContext";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import SpinLoading from "../../components/SpinLoading";
import { MathJax, MathJaxContext } from "better-react-mathjax";
import { useNavigate } from "react-router-dom";
import DisplayContent from "../../components/DisplayContent";

const QuestionReports = () => {
  const { report, setReport } = useReportContext();
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);
  const navigate = useNavigate();

  const maxPageNumbersToShow = 5; // Maximum number of page numbers to show at once

  useEffect(() => {
    fetchReports();
  }, []);

  useEffect(() => {
    // This useEffect will trigger when `report` is updated
  }, [report]);

  const fetchReports = async () => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/report/question-reports`
      );
      if (res.data.success) {
        setReport(res.data.data.reverse());
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      console.error("Error fetching reports", error);
      toast.error("Failed to fetch reports. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const navigateToQuestion = (questionId) => {
    navigate(`/view-solution/${questionId}`);
  };

  // Logic to calculate indexes of the current page's items
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentReports = report?.slice(indexOfFirstItem, indexOfLastItem) || [];

  // Total number of pages
  const totalPages = Math.ceil(report.length / itemsPerPage);

  // Logic to paginate
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const startPage = Math.max(
    currentPage - Math.floor(maxPageNumbersToShow / 2),
    1
  );
  const endPage = Math.min(startPage + maxPageNumbersToShow - 1, totalPages);

  const mathJaxConfig = {
    loader: { load: ["[tex]/ams"] },
    tex: {
      packages: { "[+]": ["ams"] },
      inlineMath: [
        ["$", "$"],
        ["\\(", "\\)"],
      ],
      displayMath: [
        ["$$", "$$"],
        ["\\[", "\\]"],
      ],
      processEscapes: true,
      processEnvironments: true,
    },
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 pt-[16vh]">
      <h1 className="text-4xl font-bold mb-8 text-[#1E2761]">
        Question Reports
      </h1>
      {isLoading ? (
        <SpinLoading />
      ) : (
        <div className="w-full max-w-4xl">
          {currentReports.length > 0 ? (
            currentReports.map((item) => (
              <div
                key={item._id}
                className="bg-white my-4 p-4 rounded-lg shadow-md hover:shadow-lg transition duration-300 cursor-pointer"
                onClick={() => navigateToQuestion(item.questionId?._id)}
              >
                <p className="text-md font-semibold text-[#1E2761]">
                  Reason: <span className="text-red-500">{item.reason}</span>
                </p>
                <MathJaxContext config={mathJaxConfig}>
                  <div className="relative p-6 rounded-lg shadow-sm bg-[#F5F5F5] mt-4">
                    <div className="relative p-2 border border-[#1E2761] rounded-lg shadow-sm bg-[#B0E0E6]">
                      <MathJax dynamic className="whitespace-pre-wrap">
                        <div className="font-bold text-xl text-[#1E2761] mb-2">
                          Question:
                        </div>
                        <div className="text-md md:text-lg">
                          <DisplayContent
                            htmlContent={item.questionId?.question}
                          />
                        </div>
                      </MathJax>
                    </div>
                    <p className="text-sm text-[#7A2048] mt-4 font-semibold">
                      Reported by:
                      <span className=" text-[#408EC6] ">
                        {item.userId?.name || "Unknown"} (
                        {item.userId?.email || "Unknown"})
                      </span>
                    </p>
                  </div>
                </MathJaxContext>
              </div>
            ))
          ) : (
            <p className="text-gray-700">No reports found.</p>
          )}
          {/* Pagination */}
          <div className="flex justify-center mt-4">
            {/* Previous Button */}
            {currentPage > 1 && (
              <button
                onClick={() => paginate(currentPage - 1)}
                className="mx-1 px-3 py-1 border rounded bg-gray-200 hover:bg-gray-400 transition duration-300"
              >
                Prev
              </button>
            )}

            {/* Page Numbers */}
            {Array.from({ length: endPage - startPage + 1 }, (_, i) => {
              const pageNumber = startPage + i;
              return (
                <button
                  key={pageNumber}
                  onClick={() => paginate(pageNumber)}
                  className={`mx-1 px-3 py-1 border rounded ${
                    currentPage === pageNumber ? "bg-gray-300" : "bg-gray-200"
                  } hover:bg-gray-400 transition duration-300`}
                >
                  {pageNumber}
                </button>
              );
            })}

            {/* Next Button */}
            {currentPage < totalPages && (
              <button
                onClick={() => paginate(currentPage + 1)}
                className="mx-1 px-3 py-1 border rounded bg-gray-200 hover:bg-gray-400 transition duration-300"
              >
                Next
              </button>
            )}
          </div>
        </div>
      )}
      <ToastContainer />
    </div>
  );
};

export default QuestionReports;
