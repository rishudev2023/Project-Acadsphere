import React, { useState } from "react";
import axios from "axios";

const CreateNotification = () => {
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = await axios.post(
        "https://acad-server-1.onrender.com/api/v1/notifications/create-notification",
        {
          title,
          message,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      if (response.data.success) {
        setSuccess(true);
        setTitle("");
        setMessage("");
      }
    } catch (err) {
      setError("Error creating notification. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-lg mx-auto p-4 bg-white rounded-lg shadow-md mt-[20vh] mb-[7.5rem]">
      <h2 className="text-xl font-bold mb-4">Create Notification</h2>
      <form onSubmit={handleSubmit}>
        {success && (
          <p className="text-green-600 mb-2">
            Notification created successfully!
          </p>
        )}
        {error && <p className="text-red-600 mb-2">{error}</p>}
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Notification Title"
          className="w-full p-2 border rounded mb-4"
          required
        />
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Notification Message"
          className="w-full h-20 p-2 border rounded mb-4"
          required
        />
        <button
          type="submit"
          disabled={loading}
          className={`w-full p-2 text-white rounded ${
            loading ? "bg-gray-400" : "bg-[#1E2761] hover:bg-[#1A1B53]"
          }`}
        >
          {loading ? "Creating..." : "Create Notification"}
        </button>
      </form>
    </div>
  );
};

export default CreateNotification;
