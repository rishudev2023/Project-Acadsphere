import React, { useState, useEffect } from "react";
import { useUserContext } from "../../../context/userContext";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const { user } = useUserContext();
  const navigate = useNavigate();

  const [totalUsers, setTotalUsers] = useState(null);
  const [monthlyUsers, setMonthlyUsers] = useState(null);
  const [yearlyUsers, setYearlyUsers] = useState(null);
  const [todayUsers, setTodayUsers] = useState(null);
  const [totalQuestions, setTotalQuestions] = useState(null);

  useEffect(() => {
    if (user?.user.email === "rishugren03@gmail.com") {
      const fetchData = async () => {
        try {
          const totalRes = await fetch(
            `https://acad-server-1.onrender.com/api/v1/user-stats/total`,
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            }
          );
          const totalData = await totalRes.json();
          setTotalUsers(totalData.totalUsers);

          const monthlyRes = await fetch(
            `https://acad-server-1.onrender.com/api/v1/user-stats/monthly`,
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            }
          );
          const monthlyData = await monthlyRes.json();
          setMonthlyUsers(monthlyData.monthlyUsers);

          const yearlyRes = await fetch(
            `https://acad-server-1.onrender.com/api/v1/user-stats/yearly`,
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            }
          );
          const yearlyData = await yearlyRes.json();
          setYearlyUsers(yearlyData.yearlyUsers);

          const todayRes = await fetch(
            `https://acad-server-1.onrender.com/api/v1/user-stats/today`,
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            }
          );
          const todayData = await todayRes.json();
          setTodayUsers(todayData.todayUsers);

          const totalQuestionsRes = await fetch(
            `https://acad-server-1.onrender.com/api/v1/user-stats/total-questions`,
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            }
          );
          const totalQuestionsData = await totalQuestionsRes.json();
          setTotalQuestions(totalQuestionsData.totalQuestions);
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      };

      fetchData();
    }
  }, [user, navigate]);

  return (
    <div className="dashboard text-center pt-[16vh] h-screen">
      <p className="text-2xl font-bold text-[#1E2761]">Dashboard</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8 p-4 md:p-10 mx-auto max-w-screen-lg">
        <DashboardStatBox title="Total Users" value={totalUsers} />
        <DashboardStatBox title="Today Users" value={todayUsers} />
        <DashboardStatBox title="Monthly Users" value={monthlyUsers} />
        <DashboardStatBox title="Yearly Users" value={yearlyUsers} />
        <DashboardStatBox title="Total Questions" value={totalQuestions} />
      </div>
      <div className="flex flex-wrap justify-center gap-4 md:gap-8 p-4">
        <DashboardButton
          onClick={() => navigate("/admin/add-detailed-notes")}
          label="Add Notes"
        />
        <DashboardButton
          onClick={() => navigate("/admin/addquestion")}
          label="Add PYQs"
        />
        {/* <DashboardButton
          onClick={() => navigate("/feedback-messages")}
          label="Feedbacks"
        /> */}
        <DashboardButton
          onClick={() => navigate("/question-reports")}
          label="Reports"
        />
        <DashboardButton
          onClick={() => navigate("/admin/create-notification")}
          label="Create Update"
        />
      </div>
    </div>
  );
};

const DashboardStatBox = ({ title, value }) => (
  <div className="h-24 sm:h-32 border border-gray-500 bg-[#408EC6]/30 rounded-lg">
    <p className="m-5 text-xl font-bold text-[#1E2761]">{title}</p>
    <p className="m-5 text-2xl font-bold text-[#1E2761] hover:text-4xl cursor-pointer">
      {value}
    </p>
  </div>
);

const DashboardButton = ({ onClick, label }) => (
  <button
    className="bg-[#1E2761] active:scale-90 transition duration-500 transform hover:shadow-xl shadow-md rounded-full px-6 py-2 text-lg md:text-xl font-medium text-white"
    onClick={onClick}
    style={{ minWidth: "120px" }}
  >
    {label}
  </button>
);

export default Dashboard;
