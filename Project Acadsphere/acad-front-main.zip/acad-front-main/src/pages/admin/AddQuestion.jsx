import React, { useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import { NavLink } from "react-router-dom";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";

const AddQuestion = () => {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.target;
    const semester = form.semester.value;
    const branch = form.branch.value;
    const year = form.year.value;
    const subject = form.subject.value;
    const module = form.module.value;

    if (
      !semester ||
      !branch ||
      !year ||
      !subject ||
      !module ||
      !question ||
      !answer
    ) {
      toast.error("Please fill out all fields");
      return;
    }

    const questionData = {
      semester,
      branch,
      year,
      subject,
      module,
      question,
      answer,
    };

    try {
      const res = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/pyqs/addquestion`,
        questionData,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      if (res.data.success) {
        toast.success(res.data.message);
        form.reset();
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      toast.error("Failed to add question. Please try again later.");
    }
  };

  const handleQuestionChange = (value) => {
    setQuestion(value);
  };
  const handleAnswerChange = (value) => {
    setAnswer(value);
  };

  const modules = {
    toolbar: [
      [{ header: "1" }, { header: "2" }, { font: [] }],
      [{ size: [] }],
      ["bold", "italic", "underline", "strike", "blockquote"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link", "image"],
      [{ color: [] }, { background: [] }],
      [{ align: [] }],
      ["clean"], // removes formatting
    ],
  };

  return (
    <div className="addquestion mb-5">
      <div className="w-full mx-auto pt-[16vh]">
        <form
          className="ease-in duration-300 w-full sm:w-max shadow-sm backdrop-blur-md bg-white/80 lg:w-[800px] mx-auto rounded-md px-8 py-5"
          onSubmit={handleSubmit}
        >
          <NavLink to="/" className="flex mb-4 items-center justify-center">
            <img
              src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgdZPjmVZIjumxmsOsENuliphIkXFOykMdtYkfFJyZlkGiQmnab3nQPhKYEji9G28wORKLx5wzWirQq8Yc8mzOPq8bFsroyKe7Uv_9onP406X7VXtlw1R5oYhkErM-vphB_3Kw5vmwJ1hfcGYXOfzlN5DkqE-ZEG8k2RGK25mfjw5AC2pqKG3xRSI6siMY/s1600/logo.webp"
              alt="logo"
              className="logo h-14 w-14 cursor-pointer text-center"
            />
            <h1 className="text-[#191919] text-2xl font-mono">Acadsphere</h1>
          </NavLink>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="semester"
            >
              <option selected disabled>
                select semester
              </option>
              {/* <option>First</option> */}
              <option>Second</option>
              <option>Third</option>
              <option>Fourth</option>
              <option>Fifth</option>
              <option>Sixth</option>
              <option>Seventh</option>
              <option>Eighth</option>
            </select>

            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="branch"
            >
              <option selected disabled>
                select branch
              </option>
              {/* <option>CSE</option> */}
              {/* <option>EEE</option>*/}
              <option>CIVIL</option>
              <option>MECH</option>
            </select>

            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="year"
            >
              <option selected disabled>
                select year
              </option>
              {/* <option>2023</option> */}
              <option>2022</option>
              <option>2021</option>
              <option>2020</option>
              <option>2019</option>
              <option>2018</option>
            </select>
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs"
              name="subject"
            >
              <option selected disabled>
                select subject
              </option>

              {/* <option>Workshop</option> */}
              <option>Maths</option>
              <option>PPS</option>
              <option>Chemistry</option>
              <option>BEE</option>
              <option>Physics</option>
              <option>Analog Circuits</option>
              <option>DSA</option>
              <option>OOPS (C++)</option>
              <option>E.Circuit Analysis</option>
              <option>Digital Electronics</option>
              <option>Electrical Machines-I</option>
              <option>Electromagnetic Fields</option>
              <option>Engineering Mechanics</option>
              <option>Basic Electronics</option>
              <option>Biology</option>
              <option>Humanities</option>
              <option>Thermodynamics</option>
            </select>
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
              name="module"
            >
              <option selected disabled>
                select module
              </option>
              {/* <option>Module 1</option>
              <option>Module 2</option> */}
              <option>Module 3a</option>
              <option>Module 3b</option>
              <option>Module 3c</option>
              <option>Module 3d</option>
              <option>Module 4a</option>
              <option>Module 4b</option>
              <option>Module 4c</option>
              <option>Module 5a</option>
              <option>Module 5b</option>
              <option>Module 6</option>
              <option>Module 7</option>
              <option>Module 8</option>
              <option>Module 9</option>
              <option>Module 10</option>
            </select>
          </div>

          <div className="space-y-8 py-6">
            <div className="space-y-4">
              <label
                htmlFor="question"
                className="text-lg font-semibold text-gray-800"
              >
                Question (LaTeX Format)
              </label>
              <div className="border-2 border-blue-300 rounded-lg shadow-md overflow-hidden">
                <ReactQuill
                  value={question}
                  onChange={handleQuestionChange}
                  modules={modules}
                  className="p-4 text-gray-800 h-[20rem]" // Increased padding and height
                  name="question"
                  placeholder="Type your question here..."
                  style={{
                    minHeight: "20rem",
                    whiteSpace: "pre-wrap",
                    borderRadius: "8px",
                  }}
                />
              </div>
            </div>

            <div className="space-y-4">
              <label
                htmlFor="answer"
                className="text-lg font-semibold text-gray-800"
              >
                Answer (LaTeX Format)
              </label>
              <div className="border-2 border-blue-300 rounded-lg shadow-md overflow-hidden">
                <ReactQuill
                  value={answer}
                  onChange={handleAnswerChange}
                  modules={modules}
                  className="p-4 text-gray-800 h-[20rem]" // Increased padding and height
                  name="answer"
                  placeholder="Type your answer here..."
                  style={{
                    minHeight: "20rem",
                    whiteSpace: "pre-wrap",
                    borderRadius: "8px",
                  }}
                />
              </div>
            </div>
          </div>

          <button
            className="bg-[#1E2761] active:scale-90 transition duration-150 transform hover:shadow-xl shadow-md w-full rounded-full px-6 py-2 text-xl font-medium text-white mx-auto text-center mb-3 mt-5 whitespace-pre-line"
            type="submit"
          >
            Add Question
          </button>
          <ToastContainer />
        </form>
      </div>
    </div>
  );
};

export default AddQuestion;
