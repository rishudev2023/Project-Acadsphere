import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import { BrowserRouter } from "react-router-dom";
import { UserProvider } from "../context/userContext.jsx";
import { QuestionProvider } from "../context/questionContext.jsx";
import { FeedbackProvider } from "../context/feedbackContext.jsx";
import { SubjectProvider } from "../context/subjectsContext.jsx";
import { ReportsProvider } from "../context/questionReportContext.jsx";
import { PostProvider } from "../context/postContext.jsx";
import { CommentProvider } from "../context/commentContext.jsx";
import { ThemeProvider } from "../context/ThemeContext.jsx";
import "react-toggle/style.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <UserProvider>
        <QuestionProvider>
          <FeedbackProvider>
            <SubjectProvider>
              <ReportsProvider>
                <PostProvider>
                  <CommentProvider>
                    <ThemeProvider>
                      <App />
                    </ThemeProvider>
                  </CommentProvider>
                </PostProvider>
              </ReportsProvider>
            </SubjectProvider>
          </FeedbackProvider>
        </QuestionProvider>
      </UserProvider>
    </BrowserRouter>
  </React.StrictMode>
);
