import React, { useState, useEffect } from "react";

const OfflineMessage = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const handleRetryClick = () => {
    window.location.reload(); // Reload the app when retry button is clicked
  };

  return (
    <div
      className={`fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-75 z-50 ${
        isOnline ? "hidden" : ""
      }`}
    >
      <div className="bg-white p-6 rounded-lg shadow-lg text-center max-w-md w-full mx-4">
        <img
          src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgdZPjmVZIjumxmsOsENuliphIkXFOykMdtYkfFJyZlkGiQmnab3nQPhKYEji9G28wORKLx5wzWirQq8Yc8mzOPq8bFsroyKe7Uv_9onP406X7VXtlw1R5oYhkErM-vphB_3Kw5vmwJ1hfcGYXOfzlN5DkqE-ZEG8k2RGK25mfjw5AC2pqKG3xRSI6siMY/s1600/logo.webp"
          alt="Offline Icon"
          className="w-16 mx-auto mb-4"
        />
        <h2 className="text-2xl font-bold mb-2">Offline</h2>
        <p className="text-gray-600 mb-4">
          You are currently offline. Please check your internet connection and
          try again.
        </p>
        <button
          onClick={handleRetryClick}
          className="bg-[#1E2761] text-white px-4 py-2 rounded-full hover:bg-[#7A2048] focus:outline-none"
        >
          Retry
        </button>
      </div>
    </div>
  );
};

export default OfflineMessage;
