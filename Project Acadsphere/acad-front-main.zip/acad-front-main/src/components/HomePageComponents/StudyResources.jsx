import React from "react";
import { useInView } from "react-intersection-observer";
import "../../utils/StudyResources.css";

const StudyResources = () => {
  const resources = [
    {
      title: "Chapterwise PYQs",
      description:
        "Access detailed solutions for chapterwise previous year questions to make your preparation easy.",
      icon: "📖",
      bgColor: "bg-blue-100",
    },
    {
      title: "Yearwise PYQs",
      description:
        "Find yearwise previous year questions with solutions to streamline your study process.",
      icon: "📅",
      bgColor: "bg-yellow-100",
    },
    {
      title: "Mark Important Questions",
      description:
        "Identify and focus on important questions marked for their relevance and frequency in exams.",
      icon: "⭐",
      bgColor: "bg-green-100",
    },
  ];

  return (
    <section className="py-12">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold text-[#1E2761] mb-4">
          Study Resources
        </h2>
        <p className="text-lg text-gray-600 mb-8">
          A diverse array of learning materials to enhance your educational
          journey.
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          {resources.map((resource, index) => (
            <ResourceCard key={index} resource={resource} />
          ))}
        </div>
      </div>
    </section>
  );
};

const ResourceCard = ({ resource }) => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <div
      ref={ref}
      className={`p-6 ${
        resource.bgColor
      } border border-gray-300 rounded-lg shadow-sm transition-transform duration-500 ease-in-out ${
        inView
          ? "transform translate-y-0 opacity-100"
          : "transform translate-y-10 opacity-0"
      }`}
    >
      <div className="text-5xl mb-2">{resource.icon}</div>
      <h3 className="font-semibold text-xl mb-2">{resource.title}</h3>
      <p className="text-gray-700">{resource.description}</p>
    </div>
  );
};

export default StudyResources;
