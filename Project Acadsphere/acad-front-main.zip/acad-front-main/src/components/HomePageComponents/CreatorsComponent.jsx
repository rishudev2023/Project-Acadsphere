import React from "react";
import { useNavigate } from "react-router-dom";

const CreatorsComponent = () => {
  const navigate = useNavigate();
  return (
    <div>
      <section className="bg-gray-100 py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-[#1E2761] mb-4">
            Our Knowledge Architect Community
          </h2>
          <p className="text-base md:text-lg lg:text-xl text-gray-700 mb-8">
            Helping students success by sharing our knowledge and expertise.
          </p>
          {/* <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <div className="p-6 bg-white border border-gray-300 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
              <div className="text-blue-500 mb-2">🔍</div>
              <h3 className="font-semibold text-xl mb-2">Visibility</h3>
              <p className="text-gray-700">
                Showcase your expertise to a large audience.
              </p>
            </div>
            <div className="p-6 bg-white border border-gray-300 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
              <div className="text-blue-500 mb-2">🌟</div>
              <h3 className="font-semibold text-xl mb-2">Impact</h3>
              <p className="text-gray-700">
                Make a difference in students' academic journeys.
              </p>
            </div>
            <div className="p-6 bg-white border border-gray-300 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
              <div className="text-blue-500 mb-2">🏆</div>
              <h3 className="font-semibold text-xl mb-2">Rewards</h3>
              <p className="text-gray-700">
                Earn recognition and monetary rewards for your contributions.
              </p>
            </div>
          </div>
          <button
            className="bg-[#1E2761] text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700 transition duration-300 mt-16"
            onClick={() => {
              navigate("/knowledge-architect/register");
            }}
          >
            Join Now
          </button> */}
          <div className="mt-12">
            <h3 className="text-xl md:text-xl lg:text-xl font-bold text-[#7A2048] mb-6">
              What Our Top Architects Say?
            </h3>
            <div className="flex flex-col md:flex-row justify-center gap-6">
              <blockquote className="w-full md:w-1/2 p-6 bg-white border border-gray-300 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
                <p className="text-gray-700">
                  "Working as a Knowledge Architect at Acadsphere has been
                  incredibly rewarding. I love the creative freedom to develop
                  and share educational content that genuinely helps students.
                  Seeing my contributions make a real difference in academic
                  success is immensely satisfying!"
                </p>
                <cite className="block mt-2 text-blue-500">- Nikita Rani</cite>
              </blockquote>
              <blockquote className="w-full md:w-1/2 p-6 bg-white border border-gray-300 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
                <p className="text-gray-700">
                  "Acadsphere offers a dynamic and collaborative environment
                  where every Knowledge Architect's voice is heard. The team's
                  support and the opportunity to collaborate on innovative
                  educational resources make it an inspiring place to work."
                </p>
                <cite className="block mt-2 text-blue-500">- Alok Kumar</cite>
              </blockquote>
              <blockquote className="w-full md:w-1/2 p-6 bg-white border border-gray-300 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
                <p className="text-gray-700">
                  "The role of a Knowledge Architect at Acadsphere has provided
                  me with significant professional growth. The platform
                  recognizes and rewards our contributions, and I've appreciated
                  the opportunity to enhance my skills while impacting student
                  learning."
                </p>
                <cite className="block mt-2 text-blue-500">- Priya Kumari</cite>
              </blockquote>
              <blockquote className="w-full md:w-1/2 p-6 bg-white border border-gray-300 rounded-lg shadow-sm hover:shadow-lg transition-shadow">
                <p className="text-gray-700">
                  "As a Knowledge Architect with Acadsphere, I find it
                  fulfilling to contribute to a platform that enhances student
                  learning. The role allows me to share my expertise and see the
                  positive outcomes of my work in the academic journeys of
                  countless students."
                </p>
                <cite className="block mt-2 text-blue-500">- Anmol Pandey</cite>
              </blockquote>
            </div>
          </div>
          {/* <div className="mt-12">
            <h3 className="text-xl md:text-xl lg:text-xl font-bold text-[#7A2048] mb-6">
              How It Works
            </h3>
            <ol className="list-decimal list-inside text-gray-700 space-y-2">
              <li>Sign Up: Create an account and join our community.</li>
              <li>
                Submit Content: Share your questions, solutions, and tutorials.
              </li>
              <li>
                Earn Rewards: Gain recognition and rewards for your
                contributions.
              </li>
            </ol>
          </div> */}
          <div className="mt-12">
            <div className="text-center text-lg font-semibold text-gray-700">
              <p>
                Total Content Created:{" "}
                <span className="text-blue-500">3000+</span>
              </p>
              <p>
                Students Helped: <span className="text-blue-500">1000+</span>
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CreatorsComponent;
