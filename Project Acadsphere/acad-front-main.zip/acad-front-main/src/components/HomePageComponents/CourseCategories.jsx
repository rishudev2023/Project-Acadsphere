import React from "react";
import { FaArrowRightLong, FaBolt } from "react-icons/fa6";
import { useNavigate } from "react-router-dom";

import {
  FaBuilding,
  FaCogs,
  FaPlug,
  FaSatelliteDish,
  FaTachometerAlt,
  FaFireExtinguisher,
} from "react-icons/fa";

import { LiaLaptopCodeSolid } from "react-icons/lia";

const CourseCategories = () => {
  const navigate = useNavigate();
  const topCourses = [
    { name: "Computer Science Engineering", icon: <LiaLaptopCodeSolid /> },
    { name: "Electrical Engineering", icon: <FaBolt /> },
    { name: "Mechanical Engineering", icon: <FaCogs /> },
    { name: "Civil Engineering", icon: <FaBuilding /> },
    { name: "Electrical and Electronics Engineering", icon: <FaPlug /> },
    {
      name: "Electronics and Communication Engineering",
      icon: <FaSatelliteDish />,
    },
    { name: "Instrumentation Engineering", icon: <FaTachometerAlt /> },
    { name: "Fire Technology", icon: <FaFireExtinguisher /> },
  ];

  return (
    <div className="text-center py-10 bg-[#F0F0F0]">
      <p className="text-[#1E2761] inline-block py-2 px-4 rounded-lg text-3xl font-bold mb-10">
        Top Undergraduate Courses
      </p>
      <div className="bg-white rounded-lg shadow-lg p-10 mx-auto max-w-5xl">
        <ul className="space-y-4 text-left text-gray-700 mb-8">
          {topCourses.map((course, index) => (
            <li
              key={index}
              className="flex items-center gap-4 border-b border-gray-200 pb-2"
            >
              <span className="text-[#1E2761] h-6 w-6">{course.icon}</span>
              <span className="text-lg font-medium">{course.name}</span>
            </li>
          ))}
        </ul>
        {/* <div className="flex justify-center mt-8">
          <button
            className="bg-[#1E2761] text-white p-3 font-bold flex items-center gap-2 transition-colors duration-300 hover:bg-[#141b52] rounded-md"
            onClick={() => {
              navigate("/explore");
            }}
          >
            <span>Explore Now</span>
            <FaArrowRightLong className="h-5 w-5" />
          </button>
        </div> */}
      </div>
    </div>
  );
};

export default CourseCategories;
