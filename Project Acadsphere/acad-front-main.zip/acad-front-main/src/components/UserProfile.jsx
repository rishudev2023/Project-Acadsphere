import React from "react";
import { useUserContext } from "../../context/userContext";
import { useNavigate } from "react-router-dom";

const UserProfile = () => {
  const navigate = useNavigate();
  const { user } = useUserContext();

  return (
    <div className="bg-[#F3F4F6] min-h-screen py-10 pt-[16vh]">
      <div className="max-w-lg mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="flex flex-col items-center py-8 px-6">
          <img
            className="border border-[#1E2761] rounded-full h-32 w-32 object-cover mb-4"
            src={
              user?.user?.profileImage ||
              "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEij_QwxFJUVyCwcPaECXCGiR7sLfuLj7xgfbujN_SRYUh6_ff4Qdst8mRlUsL8Ksd8CgKRDeGCEALDtxD_2OecpXyPSKs86_adG3a-T0SmdZ9tI12usAvmnnG6rLkOwWFlvsqD-_eQJunkzGSdwTXVkRKj0OGte8gLpTiD6Wv7lSmOu843JTCtTy-I-dHU/s320/de6e8d53598eecfb6a2d86919b267791.jpg"
            }
            alt="Profile"
          />
          <h2 className="text-3xl font-semibold text-[#1E2761] mb-2">
            {user?.user.name}
          </h2>
          {/* <p className="text-lg text-gray-600 italic mb-6">
            {user?.user.email}
          </p> */}
          <div className="w-full px-4">
            <div className="flex flex-col gap-4 mb-6">
              <div className="flex justify-between">
                <span className="font-semibold text-[#1E2761] text-lg">
                  College:
                </span>
                <p className="text-gray-700 text-lg italic">
                  {user?.user.college}
                </p>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold text-[#1E2761] text-lg">
                  Semester:
                </span>
                <p className="text-gray-700 text-lg italic">
                  {user?.user.semester}
                </p>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold text-[#1E2761] text-lg">
                  Branch:
                </span>
                <p className="text-gray-700 text-lg italic">
                  {user?.user.branch}
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <button
                className="bg-[#1E2761] text-white py-2 px-4 rounded-lg font-bold shadow-md hover:bg-[#172a54] transition duration-200"
                onClick={() => {
                  navigate(`/user/${user?.user._id}/edit-profile`);
                }}
              >
                Edit Profile
              </button>
              <button
                className="bg-red-600 text-white py-2 px-4 rounded-lg font-bold shadow-md hover:bg-red-700 transition duration-200"
                onClick={() => {
                  localStorage.clear();
                  navigate("/");
                  location.reload();
                }}
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
