import React from "react";
import Modal from "react-modal";
import ReportQuestion from "./ReportQuestion";
import { RxCross2 } from "react-icons/rx";

Modal.setAppElement("#root"); // Bind modal to the root of the app

const ReportModal = ({ isOpen, onRequestClose, questionId, userId }) => {
  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Report Modal"
      className="Modal"
      overlayClassName="Overlay"
    >
      <ReportQuestion questionId={questionId} userId={userId} />
      <button
        onClick={onRequestClose}
        className="mt-4 bg-[#7A2048] text-white px-4 py-2 rounded"
      >
        Close
      </button>
    </Modal>
  );
};

export default ReportModal;
