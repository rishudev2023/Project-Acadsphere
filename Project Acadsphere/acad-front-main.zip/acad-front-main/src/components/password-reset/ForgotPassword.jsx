import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { CiLock } from "react-icons/ci";
import { Link } from "react-router-dom";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e) => {
    const emailValue = e.target.value;
    setEmail(emailValue);
    setIsButtonDisabled(emailValue.trim() === "");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    const form = e.target;
    const userData = { email };

    fetch(`https://acad-server-1.onrender.com/api/v1/user/forgot-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userData),
    })
      .then((res) => res.json())
      .then((data) => {
        setIsLoading(false);
        if (data.success) {
          // localStorage.setItem("token", data.data.token);
          toast.success(data.message);
          form.reset();
          setEmail(""); // Clear email state
          setIsButtonDisabled(true); // Disable button after form reset
        } else {
          toast.error(data.message);
        }
      })
      .catch((error) => {
        setIsLoading(false);
        console.log(error);
        toast.error("Something went wrong. Please try again.");
      });
  };

  return (
    <div className="flex justify-center items-center min-h-screen">
      <form
        onSubmit={handleSubmit}
        className="bg-white/80 p-8 rounded-lg shadow-lg w-full max-w-md"
      >
        <div className="flex justify-center items-center gap-4 mb-4 p-3">
          <CiLock className="text-6xl text-[#1E2761]" />
          <h2 className="text-2xl font-semibold text-center">
            Forgot Password?
          </h2>
        </div>
        <p className="text-sm text-gray-600 py-4 text-center">
          Enter your email and we'll send you a link to reset your password.
        </p>
        <input
          type="email"
          name="email"
          value={email}
          onChange={handleInputChange}
          placeholder="Enter your email"
          className="w-full p-2 mb-4 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#1E2761]"
        />
        <button
          type="submit"
          className={`w-full bg-[#1E2761] text-white py-2 rounded-full transition-opacity duration-300 ${
            isButtonDisabled
              ? "opacity-50 cursor-not-allowed"
              : "hover:opacity-90"
          }`}
          disabled={isButtonDisabled}
        >
          {isLoading ? (
            <div className="flex justify-center items-center">
              <svg
                className="animate-spin h-5 w-5 mr-3 text-white"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Processing...
            </div>
          ) : (
            "Get Reset Link"
          )}
        </button>

        <ToastContainer />

        <p className="text-center text-xl py-4 text-[#1E2761] font-semibold">
          OR
          <hr />
        </p>

        <div className="text-center">
          <Link
            to="/login"
            className="text-[#408EC6] font-semibold px-4 rounded transition-colors duration-300 hover:text-[#1E2761]"
          >
            Back to Login
          </Link>
        </div>
      </form>
    </div>
  );
};

export default ForgotPassword;
