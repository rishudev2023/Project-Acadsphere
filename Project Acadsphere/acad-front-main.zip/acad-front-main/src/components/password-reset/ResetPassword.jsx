import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { CiLock } from "react-icons/ci";
import { FaEye, FaEyeSlash } from "react-icons/fa";

const ResetPassword = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handlePasswordVisibilityToggle = () => {
    setShowPassword(!showPassword);
  };

  useEffect(() => {
    setIsButtonDisabled(password.trim() === "");
  }, [password]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch(
        `https://acad-server-1.onrender.com/api/v1/user/reset-password`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ password, token }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to reset password.");
      }
      const data = await response.json();
      toast.success(data.message);
      setTimeout(() => {
        navigate("/login");
      }, 2000);
    } catch (error) {
      console.log(error);
      toast.error(error.message || "Failed to reset password.");
      setTimeout(() => {
        navigate("/accounts/forgot-password");
      }, 2000);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen">
      <form
        onSubmit={handleSubmit}
        className="bg-white/80 p-8 rounded-lg shadow-lg w-full max-w-md"
      >
        <div className="flex justify-center items-center gap-4 mb-4 p-3">
          <CiLock className="text-6xl text-[#1E2761]" />
          <h2 className="text-2xl font-semibold text-center">Reset Password</h2>
        </div>
        <p className="text-sm text-gray-600 py-4 text-center">
          Enter your new password to reset your account.
        </p>
        <div className="relative">
          {" "}
          {/* Ensure the relative positioning */}
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Enter new password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-2 mb-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#1E2761]"
            required
          />
          <button
            type="button"
            className="absolute right-4 top-3 text-gray-400 focus:outline-none"
            onClick={handlePasswordVisibilityToggle}
          >
            {showPassword ? <FaEyeSlash /> : <FaEye />}{" "}
          </button>
        </div>
        <p className="text-sm text-gray-600 mb-6">
          Enter a strong 8 digit password.
        </p>
        <button
          type="submit"
          className={`w-full bg-[#1E2761] text-white py-2 rounded-full transition-opacity duration-300 ${
            isButtonDisabled
              ? "opacity-50 cursor-not-allowed"
              : "hover:opacity-90"
          }`}
          disabled={isButtonDisabled || isLoading}
        >
          {isLoading ? (
            <div className="flex justify-center items-center">
              <svg
                className="animate-spin h-5 w-5 mr-3 text-white"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Processing...
            </div>
          ) : (
            "Reset Password"
          )}
        </button>

        <ToastContainer />
      </form>
    </div>
  );
};

export default ResetPassword;
