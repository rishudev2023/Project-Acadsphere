import React from "react";
import { useNavigate } from "react-router-dom";
import { FaBook, FaCalendar, FaStar } from "react-icons/fa";
import { IoMdArrowForward } from "react-icons/io";
import { useUserContext } from "../../context/userContext";

const StudyMode = () => {
  const navigate = useNavigate();
  const { user } = useUserContext();

  return (
    <div className="bg-[#F3F4F6] min-h-screen py-10 pt-[14vh]">
      <div className="max-w-4xl mx-auto p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-semibold text-[#1E2761]">
              Hi,{" "}
              <span className="italic text-[#7A2048]">{user?.user?.name}!</span>
            </h2>
            <p className="text-[#408EC6] mt-2">Happy to see you here!</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {/* Cards */}
          <div className="bg-[#1E2761] text-white rounded-lg shadow-lg p-6 flex flex-col items-center">
            <FaBook className="text-4xl mb-4" />
            <h3 className="text-xl font-semibold mb-4">Chapterwise PYQs</h3>
            <p className="text-lg mb-4 text-center">
              Practice chapterwise previous year questions for better
              preparation.
            </p>
            <button
              className="flex items-center gap-2 bg-white active:scale-90 transition duration-300 transform hover:shadow-xl shadow-md rounded-md px-4 py-2 text-md font-medium text-[#1E2761]"
              onClick={() => {
                navigate("/study-mode/chapterwise-pyqs");
              }}
            >
              Get started <IoMdArrowForward size={18} />
            </button>
          </div>
          <div className="bg-[#1E2761] text-white rounded-lg shadow-lg p-6 flex flex-col items-center">
            <FaCalendar className="text-4xl mb-4" />
            <h3 className="text-xl font-semibold mb-4">Yearly PYQs</h3>
            <p className="text-lg mb-4 text-center">
              Explore yearly previous year questions to evaluate your
              preparation.
            </p>
            <button
              className="flex items-center gap-2 bg-white active:scale-90 transition duration-300 transform hover:shadow-xl shadow-md rounded-md px-4 py-2 text-md font-medium text-[#1E2761]"
              onClick={() => {
                navigate("/study-mode/yearly-pyqs");
              }}
            >
              Get started <IoMdArrowForward size={18} />
            </button>
          </div>
          <div className="bg-[#1E2761] text-white rounded-lg shadow-lg p-6 flex flex-col items-center">
            <FaStar className="text-4xl mb-4" />
            <h3 className="text-xl font-semibold mb-4">Important Questions</h3>
            <p className="text-lg mb-4 text-center">
              Here are your important questions to focus on.
            </p>
            <button
              className="flex items-center gap-2 bg-white active:scale-90 transition duration-300 transform hover:shadow-xl shadow-md rounded-md px-4 py-2 text-md font-medium text-[#1E2761]"
              onClick={() => {
                navigate("/study-mode/important-questions");
              }}
            >
              Continue <IoMdArrowForward size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudyMode;
