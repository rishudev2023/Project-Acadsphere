// SubjectSidebar.jsx

import React from "react";
import { Link } from "react-router-dom";

const SubjectSidebar = () => {
  return (
    <div className="w-1/5 bg-gray-200 h-full p-4">
      <h2 className="text-lg font-semibold mb-4">Subjects</h2>
      <ul>
        <li className="mb-2">
          <Link
            to="/question-reports?subject=Mathematics"
            className="text-blue-500 hover:underline"
          >
            Mathematics
          </Link>
        </li>
        <li className="mb-2">
          <Link
            to="/question-reports?subject=Physics"
            className="text-blue-500 hover:underline"
          >
            Physics
          </Link>
        </li>
        <li className="mb-2">
          <Link
            to="/question-reports?subject=Chemistry"
            className="text-blue-500 hover:underline"
          >
            Chemistry
          </Link>
        </li>
        <li className="mb-2">
          <Link
            to="/question-reports?subject=Chemistry"
            className="text-blue-500 hover:underline"
          >
            Physics
          </Link>
        </li>
        <li className="mb-2">
          <Link
            to="/question-reports?subject=Chemistry"
            className="text-blue-500 hover:underline"
          >
            BEE
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default SubjectSidebar;
