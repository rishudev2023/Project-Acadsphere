import React from "react";
import { useUserContext } from "../../context/userContext";
import { useNavigate } from "react-router-dom";
import StudyResources from "./HomePageComponents/StudyResources";
import CourseCategories from "./HomePageComponents/CourseCategories";
import CreatorsComponent from "./HomePageComponents/CreatorsComponent";
import { motion } from "framer-motion"; // Importing framer-motion

const Header = () => {
  const { user } = useUserContext();
  const navigate = useNavigate();

  // Framer-motion variants for animations
  const fadeInUp = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8 } },
  };

  const buttonHover = {
    scale: 1.05,
    boxShadow: "0px 4px 15px rgba(0, 0, 0, 0.2)",
  };

  return (
    <div className="px-4 md:px-6 lg:px-8 pt-[10vh]">
      <div className="container mx-auto flex flex-col lg:flex-row items-center lg:space-x-8 p-10">
        <motion.div
          className="flex-1 lg:w-1/2 flex flex-col space-y-6 lg:space-y-8"
          initial="hidden"
          animate="visible"
          variants={fadeInUp}
        >
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-[#408EC6]">
            Welcome <span className="text-[#1E2761]">to</span>{" "}
            <span className="text-[#7A2048]">Acadsphere</span>
          </h1>
          <p className="text-base md:text-lg lg:text-xl text-[#191919] leading-relaxed">
            Empowering Student Success: Dive into Acadsphere's vast collection
            of previous papers and solutions. Achieve your goals with ease and
            precision through our comprehensive study tools.
          </p>

          <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
            {user?.user.email === "rishugren03@gmail.com" &&
              user?.user &&
              user?.user.role === "admin" && (
                <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
                  <motion.button
                    className="bg-[#1E2761] text-white rounded-full px-6 py-2 text-lg font-medium shadow-md"
                    whileHover={buttonHover}
                    onClick={() => navigate("/admin/dashboard")}
                  >
                    Dashboard
                  </motion.button>
                  <motion.button
                    className="bg-[#1E2761] text-white rounded-full px-6 py-2 text-lg font-medium shadow-md"
                    whileHover={buttonHover}
                    onClick={() => navigate("/study-mode")}
                  >
                    Start study
                  </motion.button>
                </div>
              )}

            {user?.user &&
              user?.user.role === "admin" &&
              user?.user.email !== "rishugren03@gmail.com" && (
                <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
                  <motion.button
                    className="bg-[#1E2761] text-white rounded-full px-6 py-2 text-lg font-medium shadow-md"
                    whileHover={buttonHover}
                    onClick={() => navigate("/admin/addquestion")}
                  >
                    Add PYQs
                  </motion.button>
                  <motion.button
                    className="bg-[#1E2761] text-white rounded-full px-6 py-2 text-lg font-medium shadow-md"
                    whileHover={buttonHover}
                    onClick={() => navigate("/study-mode")}
                  >
                    Start study
                  </motion.button>
                </div>
              )}

            {!(user?.user && user?.user.role === "admin") &&
              !(user?.user.email === "rishugren03@gmail.com") && (
                <motion.button
                  className="bg-[#1E2761] text-white rounded-full px-6 py-2 text-lg font-medium shadow-md"
                  whileHover={buttonHover}
                  onClick={() => navigate("/study-mode")}
                >
                  Get Started
                </motion.button>
              )}
          </div>
        </motion.div>

        <motion.div
          className="mt-8 lg:mt-0 flex justify-center lg:justify-end flex-1"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          <img
            src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhXAm8Vqo6Ykj_VYmw7nKHlXDFrOW2an3J3OU2wTS3odDdvKYOFcnABeuM1gHfb5RX7BhxqXmUGO57LY9QThVDstO_gD94D1LJDjAuw5-Yl25ezOw10LYjwgqfBAwV_fWOD_gnyPyPnyTaPAmmc33BMY1USoYVMGFRQnn45T64LJ4g5lKElssxZRdATTQI/s500/hero-img.png"
            alt="Hero"
            className="w-full max-w-[35rem] h-[35rem] object-cover"
          />
        </motion.div>
      </div>
      <hr />
      <CreatorsComponent />
      <hr />
      <StudyResources className="mt-10" />
      <hr />
      <CourseCategories />
    </div>
  );
};

export default Header;
