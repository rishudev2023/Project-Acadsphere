import React, { useState } from "react";
import algoliasearch from "algoliasearch/lite";
import {
  InstantSearch,
  SearchBox,
  Hits,
  connectStateResults,
} from "react-instantsearch-dom";
import { useNavigate } from "react-router-dom";
import "./Search.css";
import { MathJax, MathJaxContext } from "better-react-mathjax";
import DisplayContent from "../components/DisplayContent";

const searchClient = algoliasearch(
  "M2XE0HTUMC",
  "84a3e266336126520b16d3bcd1f06cea"
);

const Hit = ({ hit }) => {
  const navigate = useNavigate();

  const navigateToQuestion = (questionId) => {
    navigate(`/view-solution/${questionId}`);
  };

  const mathJaxConfig = {
    loader: { load: ["[tex]/ams"] },
    tex: {
      packages: { "[+]": ["ams"] },
      inlineMath: [
        ["$", "$"],
        ["\\(", "\\)"],
      ],
      displayMath: [
        ["$$", "$$"],
        ["\\[", "\\]"],
      ],
      processEscapes: true,
      processEnvironments: true,
    },
  };

  return (
    <MathJaxContext config={mathJaxConfig}>
      <div
        className="p-3 border border-[#1E2761] rounded-lg bg-white cursor-pointer hover:bg-gray-100"
        onClick={() => navigateToQuestion(hit.objectID)}
      >
        <div className="font-bold text-sm text-[#1E2761]">Question:</div>
        <MathJax dynamic>
          <div className="text-sm whitespace-pre-wrap">
            <DisplayContent htmlContent={hit.question} />
          </div>
        </MathJax>
      </div>
    </MathJaxContext>
  );
};

const CustomSearchBox = ({ currentRefinement, refine }) => (
  <input
    type="search"
    value={currentRefinement}
    onChange={(event) => refine(event.currentTarget.value)}
    placeholder="Search..."
    className="p-3 bg-white rounded-full border border-gray-300 focus:outline-none focus:border-blue-500 w-full"
  />
);

const Results = connectStateResults(({ searchResults, children }) =>
  searchResults && searchResults.nbHits === 0 ? (
    <div className="text-center text-sm font-medium py-2">
      No results found.
    </div>
  ) : (
    children
  )
);

const Search = () => {
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearchChange = (event) => {
    const { value } = event.currentTarget;
    if (value.trim() !== "") {
      setHasSearched(true);
    } else {
      setHasSearched(false);
    }
  };

  return (
    <InstantSearch searchClient={searchClient} indexName="questions_index">
      <div className="relative w-[80%] mx-auto lg:mx-0">
        <SearchBox className="w-full px-4 py-2" onChange={handleSearchChange} />
        {hasSearched && (
          <div className="absolute top-full left-0 right-0 w-full bg-white border border-gray-200 shadow-lg rounded-lg mt-2 z-10 max-h-80 overflow-y-auto">
            <Results>
              <Hits hitComponent={Hit} />
            </Results>
          </div>
        )}
      </div>
    </InstantSearch>
  );
};

export default Search;
