import React, { useEffect, useState } from "react";
import axios from "axios";
import Notifications from "./Notifications";
import spinLoading from "./SpinLoading";
import { RxCross2 } from "react-icons/rx";
import { timeSince } from "../utils/timeSince";

const NotificationModal = ({ isOpen, onClose }) => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchNotifications = async () => {
    try {
      const response = await axios.get(
        "https://acad-server-1.onrender.com/api/v1/notifications/get-notifications",
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (response.data.success) {
        setNotifications(response.data.data);
      }
    } catch (err) {
      setError("Error fetching notifications. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchNotifications();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-end z-50">
      <div
        className="absolute inset-0 bg-black opacity-50"
        onClick={onClose}
      ></div>
      <div className="bg-white w-96 max-w-full h-full overflow-y-auto p-4">
        <button className="text-gray-800 float-right" onClick={onClose}>
          <RxCross2 />
        </button>
        <h2 className="text-lg font-bold mb-10">Notifications</h2>
        <hr />
        {loading ? (
          <spinLoading />
        ) : error ? (
          <p className="text-red-500">{error}</p>
        ) : notifications.length === 0 ? (
          <p>No notifications available.</p>
        ) : (
          <ul className="space-y-2">
            {notifications.map((notification) => (
              <li
                key={notification._id}
                className="border-b border-gray-300 p-2"
              >
                <h3 className="font-semibold">{notification.title}</h3>
                <p>{notification.message}</p>
                <p className="text-sm text-gray-500">
                  {timeSince(notification.createdAt)}
                </p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default NotificationModal;
