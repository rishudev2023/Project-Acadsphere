import React from "react";
import Search from "./Search";
import { useUserContext } from "../../context/userContext";

const SearchComponent = () => {
  const { user, setUser } = useUserContext();
  return (
    <div>
      <Search />
    </div>
  );
};

export default SearchComponent;
