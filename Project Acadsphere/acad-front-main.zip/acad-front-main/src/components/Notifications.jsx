import React, { useEffect, useState } from "react";
import axios from "axios";
import spinLoading from "./SpinLoading";

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchNotifications = async () => {
    try {
      const response = await axios.get(
        "https://acad-server-1.onrender.com/api/v1/notifications/get-notifications",
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (response.data.success) {
        setNotifications(response.data.data);
      }
    } catch (err) {
      setError("Error fetching notifications. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  const timeSince = (date) => {
    const now = new Date();
    const seconds = Math.floor((now - new Date(date)) / 1000);
    let interval = Math.floor(seconds / 31536000); // years
    if (interval >= 1) return `${interval} year${interval > 1 ? "s" : ""} ago`;
    interval = Math.floor(seconds / 2592000); // months
    if (interval >= 1) return `${interval} month${interval > 1 ? "s" : ""} ago`;
    interval = Math.floor(seconds / 86400); // days
    if (interval >= 1) return `${interval} day${interval > 1 ? "s" : ""} ago`;
    interval = Math.floor(seconds / 3600); // hours
    if (interval >= 1) return `${interval} hour${interval > 1 ? "s" : ""} ago`;
    interval = Math.floor(seconds / 60); // minutes
    if (interval >= 1)
      return `${interval} minute${interval > 1 ? "s" : ""} ago`;
    return "Just now";
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  return (
    <div className="min-h-screen pt-[16vh] bg-gray-50 flex flex-col items-center text-gray-800 p-4">
      <h2 className="text-2xl font-bold mb-6">Notifications</h2>
      {loading && <spinLoading />}
      {error && <p className="text-red-600 mb-4">{error}</p>}
      <div className="w-full max-w-2xl bg-white shadow-md rounded-lg p-4">
        <ul className="space-y-4">
          {notifications.map((notification) => (
            <li
              key={notification._id}
              className="border-b border-gray-300 pb-2 last:border-b-0"
            >
              <h3 className="font-semibold text-lg">{notification.title}</h3>
              <p className="text-gray-600">{notification.message}</p>
              <p className="text-xs text-gray-500">
                {/* Use the timeSince function to display time */}
                {timeSince(notification.createdAt)}
              </p>
            </li>
          ))}
          {notifications.length === 0 && !loading && (
            <p className="text-gray-500">No notifications available.</p>
          )}
        </ul>
      </div>
    </div>
  );
};

export default Notifications;
