import React from "react";

const MM2 = () => {
  return (
    <div>
      <span className="text-xl text-[#1E2761] font-[600]">Maths</span>
      <span className="text-xl font-[600]">/</span>
      <span className="text-xl font-[600] text-violet-500">
        Module 2 (Calculus)
      </span>
      <div className="mt-5 text-center text-darkblue-500 text-md justify-left">
        <p>Rolle's Theorem</p>
        <p>Mean Value Theorems</p>
        <p>Taylor's and Maclaurin Theorems with Reminders </p>
        <p>Intermediate Forms and L'Hospitals Rule</p>
        <p>Maxima and Minima</p>
      </div>
    </div>
  );
};

export default MM2;
