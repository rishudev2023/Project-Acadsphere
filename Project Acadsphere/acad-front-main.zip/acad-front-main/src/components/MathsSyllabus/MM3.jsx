import React from "react";

const MM3 = () => {
  return (
    <div>
      <span className="text-xl text-[#1E2761] font-[600]">Maths</span>
      <span className="text-xl font-[600]">/</span>
      <span className="text-xl font-[600] text-violet-500">
        Module 3 (Sequences and Series)
      </span>
      <div className="mt-5 text-center text-darkblue-500 text-md justify-left">
        <p>Convergence of Sequence and Series</p>
        <p>Test For Convergence</p>
        <p>Power Series, Taylor's Series </p>
        <p>Series for Trigonometric, Logorithmic Functions</p>
        <p>
          Fourier Series: Half Range Sine and Cosine Series, Parseval's Theorem
        </p>
      </div>
    </div>
  );
};

export default MM3;
