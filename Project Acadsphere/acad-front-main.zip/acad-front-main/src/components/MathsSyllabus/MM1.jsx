import React from "react";

const MM1 = () => {
  return (
    <div>
      <span className="text-xl text-[#1E2761] font-[600]">Maths</span>
      <span className="text-xl font-[600]">/</span>
      <span className="text-xl font-[600] text-violet-500">
        Module 1 (Calculus)
      </span>
      <div className="mt-5 text-center text-darkblue-500 text-md justify-left">
        <p>Evolutes and Involutes</p>
        <p>Evaluation of Definite and Improper Integrals</p>
        <p>Beta and Gamma functions and their properties</p>
        <p>
          Applications of definite integrals to Evaluate Surface Areas <br />{" "}
          and Volumes of Revolutions
        </p>
      </div>
    </div>
  );
};

export default MM1;
