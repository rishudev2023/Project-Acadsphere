import React, { useState } from "react";
import SyllabusSidebar from "./syllabusComponents/SubjectSidebar";
import SyllabusContent from "./syllabusComponents/SyllabusContent";
import MM1 from "./MathsSyllabus/MM1";
import MM2 from "./MathsSyllabus/MM2";
import MM3 from "./MathsSyllabus/MM3";

const Syllabus = () => {
  const subjects = ["Mathematics", "PPS", "Chemistry"];
  const subjectModules = {
    Mathematics: [1, 2, 3, 4, 5],
    PPS: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    Chemistry: [1, 2, 3, 4, 5, 6, 7],
  };

  const [selectedSubject, setSelectedSubject] = useState(subjects[0]);
  const [selectedModule, setSelectedModule] = useState(1);

  const handleSubjectSelect = (subject) => {
    setSelectedSubject(subject);
    setSelectedModule(subjectModules[subject][0]); // Select the first module when subject changes
  };

  const handleModuleSelect = (module) => {
    setSelectedModule(module);
  };

  // Mock syllabus content, replace with actual content or fetch from API
  const syllabusBody = {
    Mathematics: {
      1: <MM1 />,
      2: <MM2 />,
      3: <MM3 />,
    },
    PPS: {
      1: "Syllabus for Physics Module 1...",
      2: "Syllabus for Physics Module 2...",
      3: "Syllabus for Physics Module 3...",
      4: "Syllabus for Physics Module 4...",
      5: "Syllabus for Physics Module 5...",
      6: "Syllabus for Physics Module 6...",
      7: "Syllabus for Physics Module 7...",
      8: "Syllabus for Physics Module 8...",
      9: "Syllabus for Physics Module 9...",
      10: "Syllabus for Physics Module 10...",
    },
    Chemistry: {
      1: "Syllabus for Chemistry Module 1...",
      2: "Syllabus for Chemistry Module 2...",
      3: "Syllabus for Chemistry Module 3...",
      4: "Syllabus for Chemistry Module 4...",
    },
  };

  return (
    <div className="flex flex-col md:flex-row">
      <SyllabusSidebar
        subjects={subjects}
        selectedSubject={selectedSubject}
        subjectModules={subjectModules}
        onSubjectSelect={handleSubjectSelect}
        onModuleSelect={handleModuleSelect}
      />
      <SyllabusContent
        syllabus={syllabusBody[selectedSubject][selectedModule]}
      />
    </div>
  );
};

export default Syllabus;
