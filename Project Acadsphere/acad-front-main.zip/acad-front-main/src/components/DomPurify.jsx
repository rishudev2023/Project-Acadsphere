import React from "react";
import domPurify from "../utils/domPurify";

function DomPurify() {
  const dirtyInput =
    '<script>alert("XSS Attack!")</script><p>Hello, world!</p>';
  const cleanInput = domPurify(dirtyInput);

  return (
    <div className="Sanitize">
      <header className="Sanitize-header">
        <div dangerouslySetInnerHTML={{ __html: cleanInput }} />
      </header>
    </div>
  );
}

export default DomPurify;
