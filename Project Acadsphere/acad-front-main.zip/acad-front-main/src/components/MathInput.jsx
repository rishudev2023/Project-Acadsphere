import React, { useState } from "react";
import MathJax from "react-mathjax2";

const MathInputComponent = ({ label, value, onChange }) => {
  const handleInputChange = (e) => {
    onChange(e.target.value);
  };

  return (
    <div className="p-4 w-full">
      <label className="block text-gray-700 text-sm font-bold mb-2">
        {label}
      </label>
      <textarea
        className="textarea textarea-ghost shadow-sm bg-white appearance-none border rounded w-full py-3 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
        rows="4"
        value={value}
        onChange={handleInputChange}
        placeholder={`Enter your ${label.toLowerCase()} here...`}
      ></textarea>
      <div className="bg-gray-100 p-4 rounded mt-2">
        <MathJax.Context input="ascii">
          <div className="math-preview">
            <MathJax.Node>{value}</MathJax.Node>
          </div>
        </MathJax.Context>
      </div>
    </div>
  );
};

export default MathInputComponent;
