import React from "react";

const ComingSoon = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 via-blue-600 to-blue-300">
      <div className="max-w-md p-8 bg-white rounded-lg shadow-lg">
        <h1 className="text-4xl font-bold text-center mb-6">Coming Soon</h1>
        <p className="text-lg text-gray-700 mb-8">
          We're currently working on bringing you the content. Stay tuned!
        </p>
        <div className="flex justify-center">
          <div className="h-4 w-4 bg-purple-900 rounded-full mr-2"></div>
          <div className="h-4 w-4 bg-blue-900 rounded-full mr-2"></div>
          <div className="h-4 w-4 bg-green-900 rounded-full mr-2"></div>
        </div>
      </div>
    </div>
  );
};

export default ComingSoon;
