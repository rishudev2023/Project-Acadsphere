import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useUserContext } from "../../context/userContext";

const Feedback = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useUserContext();

  const handleOnSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const form = e.target;
    const name = form.name.value;
    const email = form.email.value;
    const message = form.message.value;

    const feedbackData = { name, email, message };

    fetch(
      "https://acad-server-1.onrender.com/api/v1/feedback/submit-feedback",
      {
        method: "POST",
        headers: {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          "Content-Type": "application/json",
        },
        body: JSON.stringify(feedbackData),
      }
    )
      .then((res) => res.json())
      .then((data) => {
        setIsLoading(false);
        if (data.success) {
          toast.success(data.message);
          form.reset();
        } else {
          toast.error(data.message);
        }
      })
      .catch((error) => {
        console.log(error);
        setIsLoading(false);
        toast.error("Something went wrong. Please try again.");
      });
  };

  return (
    <div className="flex justify-center items-center h-screen">
      <form
        className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md"
        onSubmit={handleOnSubmit}
      >
        <h2 className="text-2xl font-semibold text-center mb-4">
          Send Feedback
        </h2>
        <p className="text-center mb-4">
          We value your feedback to help us improve. Have suggestions? Want to
          join our team? Send us a message!
        </p>
        <input
          type="text"
          placeholder="Your Name"
          name="name"
          value={user?.user.name}
          className="w-full p-2 mb-4 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
          required
        />
        <input
          type="email"
          placeholder="Your Email"
          name="email"
          value={user?.user.email}
          className="w-full p-2 mb-4 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
          required
        />
        <textarea
          placeholder="Your Message"
          name="message"
          className="w-full p-2 mb-4 border rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
          required
        ></textarea>
        <button
          type="submit"
          className={`w-full bg-[#1E2761] text-white py-2 rounded-full transition-opacity duration-300 ${
            isLoading ? "opacity-50 cursor-not-allowed" : ""
          }`}
          disabled={isLoading}
        >
          {isLoading ? (
            <div className="flex justify-center items-center">
              <svg
                className="animate-spin h-5 w-5 mr-3 text-white"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              Sending...
            </div>
          ) : (
            "Send Feedback"
          )}
        </button>
        <ToastContainer />
      </form>
    </div>
  );
};

export default Feedback;
