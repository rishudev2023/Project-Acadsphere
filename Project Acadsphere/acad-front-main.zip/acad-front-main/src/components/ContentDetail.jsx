import React from "react";

const ContentDetail = () => {
  const pyqData = [
    {
      branch: "CSE",
      subjects: [
        { name: "MATHS", years: "2022, 2019 " },
        { name: "BEE", years: "2023, 2022, 2021" },
        { name: "PHYSICS", years: "2022, 2019" },
      ],
    },
    {
      branch: "MECH",
      subjects: [
        { name: "MATHS", years: "2017, 2019, 2021" },
        { name: "CHEM", years: "2018, 2020, 2022" },
        { name: "PPS", years: "2018, 2020, 2022" },
      ],
    },
    // Add more branches and subjects here
  ];

  // Find the branch-specific data based on user's branch
  const branchData = pyqData.find((branch) => branch.branch === userBranch);

  return (
    <div className="pyq-table-container p-4">
      {branchData ? (
        <div className="branch-section mb-6">
          <h2 className="branch-title text-lg font-bold mb-2">
            {branchData.branch}
          </h2>
          <table className="table-auto w-full border-collapse border border-gray-300">
            <thead>
              <tr>
                <th className="border border-gray-300 px-4 py-2">Subjects</th>
                <th className="border border-gray-300 px-4 py-2">
                  Years Available
                </th>
              </tr>
            </thead>
            <tbody>
              {branchData.subjects.map((subject, subjectIndex) => (
                <tr key={subjectIndex}>
                  <td className="border border-gray-300 px-4 py-2">
                    {subject.name}
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    {subject.years}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p>No PYQs available for your branch.</p>
      )}
    </div>
  );
};

export default ContentDetail;
