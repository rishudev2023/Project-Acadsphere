import React from "react";
import sanitize from "../utils/sanitizeHtml";

function Sanitize() {
  const dirtyInput =
    '<script>alert("XSS Attack!")</script><p>Hello, world!</p>';
  const cleanInput = sanitize(dirtyInput);

  return (
    <div className="App">
      <header className="App-header">
        <div dangerouslySetInnerHTML={{ __html: cleanInput }} />
      </header>
    </div>
  );
}

export default Sanitize;
