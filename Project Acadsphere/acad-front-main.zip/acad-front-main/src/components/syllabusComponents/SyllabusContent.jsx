import React from "react";

const SyllabusContent = ({ syllabus }) => {
  return (
    <div className="content text-center p-4 md:w-3/4">
      <div>{syllabus}</div>
    </div>
  );
};

export default SyllabusContent;
