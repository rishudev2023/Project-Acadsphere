import React, { useState } from "react";

const SubjectSidebar = ({
  subjects,
  selectedSubject,
  subjectModules,
  onSubjectSelect,
  onModuleSelect,
}) => {
  const [selectedModule, setSelectedModule] = useState(1);

  const handleModuleSelect = (module) => {
    setSelectedModule(module);
    onModuleSelect(module);
  };

  return (
    <div className="sidebar bg-[#1E2761] text-white h-full w-full md:w-1/4 md:relative overflow-y-auto">
      <div className="p-4">
        <h2 className="text-lg font-semibold mb-4">Subjects</h2>
        {subjects.map((subject, index) => (
          <div
            key={index}
            className={`p-2 cursor-pointer ${
              selectedSubject === subject ? "bg-[#408EC6]" : ""
            }`}
            onClick={() => onSubjectSelect(subject)}
          >
            {subject}
          </div>
        ))}
      </div>
      {selectedSubject && (
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-4">Modules</h2>
          {subjectModules[selectedSubject].map((module, index) => (
            <div
              key={index}
              className={`p-2 cursor-pointer ${
                selectedModule === module ? "bg-[#408EC6]" : ""
              }`}
              onClick={() => handleModuleSelect(module)}
            >
              Module {module}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SubjectSidebar;
