import React from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";

const CreatePost = () => {
  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.target;
    const text = form.text.value;

    if (!text) {
      toast.error("This field is required!");
      return;
    }

    const postData = {
      text,
    };

    try {
      const res = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/community/create-post`,
        postData,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      if (res.data.success) {
        toast.success(res.data.message);
        form.reset();
        location.reload();
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      console.error("Error:", error); // Log the error
      toast.error("Failed to add question. Please try again later.");
    }
  };

  return (
    <div className="createpost mb-8">
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover={false}
        draggable
        pauseOnFocusLoss={false}
      />
      <div className="w-full max-w-2xl mx-auto pt-8 px-4 sm:px-0">
        <form
          onSubmit={handleSubmit}
          className="bg-white shadow-lg rounded-md p-4 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-2"
        >
          <textarea
            name="text"
            rows="5"
            placeholder="What's on your mind?"
            className="w-full sm:h-16 h-20 p-4 resize-none border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#1E2761] transition-all"
          />
          <button
            type="submit"
            className="bg-[#1E2761] hover:bg-[#16204b] text-white px-6 py-2 rounded-full font-semibold transition-all duration-300 w-full sm:w-auto sm:ml-2"
          >
            Post
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreatePost;
