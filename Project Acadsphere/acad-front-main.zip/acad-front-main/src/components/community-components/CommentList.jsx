import React, { useEffect, useState } from "react";
import { FaHeart, FaRegHeart } from "react-icons/fa";
import { AiOutlineDelete } from "react-icons/ai";
import axios from "axios"; // For API calls
import { timeSince } from "../../utils/timeSince";
import { useCommentContext } from "../../../context/commentContext";
import SpinLoading from "../SpinLoading";
import { useUserContext } from "../../../context/userContext";
import { useParams } from "react-router-dom";
import DeleteModal from "./DeleteModal";

const CommentList = () => {
  const { Comment, setComment } = useCommentContext();
  const [loading, setLoading] = useState(true);
  const { postId } = useParams();
  const { user } = useUserContext();
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const openDeleteModal = () => setShowDeleteModal(true);

  const closeDeleteModal = () => setShowDeleteModal(false);

  const fetchComment = async () => {
    try {
      const response = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}/comments`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      // Ensure that response.data is an array and update state
      setComment(Array.isArray(response.data) ? response.data : []);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching comments:", error);
      setLoading(false);
    }
  };

  // Like a comment
  const likeComment = async (commentId) => {
    try {
      await axios.post(
        `https://acad-server-1.onrender.com/api/v1/community/comment/${commentId}/like`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data.success) {
        setComment((prevComment) =>
          prevComment.map((comment) =>
            comment._id === commentId
              ? { ...comment, likes: [...comment.likes, user._id] }
              : comment
          )
        );
      }
    } catch (error) {
      console.error("Error liking comment:", error);
    }
  };

  // Delete a comment
  const deleteComment = async (commentId) => {
    try {
      await axios.delete(
        `https://acad-server-1.onrender.com/api/v1/community/comment/${commentId}`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data.success) {
        setComment((prevComment) =>
          prevComment.filter((comment) => comment._id !== commentId)
        );
      }
    } catch (error) {
      console.error("Error deleting comment:", error);
    }
  };

  // Add a new comment
  const addComment = (newComment) => {
    setComment((prevComment) => [newComment, ...prevComment]);
  };

  useEffect(() => {
    fetchComment();
  }, [postId]);

  if (loading) {
    return (
      <div className="flex justify-center my-8">
        <SpinLoading />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto h-auto">
      <div className="bg-white max-h-[500px] overflow-y-auto">
        {Array.isArray(Comment) && Comment.length > 0 ? (
          [...Comment].reverse().map((comment) => (
            <div
              key={comment._id}
              className="border-b border-gray-300 py-4 px-6"
            >
              <div className="flex items-start">
                {/* User avatar */}
                <div className="mr-4">
                  {comment.createdBy.profileImage ? (
                    <img
                      src={comment.createdBy.profileImage}
                      alt={comment.createdBy.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center text-gray-700">
                      {comment.createdBy.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>

                {/* Comment text */}
                <div className="flex-1">
                  <p className="font-bold text-gray-900">
                    {comment.createdBy.name}
                  </p>
                  <p className="text-gray-700">{comment.text}</p>

                  {/* Like Button and Time since comment was posted */}
                  <div className="flex justify-between items-center mt-2">
                    {/* <button
                      onClick={() => likeComment(comment._id)}
                      className="flex items-center hover:text-blue-600 transition duration-200"
                    >
                      {comment.likes.includes(user?.user._id) ? (
                        <FaHeart className="mr-1 text-red-500" size={23} />
                      ) : (
                        <FaRegHeart className="mr-1" size={20} />
                      )}
                      <span>{comment.likes.length}</span>
                    </button> */}
                    {/* Delete Button */}
                    {/* {comment.createdBy._id === user?.user._id && (
                      <button
                        onClick={() => openDeleteModal(comment._id)}
                        className="hover:text-red-600 transition duration-200"
                      >
                        <AiOutlineDelete className="mr-1" />
                      </button>
                    )}
                    {/* Delete Modal */}
                    {/* <DeleteModal
                      showModal={showDeleteModal}
                      onClose={closeDeleteModal}
                      onConfirm={() => deleteComment(comment._id)}
                    /> */}
                  </div>
                  <p className="text-sm text-gray-500">
                    {timeSince(comment.createdAt, true)}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500 p-6">
            Be the first to comment!
          </p>
        )}
      </div>
    </div>
  );
};

export default CommentList;
