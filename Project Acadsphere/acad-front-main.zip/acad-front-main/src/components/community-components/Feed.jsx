import React from "react";
import PostList from "../../components/community-components/PostList";
import CreatePost from "../../components/community-components/CreatePost";

const Feed = () => {
  return (
    <div className="container mx-auto  mt-[-1rem]">
      {/* Create Post Section */}
      <CreatePost />
      <PostList />
    </div>
  );
};

export default Feed;
