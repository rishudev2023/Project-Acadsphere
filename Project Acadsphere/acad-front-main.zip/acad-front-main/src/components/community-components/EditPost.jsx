import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import SpinLoading from "../../components/SpinLoading";
import { FaArrowLeftLong } from "react-icons/fa6";

const EditPost = () => {
  const { postId } = useParams(); // Get postId from URL
  const navigate = useNavigate(); // To navigate after editing
  const [post, setPost] = useState(null); // State to hold post details
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [updatedText, setUpdatedText] = useState(""); // Text to update the post

  // Fetch the post details to edit
  useEffect(() => {
    const fetchPost = async () => {
      try {
        const res = await axios.get(
          `https://acad-server-1.onrender.com/api/v1/community/post/${postId}`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );
        if (res.status === 200) {
          setPost(res.data);
          setUpdatedText(res.data.text); // Set the post text for editing
        }
      } catch (err) {
        setError("Error fetching the post");
        console.error("Error fetching post:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchPost();
  }, [postId]);

  // Handle the form submission for editing the post
  const handleEditSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.put(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}/edit`,
        { text: updatedText },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data.success) {
        // Redirect to the detailed post view after successful edit
        navigate(-1);
      }
    } catch (error) {
      console.log("Error updating post:", error);
      setError("Failed to update post");
    }
  };

  if (loading) {
    return (
      <div className="h-screen mt-[20vh]">
        <SpinLoading></SpinLoading>
        <h1 className="text-2xl text-center">Please wait...</h1>
      </div>
    );
  }

  if (error) {
    return <p className="text-center text-red-500">{error}</p>;
  }

  return (
    <div className="h-screen pt-[14vh] p-4">
      <div className="max-w-2xl mx-auto text-xl flex items-center gap-4 p-4">
        <FaArrowLeftLong
          className="cursor-pointer text-blue-600 hover:text-blue-800 transition duration-300"
          size={25}
          onClick={() => {
            navigate(-1);
          }}
        />
        <span className="text-3xl font-bold text-gray-800">Edit Post</span>
      </div>
      <div className=" flex justify-center items-center bg-gray-100">
        <div className="max-w-xl w-full mx-auto p-6 bg-white rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold mb-5 text-gray-800">
            Edit Your Post
          </h2>
          <form onSubmit={handleEditSubmit}>
            <textarea
              className="w-full h-32 border border-gray-300 p-4 rounded-md resize-none focus:ring-2 focus:ring-[#1E2761] focus:border-transparent focus:outline-none transition-all duration-300 text-gray-800"
              value={updatedText}
              onChange={(e) => setUpdatedText(e.target.value)}
              placeholder="Edit your post..."
              required
            />
            <div className="flex justify-end mt-5">
              <button
                type="submit"
                className="bg-[#1E2761] hover:bg-[#16204b] text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditPost;
