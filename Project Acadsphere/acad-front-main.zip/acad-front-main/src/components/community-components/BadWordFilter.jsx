// src/components/BadWordFilter.jsx
import React, { useState } from "react";
import { toast } from "react-toastify";
import { Filter } from "bad-words";
import { useUserContext } from "../../../context/userContext";

const BadWordFilter = ({ onFilterChange }) => {
  const [badWords, setBadWords] = useState(["badword1", "badword2"]); // Default bad words
  const [newBadWord, setNewBadWord] = useState(""); // State for new bad word input
  const { user } = useUserContext();

  const handleBadWordSubmit = (event) => {
    event.preventDefault();
    if (newBadWord.trim()) {
      setBadWords((prevBadWords) => [...prevBadWords, newBadWord.trim()]);
      setNewBadWord(""); // Clear input after submission
      toast.success(`"${newBadWord}" has been added to the bad words list!`);
      onFilterChange([...badWords, newBadWord.trim()]); // Notify parent about bad words update
    } else {
      toast.error("Please enter a valid word!");
    }
  };

  const filter = new Filter({ replace: "***" });
  filter.addWords(...badWords); // Add custom bad words to the filter

  const handleTextInput = (text) => {
    if (filter.isProfane(text)) {
      toast.error("Your input contains inappropriate content!");
      return true; // Indicates inappropriate content
    }
    return false; // Indicates no inappropriate content
  };

  return (
    <div className="mb-4">
      {user?.user && user?.user.role === "admin" && (
        <div>
          <h3 className="font-bold">Customize Bad Words</h3>
          <form
            onSubmit={handleBadWordSubmit}
            className="flex items-center mb-2"
          >
            <input
              type="text"
              value={newBadWord}
              onChange={(e) => setNewBadWord(e.target.value)}
              placeholder="Add a bad word"
              className="border border-gray-300 rounded-md p-2 w-full mr-2"
            />
            <button
              type="submit"
              className="bg-[#1E2761] text-white px-4 py-2 rounded-md"
            >
              Add
            </button>
          </form>
          <div>
            <h4 className="font-semibold">Current Bad Words:</h4>
            <ul>
              {badWords.map((word, index) => (
                <li key={index} className="text-sm">
                  {word}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default BadWordFilter;
