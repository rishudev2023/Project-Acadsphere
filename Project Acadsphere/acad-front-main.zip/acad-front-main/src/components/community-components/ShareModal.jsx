import React from "react";
import {
  AiOutlineCopy,
  AiOutlineWhatsApp,
  AiOutlineLink,
  AiOutlineClose,
} from "react-icons/ai";

const ShareModal = ({ showModal, onClose, postLink }) => {
  if (!showModal) return null;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(postLink);
    alert("Link copied to clipboard!");
    onClose();
  };

  const shareOnWhatsApp = () => {
    const whatsappLink = `https://api.whatsapp.com/send?text=${encodeURIComponent(
      postLink
    )}`;
    window.open(whatsappLink, "_blank");
    onClose();
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-[#3d3d3d]">
      <div className="relative bg-white p-6 max-w-md w-full rounded-lg shadow-lg space-y-4">
        {/* Cross button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 transition"
        >
          <AiOutlineClose size={20} />
        </button>

        <h3 className="text-xl font-semibold mb-4 text-center">Share Post</h3>

        {/* Share Options */}
        <div className="space-y-4">
          <button
            onClick={copyToClipboard}
            className="flex items-center w-full p-3 border rounded-lg hover:bg-gray-100 transition"
          >
            <AiOutlineCopy className="mr-2" />
            Copy Link
          </button>

          <button
            onClick={shareOnWhatsApp}
            className="flex items-center w-full p-3 border rounded-lg hover:bg-gray-100 transition"
          >
            <AiOutlineWhatsApp className="mr-2 text-green-500" />
            Share on WhatsApp
          </button>

          <button
            onClick={() => window.open(postLink, "_blank")}
            className="flex items-center w-full p-3 border rounded-lg hover:bg-gray-100 transition"
          >
            <AiOutlineLink className="mr-2" />
            Open Link in New Tab
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;
