import React, { useState } from "react";
import { FaTimes } from "react-icons/fa"; // For the cross icon
import { useNavigate } from "react-router-dom";

const CommunityFeaturesBanner = () => {
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = useState(true);

  const closeBanner = () => {
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="bg-[#1E2761] text-white p-4 rounded-lg shadow-lg relative pt-[16vh]">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold">
            🎉 Welcome to Acadsphere's New Community Feature!
          </h2>
          <p className="mt-2 text-sm">
            Join the conversation, share your thoughts, memes, and exam tips
            with fellow students in our brand-new Community section! Also, stay
            updated with important announcements through our Notifications
            feature.
          </p>
          <button
            className="border rounded-md bg-white text-[#1E2761] p-2"
            onClick={() => {
              navigate("/community/feeds");
            }}
          >
            Try Now
          </button>
        </div>
        <button onClick={closeBanner} className="text-white focus:outline-none">
          <FaTimes className="text-xl" />
        </button>
      </div>
    </div>
  );
};

export default CommunityFeaturesBanner;
