import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import SpinLoading from "../SpinLoading"; // Assuming you have a loading spinner component
import { useNavigate } from "react-router-dom";
import { useUserContext } from "../../../context/userContext";
import { usePostContext } from "../../../context/postContext";
import { Link } from "react-router-dom";
import DeleteModal from "./DeleteModal";
import ShareModal from "./ShareModal";
import { timeSince } from "../../utils/timeSince";
import { FaRegSadCry, FaClipboardList } from "react-icons/fa";

import {
  AiOutlineShareAlt,
  AiOutlineEdit,
  AiOutlineDelete,
} from "react-icons/ai";
import { FaRegHeart, FaHeart } from "react-icons/fa";
import { MdOutlineInsertComment } from "react-icons/md";
import CreatePost from "./CreatePost";

const MyPost = () => {
  const navigate = useNavigate();
  const { user } = useUserContext();
  const [loading, setLoading] = useState(true);
  const [isFetchingMore, setIsFetchingMore] = useState(false); // For infinite scroll loading state
  const [page, setPage] = useState(1); // Track pagination
  const [hasMore, setHasMore] = useState(true); // Track if there are more posts to load
  const { Post, setPost } = usePostContext();
  const observerRef = useRef(); // Ref to keep track of intersection observer
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const [showShareModal, setShowShareModal] = useState(false); // State for controlling the share modal visibility

  // Function to open the share modal
  const openShareModal = () => setShowShareModal(true);

  // Function to close the share modal
  const closeShareModal = () => setShowShareModal(false);

  const openDeleteModal = () => setShowDeleteModal(true);

  // Function to close the delete modal
  const closeDeleteModal = () => setShowDeleteModal(false);

  const postLink = `${window.location.origin}/community/post/${Post._id}`;
  const userId = user?.user._id;

  const fetchPosts = async (page) => {
    try {
      const res = await axios.get(
        `https://acad-server-1.onrender.com/api/v1/community/user/${userId}/posts`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      if (res.data.success) {
        const posts = res.data.data.posts;
        setPost((prevPosts) => [...posts]);
        if (posts.length === 0 || posts.length < 10) setHasMore(false);
      }
    } catch (error) {
      console.log("Error fetching posts:", error);
    } finally {
      setLoading(false);
      setIsFetchingMore(false);
    }
  };

  // Like a post
  const likePost = async (postId) => {
    try {
      const res = await axios.put(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}/like`,
        {},
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (res.data.success) {
        setPost((prevPosts) =>
          prevPosts.map((post) =>
            post._id === postId ? { ...post, likes: res.data.likes } : post
          )
        );
      }
    } catch (error) {
      console.log("Error liking post:", error);
    }
  };

  const deletePost = async (postId) => {
    try {
      const res = await axios.delete(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        // Update the feed by removing the deleted post from the state
        setPost((prevPosts) => prevPosts.filter((post) => post._id !== postId));
      }
    } catch (error) {
      console.log("Error deleting post:", error);
    } finally {
      closeDeleteModal(); // Close the modal after the action is completed
    }
  };

  useEffect(() => {
    fetchPosts(page); // Fetch the initial posts
  }, [page]);

  useEffect(() => {
    fetchPosts(page); // Fetch the initial posts
  }, [page]);

  // Infinite scrolling logic with IntersectionObserver
  useEffect(() => {
    if (loading || !hasMore) return; // Do not observe if still loading or no more posts

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !isFetchingMore) {
          // If last post is visible and not already fetching
          setIsFetchingMore(true); // Set fetching to true
          setPage((prevPage) => prevPage + 1); // Load the next page
        }
      },
      {
        root: null, // Observe the viewport
        rootMargin: "200px", // Start loading more before reaching the bottom
        threshold: 0.1,
      }
    );

    if (observerRef.current) {
      observer.observe(observerRef.current); // Observe the last post
    }

    return () => {
      if (observerRef.current) {
        observer.unobserve(observerRef.current); // Cleanup observer on unmount
      }
    };
  }, [loading, hasMore, isFetchingMore]);

  if (loading && page === 1) {
    return <SpinLoading />;
  }

  return (
    <div className="max-w-2xl mx-auto pt-[4vh]">
      <div className="flex items-center justify-center mb-4">
        <FaClipboardList className="text-3xl text-[#1E2761] mr-2" />
        <h1 className="text-2xl font-bold text-gray-800">Your Posts</h1>
      </div>
      <hr />
      <div className="bg-white shadow-lg rounded-lg max-h-[600px] overflow-y-auto p-1">
        {Post && Post.length > 0 ? (
          [...Post].map((post, index) => (
            <div
              key={post._id}
              className="border-b border-gray-200 py-6 px-5 flex items-start bg-white hover:bg-gray-50 shadow-sm hover:shadow-md transition-shadow duration-300 rounded-lg mb-4"
              ref={index === 0 ? observerRef : null}
            >
              {/* User Avatar */}
              <div className="mr-5">
                {post.createdBy && post.createdBy.profileImage ? (
                  <img
                    src={post.createdBy.profileImage}
                    alt={post.createdBy.name}
                    className="w-12 h-12 rounded-full object-cover shadow-md"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center text-gray-700 font-semibold">
                    {post.createdBy.name.charAt(0).toUpperCase()}
                  </div>
                )}
              </div>

              {/* Post Content */}
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  {/* User Name and College */}
                  <div>
                    <p className="font-semibold text-gray-900">
                      {post.createdBy ? post.createdBy.name : "Anonymous"}
                    </p>
                    <p className="text-sm text-gray-500">
                      {post.createdBy
                        ? post.createdBy.college.charAt(0).toUpperCase() +
                          post.createdBy.college.slice(1).toLowerCase()
                        : ""}
                    </p>
                  </div>

                  {/* Timestamp */}
                  <p className="text-sm text-gray-400">
                    {timeSince(post.createdAt, true)}
                  </p>
                </div>

                {/* Post Text */}
                <div className="border rounded-md p-4">
                  <Link to={`/community/post/${post._id}`}>
                    <p className="text-gray-700 leading-6">{post.text}</p>
                  </Link>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between mt-4 space-x-6 text-gray-500">
                  {/* Like Button */}
                  <button
                    onClick={() => likePost(post._id)}
                    className="flex items-center hover:text-blue-600 transition duration-200"
                  >
                    {post.likes.includes(user?.user._id) ? (
                      <FaHeart className="mr-1 text-red-500" size={23} />
                    ) : (
                      <FaRegHeart className="mr-1" size={20} />
                    )}
                    <span>{post.likes.length}</span>
                  </button>

                  {/* Comment Button */}
                  <button
                    onClick={() => navigate(`/community/post/${post._id}`)}
                    className="flex items-center hover:text-blue-600 transition duration-200"
                  >
                    <MdOutlineInsertComment className="mr-1" />
                    <span>{post.comments.length}</span>
                  </button>

                  {/* Share Button */}
                  <button
                    onClick={openShareModal}
                    className="flex items-center hover:text-blue-600 transition duration-200"
                  >
                    <AiOutlineShareAlt className="mr-1" />
                  </button>

                  {/* Share Modal */}
                  <ShareModal
                    showModal={showShareModal}
                    onClose={closeShareModal}
                    postLink={`${window.location.origin}/community/post/${post._id}`}
                  />

                  {/* Edit and Delete for Post Owner */}
                  {user?.user._id === post.createdBy._id && (
                    <div className="flex items-center space-x-4">
                      <button className="hover:text-blue-600 transition duration-200">
                        <Link to={`/community/post/${post._id}/edit`}>
                          <AiOutlineEdit className="mr-1" />
                        </Link>
                      </button>
                      <button
                        onClick={() => openDeleteModal(post._id)}
                        className="hover:text-red-600 transition duration-200"
                      >
                        <AiOutlineDelete className="mr-1" />
                      </button>

                      {/* Delete Modal */}
                      <DeleteModal
                        showModal={showDeleteModal}
                        onClose={closeDeleteModal}
                        onConfirm={() => deletePost(post._id)}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center p-4 bg-gray-100 rounded-lg shadow-lg w-80 mx-auto w-full">
            <FaRegSadCry className="text-5xl text-gray-400 mb-2" />
            <h1 className="text-xl font-semibold text-gray-800 mb-2">
              No Posts to Display
            </h1>
            <p className="text-center text-gray-500 mb-4">
              It looks like there are no posts yet.
            </p>
            <div className="flex flex-col items-center ">
              <h2 className="text-md font-medium text-gray-700 mb-2">
                Create a Post
              </h2>
              <CreatePost />
            </div>
          </div>
        )}

        {isFetchingMore && (
          <div className="flex justify-center my-8">
            <SpinLoading />
          </div>
        )}
      </div>
    </div>
  );
};

export default MyPost;
