import React, { useState } from "react";
import axios from "axios";
import { usePostContext } from "../../../context/postContext";

const CommentBox = ({ postId, onCommentAdded }) => {
  const [commentText, setCommentText] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const { Post, setPost } = usePostContext();

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/community/posts/${postId}/comment`,
        { text: commentText },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      if (res.data.success) {
        // Update the post state with the new comments
        setPost((prevPost) => {
          // Ensure that comments array exists, if not default it to an empty array
          const updatedComments = prevPost.comments
            ? [...prevPost.comments]
            : [];

          // Append the new comment to the existing comments array
          return {
            ...prevPost,
            comments: [...updatedComments, res.data.newComment],
          };
        });

        setCommentText(""); // Clear the input after successful comment
        if (onCommentAdded) onCommentAdded(); // Notify parent component (optional)
      }
    } catch (error) {
      console.error("Error commenting on post:", error);
      setError("Failed to add the comment. Please try again.");
    } finally {
      setLoading(false);
      location.reload();
    }
  };

  return (
    <div className="createpost mb-8">
      <div className="w-full max-w-2xl mx-auto pt-8 px-4 sm:px-0">
        <form
          onSubmit={handleCommentSubmit}
          className="bg-white shadow-lg rounded-md p-4 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-2"
        >
          <textarea
            className="w-full sm:h-16 h-20 p-4 resize-none border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#1E2761] transition-all"
            placeholder="Add a comment..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            required
          />
          <button
            type="submit"
            disabled={loading}
            className="bg-[#1E2761] hover:bg-[#16204b] text-white px-6 py-2 rounded-full font-semibold transition-all duration-300 w-full sm:w-auto sm:ml-2"
          >
            {loading ? "Processing..." : "Comment"}
          </button>
          {error && <p className="text-red-500 mt-2">{error}</p>}
        </form>
      </div>
    </div>
  );
};

export default CommentBox;
