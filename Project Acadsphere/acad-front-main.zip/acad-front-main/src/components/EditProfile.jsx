import React, { useState, useEffect } from "react";
import avatar from "../assets/images/avatar.jpg";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import { useUserContext } from "../../context/userContext";

const EditProfile = () => {
  const [image, setImage] = useState({});
  const [uploading, setUploading] = useState(false);
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    college: "",
    semester: "",
    branch: "",
    password: "",
    confirmPassword: "",
    profileImage: "",
  });
  const { user } = useUserContext();

  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(
          `https://acad-server-1.onrender.com/api/v1/editProfileApi/editProfile`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );

        if (res.data) {
          setUserData(res.data.data);
          setImage({
            url: res.data.data.profileImage,
            public_id: res.data.data.public_id,
          });
        }
      } catch (error) {
        console.error(error);
        toast.error("Failed to fetch user data");
      }
    };

    fetchData();
  }, []);

  const handleImage = async (e) => {
    const file = e.target.files[0];
    let formData = new FormData();
    formData.append("image", file);
    setUploading(true);

    try {
      const res = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/all/upload-image`,
        formData
      );
      // console.log(res.data.url);
      setImage({
        url: res.data.url,
        public_id: res.data.public_id,
      });
      setUploading(false);
      toast.success("Profile image uploaded.");
    } catch (error) {
      console.error(error);
      setUploading(false);
      toast.error("Image upload failed.");
    }
  };

  const handleOnChange = (e) => {
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleOnSubmit = async (e) => {
    e.preventDefault();
    const { name, college, semester, branch } = userData;

    if (!name || !college || !semester || !branch) {
      toast.error("All fields are required!");
      return;
    }

    if (semester === "select semester" || branch === "select branch") {
      toast.error("Please select valid semester and branch!");
      return;
    }

    const updatedData = {
      name,
      college,
      semester,
      branch,
      profileImage: image?.url,
    };

    try {
      const res = await axios.put(
        `https://acad-server-1.onrender.com/api/v1/editProfileApi/updateProfile`,
        updatedData,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      if (res.data) {
        toast.success("Profile updated successfully!");
        navigate(`/user/${user?.user._id}/profile`);
        window.location.reload();
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      console.error(error);
      toast.error("Failed to update profile");
    }
  };

  return (
    <div className="edit-profile">
      <div className="w-full mx-auto pt-[16vh]">
        <form
          action=""
          className="ease-in duration-300 w-[80%] sm:w-max shadow-sm backdrop-blur-md bg-white/80 lg:w-max mx-auto rounded-md px-6 py-5 mb-10"
          onSubmit={handleOnSubmit}
        >
          <label htmlFor="file-upload" className="custom-file-upload">
            <img
              src={
                image?.url ||
                "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEij_QwxFJUVyCwcPaECXCGiR7sLfuLj7xgfbujN_SRYUh6_ff4Qdst8mRlUsL8Ksd8CgKRDeGCEALDtxD_2OecpXyPSKs86_adG3a-T0SmdZ9tI12usAvmnnG6rLkOwWFlvsqD-_eQJunkzGSdwTXVkRKj0OGte8gLpTiD6Wv7lSmOu843JTCtTy-I-dHU/s320/de6e8d53598eecfb6a2d86919b267791.jpg"
              }
              alt=""
              className="h-32 w-32 bg-contain rounded-full mx-auto cursor-pointer"
            />
          </label>
          <label className="block text-center text-gray-900 text-base mb-2">
            Profile Picture
          </label>
          <input
            type="file"
            label="Image"
            name="myFile"
            id="file-upload"
            className="hidden"
            accept=".jpeg, .png, .jpg"
            onChange={handleImage}
          />

          <div className="mb-3">
            <label htmlFor="name" className="block text-gray-700 text-sm mb-2">
              Name
            </label>
            <input
              type="text"
              name="name"
              value={userData.name}
              onChange={handleOnChange}
              placeholder="Enter your Name"
              className="shadow-sm bg-white appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focusshadow-outline"
              required
            />
          </div>

          <div className="mb-3">
            <select
              className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
              name="college"
              value={userData.college}
              onChange={handleOnChange}
            >
              <option selected disabled>
                select college
              </option>

              <option> BHAGALPUR COLLEGE OF ENGINEERING, BHAGALPUR</option>
              <option>GAYA COLLEGE OF ENGINEERING, GAYA</option>
              <option>DARBHANGA COLLEGE OF ENGINEERING, DARBHANGA</option>
              <option>MOTIHARI COLLEGE OF ENGINEERING, MOTIHARI</option>
              <option>
                LOK NAYAK JAI PRAKASH INSTITUTE OF TECHNOLOGY, CHAPRA
              </option>
              <option>SERSHAH ENGINEERING COLLEGE, SASARAM, ROHTAS</option>
              <option>
                RASHTRAKAVI RAMDHARI SINGH DINKAR COLLEGE OF ENGINEERING,
                BEGUSARAI
              </option>
              <option>SUPAUL COLLEGE OF ENGINEERING, SUPAUL</option>
              <option>BAKHTIYARPUR COLLEGE OF ENGINEERING, PATNA</option>
              <option>SITAMARHI INSTITUTE OF TECHNOLOGY, SITAMARHI</option>
              <option> PURNEA COLLEGE OF ENGINEERING, PURNEA</option>
              <option>B. P. MANDAL COLLEGE OF ENGINEERING, MADHEPURA</option>
              <option>KATIHAR ENGINEERING COLLEGE, KATIHAR</option>
              <option>SAHARSA COLLEGE OF ENGINEERING, SAHARSA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, JAMUI</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, BANKA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, VAISHALI</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, NAWADA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, KISHANGANJ</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, MUNGER</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, SHEOHAR</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, WEST CHAMPARAN</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, AURANGABAD</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, KAIMUR</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, GOPALGANJ</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, MADHUBANI</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, SIWAN</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, JEHANABAD</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, ARWAL</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, KHAGARIA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, BUXAR</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, BHOJPUR</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, SHEIKHPURA</option>
              <option>GOVERNMENT ENGINEERING COLLEGE, LAKHISARAI</option>
              <option> GOVERNMENT ENGINEERING COLLEGE, SAMASTIPUR</option>
              <option> MUZAFFARPUR INSTITUTE OF TECHNOLOGY, MUZAFFARPUR</option>
              <option>
                Shri Phanishwar Nath Renu Engineering College, Araria
              </option>
              <option>VIDYA VIHAR INSTITUTE OF TECHNOLOGY,PURNIA</option>
              <option>NETAJI SUBHAS INSTITUTE OF TECHNOLOGY,BIHTA</option>
              <option> SITYOG INSTITUTE OF TECHNOLOGY,AURANGABAD</option>
              <option>AZMET INSTITUTE OF TECHNOLOGY,KISHENGANJ</option>
              <option>ADWAITA MISSION INSTITUTE OF TECHNOLOGY,BANKA</option>
              <option> MOTI BABU INSTITUTE OF TECHNOLOGY,FORBISGANJ</option>
              <option>EXALT COLLEGE OF ENGG. & TECHNOLOGY,VAISHALI</option>
              <option>MOTHERS INSTITUTE OF TECHNOLOGY,BIHTA</option>
              <option> R.P. SHARMA INSTITUTE OF TECHNOLOGY, PATNA</option>
              <option>
                MAULANA AZAD COLLEGE OF ENGINEERING &
                TECHNOLOGY,NEORAGANJ,NEORA,PATNA
              </option>
              <option> NALANDA COLLEGE OF ENGINEERING, CHANDI</option>
              <option>
                Millia Kishanganj College of Engineering & Technology,
                Kishanganj
              </option>
              <option> Millia Institute of Technology, Purnia</option>
              <option> Prabhu Kailash Engineering College, Aurangabad</option>
              <option>
                Siwan College of Engineering and Management, Siwan
              </option>
            </select>
          </div>
          <div className="flex items-center gap-8">
            <div className="mb-3">
              <select
                className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
                name="semester"
                value={userData.semester}
                onChange={handleOnChange}
              >
                <option>select semester</option>
                <option>First</option>
                <option>Second</option>
                <option>Third</option>
                <option>Fourth</option>
                <option>Fifth</option>
                <option>Sixth</option>
                <option>Seventh</option>
                <option>Eighth</option>
              </select>
            </div>

            <div className="mb-3">
              <select
                className="select bg-[#1E2761] text-white select-md w-full max-w-xs mb-5"
                name="branch"
                value={userData.branch}
                onChange={handleOnChange}
              >
                <option>select branch</option>
                <option>CSE</option>
                <option>EEE</option>
                <option>CIVIL</option>
                <option>MECH</option>
                <option>ELECTRICAL</option>
                <option>ECE</option>
                <option>IE</option>
                <option>FT</option>
              </select>
            </div>
          </div>

          <button
            className="bg-[#1E2761] active:scale-90 transition duration-150 transform hover:shadow-xl shadow-md w-full rounded-full px-6 py-2 text-xl font-medium text-white mx-auto text-center mb-3 mt-5"
            type="submit"
          >
            Update Profile
          </button>
          <ToastContainer />
        </form>
      </div>
    </div>
  );
};

export default EditProfile;
