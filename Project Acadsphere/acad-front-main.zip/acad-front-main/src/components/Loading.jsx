import React from "react";
import logo from "../assets/images/logo.svg";

const Loading = () => {
  return (
    <div className="flex flex-col justify-center items-center h-screen w-full bg-blue-500/45 border border-[#1E2761] rounded-lg">
      <div className="relative flex flex-col items-center">
        <img
          src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgdZPjmVZIjumxmsOsENuliphIkXFOykMdtYkfFJyZlkGiQmnab3nQPhKYEji9G28wORKLx5wzWirQq8Yc8mzOPq8bFsroyKe7Uv_9onP406X7VXtlw1R5oYhkErM-vphB_3Kw5vmwJ1hfcGYXOfzlN5DkqE-ZEG8k2RGK25mfjw5AC2pqKG3xRSI6siMY/s1600/logo.webp"
          alt="Loading logo"
          className="h-16 w-16 mb-4"
        />

        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-[#1E2761] rounded-full animate-bounce"></div>
          <div className="w-3 h-3 bg-[#1E2761] rounded-full animate-bounce delay-200"></div>
          <div className="w-3 h-3 bg-[#1E2761] rounded-full animate-bounce delay-400"></div>
        </div>
      </div>
    </div>
  );
};

export default Loading;
