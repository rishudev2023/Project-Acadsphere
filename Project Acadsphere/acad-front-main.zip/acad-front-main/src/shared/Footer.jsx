import React from "react";
import logo from "../assets/images/logo.svg";
import { Link } from "react-router-dom";
import { RiWhatsappLine } from "react-icons/ri";
import { FaLinkedin } from "react-icons/fa";
import { FaMessage } from "react-icons/fa6";
import { FaInstagramSquare } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="footer p-10 bg-gray-0 text-base-content">
      <aside className="flex items-center">
        <div>
          <Link to="/">
            <img
              src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgdZPjmVZIjumxmsOsENuliphIkXFOykMdtYkfFJyZlkGiQmnab3nQPhKYEji9G28wORKLx5wzWirQq8Yc8mzOPq8bFsroyKe7Uv_9onP406X7VXtlw1R5oYhkErM-vphB_3Kw5vmwJ1hfcGYXOfzlN5DkqE-ZEG8k2RGK25mfjw5AC2pqKG3xRSI6siMY/s1600/logo.webp"
              alt=""
              className="h-20 cursor-pointer"
            />
          </Link>
          <h1 className="text-2xl text-[#1E2761] py-5">
            Acadsphere <p className="text-lg"> &copy; 2024</p>
          </h1>
        </div>

        <p className="text-2xl p-5 m-12">
          Where engineers meet <br />
          semester needs.
        </p>
      </aside>
      <nav className="text-lg">
        <h6 className="footer-title text-[##7A2048] text-xl">
          Important Links
        </h6>
        <Link to="/about" className="link link-hover">
          About Us
        </Link>
        <Link to="/privacy-policy" className="link link-hover">
          Privacy Policy
        </Link>
        {/* <Link to="refund-policy" className="link link-hover">
          Refund and <br /> Cancellation Policy
        </Link> */}
        <Link to="terms&conditions" className="link link-hover">
          Terms & Conditions
        </Link>
        <Link to="cookie-policy" className="link link-hover">
          Cookie Policy
        </Link>
      </nav>
      <nav className="text-lg">
        <h6 className="footer-title text-[##7A2048] text-xl">Contact Us</h6>
        <a
          href="https://www.linkedin.com/company/acadsphere/?viewAsMember=true"
          className="flex items-center gap-1 link link-hover"
        >
          <FaLinkedin /> LinkedIn
        </a>
        <a
          href="https://whatsapp.com/channel/0029VaeuxXW1iUxgDuurZJ3T"
          className=" flex items-center gap-1 link link-hover"
        >
          <RiWhatsappLine className="text-2xl" /> WhatsApp
        </a>
        <a
          href="https://www.instagram.com/acadsphere.in/"
          className="flex items-center gap-1 link link-hover"
        >
          <FaInstagramSquare className="text-xl" /> Instagram
        </a>

        {/* <a
          href="https://acadsphere.in/feedback"
          className="flex items-center gap-1 link link-hover"
        >
          <FaMessage /> Send us message
        </a> */}
      </nav>
    </footer>
  );
};

export default Footer;
