import React, { useEffect, useState, useRef } from "react";
import { FaHome, FaBook, FaBell, FaUser } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import { useUserContext } from "../../context/userContext";
import SearchComponent from "../components/SearchComponent";
import axios from "axios";
import NotificationModal from "../components/NotificationModal";
import { MdPeopleAlt } from "react-icons/md";
import { FaUserCircle } from "react-icons/fa";
import { useTheme } from "../../context/ThemeContext";
import Toggle from "react-toggle";

const Navbar = () => {
  const navigate = useNavigate();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false); // State for notification modal
  const [unseenCount, setUnseenCount] = useState(0); // State for unseen notifications
  const dropdownRef = useRef(null);
  const { user, setUser } = useUserContext();
  const { isDarkMode, setIsDarkMode } = useTheme();

  const getUser = async () => {
    try {
      const res = await axios.post(
        `https://acad-server-1.onrender.com/api/v1/user/get-user`,
        {
          token: localStorage.getItem("token"),
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        setUser(res.data.data);
        setUnseenCount(res.data.data.unseenNotifications); // Set unseen notifications count
      } else {
        localStorage.clear();
      }
    } catch (error) {
      localStorage.clear();
      console.log(error);
    }
  };

  useEffect(() => {
    if (!user && localStorage.getItem("token")) {
      getUser();
    }
  }, [user]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [dropdownRef]);

  return (
    <div>
      <div className="bg-white shadow-md fixed top-0 left-0 w-full z-40 ease-in duration-300">
        <div className="py-4 px-6 container mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <img
                src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgdZPjmVZIjumxmsOsENuliphIkXFOykMdtYkfFJyZlkGiQmnab3nQPhKYEji9G28wORKLx5wzWirQq8Yc8mzOPq8bFsroyKe7Uv_9onP406X7VXtlw1R5oYhkErM-vphB_3Kw5vmwJ1hfcGYXOfzlN5DkqE-ZEG8k2RGK25mfjw5AC2pqKG3xRSI6siMY/s1600/logo.webp"
                alt="Logo"
                className="h-12 cursor-pointer"
              />
              <Link
                to="/"
                className="text-gray-800 text-3xl ml-3 hidden lg:block hover:text-blue-600 transition duration-200"
              >
                Acadsphere
              </Link>
              <div className="block lg:hidden flex-grow ml-4">
                <SearchComponent />
              </div>
            </div>
            <div className="lg:flex hidden gap-6 items-center">
              <SearchComponent />
              {user ? (
                <div className="relative flex items-center gap-6">
                  {user?.user && user?.user.role === "admin" && (
                    <Link
                      to="/admin/my-questions"
                      className="text-gray-800 hover:text-blue-600 transition duration-200"
                    >
                      My Questions
                    </Link>
                  )}
                  <Link
                    to="/community/feeds"
                    className="text-xl text-gray-800 hover:text-blue-600 transition duration-200"
                  >
                    Community
                  </Link>

                  <div
                    className="flex items-center cursor-pointer relative"
                    onClick={() => setIsModalOpen(true)} // Open modal on click
                  >
                    <FaBell size={20} className="text-gray-800" />
                    {unseenCount > 0 && (
                      <span className="absolute top-0 right-0 bg-red-500 h-3 w-3 rounded-full"></span>
                    )}
                  </div>
                  <div
                    className="flex items-center cursor-pointer"
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  >
                    <div className="w-10 h-10 rounded-full overflow-hidden border border-gray-300">
                      {user?.user?.profileImage ? (
                        <img
                          alt="Profile"
                          src={user?.user?.profileImage}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <FaUserCircle
                          size={38}
                          className="cursor-pointer text-gray-700 cover"
                        />
                      )}
                    </div>
                  </div>
                  {isDropdownOpen && (
                    <ul
                      ref={dropdownRef}
                      className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg z-10"
                    >
                      <li>
                        <Link
                          to={`/user/${user?.user._id}/profile`}
                          className="block px-4 py-2 text-gray-800 hover:bg-gray-100 transition duration-200"
                        >
                          Profile
                        </Link>
                      </li>
                      <li>
                        <button
                          className="w-full text-left px-4 py-2 text-gray-800 hover:bg-gray-100 transition duration-200"
                          onClick={() => {
                            localStorage.clear();
                            navigate("/");
                            location.reload();
                          }}
                        >
                          Logout
                        </button>
                      </li>
                    </ul>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-4">
                  <Link to="/user/register">
                    <button className="bg-gray-800 text-white hover:bg-gray-700 transition duration-200 rounded-full px-6 py-2 text-lg font-medium shadow-md">
                      Signup
                    </button>
                  </Link>
                  <Link to="/login">
                    <button className="bg-gray-800 text-white hover:bg-gray-700 transition duration-200 rounded-full px-6 py-2 text-lg font-medium shadow-md">
                      Login
                    </button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Notification Modal */}
      <NotificationModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)} // Close modal
      />

      {/* Bottom Navigation Bar for Smaller Screens */}
      <div className="lg:hidden fixed bottom-0 left-0 w-full bg-white shadow-md z-50">
        <div className="flex justify-around py-2 px-4 border-t border-gray-200">
          <Link
            to="/"
            className="text-gray-800 flex flex-col items-center hover:text-blue-600 transition duration-200"
          >
            <FaHome size={20} />
            <span className="text-xs mt-1">Home</span>
          </Link>
          <Link
            to="/study-mode"
            className="text-gray-800 flex flex-col items-center hover:text-blue-600 transition duration-200"
          >
            <FaBook size={20} />
            <span className="text-xs mt-1">Study Mode</span>
          </Link>
          <Link
            to="/community/feeds"
            className="text-gray-800 flex flex-col items-center hover:text-blue-600 transition duration-200"
          >
            <MdPeopleAlt size={20} />
            <span className="text-xs mt-1">Community</span>
          </Link>
          <div
            onClick={() => {
              navigate("/updates");
            }}
            className="relative flex flex-col items-center cursor-pointer hover:text-blue-600 transition duration-200"
          >
            <FaBell size={20} />
            <span className="text-xs mt-1">Updates</span>
            {unseenCount > 0 && (
              <span className="absolute top-0 right-0 bg-red-500 h-3 w-3 rounded-full"></span>
            )}
          </div>
          <Link
            to={user?.user ? `/user/${user?.user._id}/profile` : "/login"}
            className="text-gray-800 flex flex-col items-center hover:text-blue-600 transition duration-200"
          >
            <FaUser size={20} />
            <span className="text-xs mt-1">{user ? "Profile" : "Login"}</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
