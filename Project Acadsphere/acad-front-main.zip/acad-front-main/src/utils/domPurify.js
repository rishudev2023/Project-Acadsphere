import DOMPurify from "dompurify";

const sanitize = (dirty) => {
  return DOMPurify.sanitize(dirty);
};

export default sanitize;
