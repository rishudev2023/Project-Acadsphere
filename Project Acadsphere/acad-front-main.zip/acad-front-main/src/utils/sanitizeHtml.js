import sanitizeHtml from "sanitize-html";

const sanitize = (dirty) => {
  return sanitizeHtml(dirty, {
    allowedTags: [],
    allowedAttributes: {},
  });
};

export default sanitize;
