export const timeSince = (date, short = false) => {
  const seconds = Math.floor((new Date() - new Date(date)) / 1000);

  // Determine the appropriate interval
  let interval = Math.floor(seconds / 31536000); // 1 year
  if (interval >= 1)
    return short
      ? `${interval}y`
      : `${interval} year${interval > 1 ? "s" : ""} ago`;

  interval = Math.floor(seconds / 2592000); // 1 month
  if (interval >= 1)
    return short
      ? `${interval}mo`
      : `${interval} month${interval > 1 ? "s" : ""} ago`;

  interval = Math.floor(seconds / 604800); // 1 week
  if (interval >= 1)
    return short
      ? `${interval}w`
      : `${interval} week${interval > 1 ? "s" : ""} ago`;

  interval = Math.floor(seconds / 86400); // 1 day
  if (interval >= 1)
    return short
      ? `${interval}d`
      : `${interval} day${interval > 1 ? "s" : ""} ago`;

  interval = Math.floor(seconds / 3600); // 1 hour
  if (interval >= 1)
    return short
      ? `${interval}h`
      : `${interval} hour${interval > 1 ? "s" : ""} ago`;

  interval = Math.floor(seconds / 60); // 1 minute
  if (interval >= 1)
    return short
      ? `${interval}m`
      : `${interval} minute${interval > 1 ? "s" : ""} ago`;

  return short
    ? `${Math.floor(seconds)}s`
    : `${Math.floor(seconds)} second${seconds > 1 ? "s" : ""} ago`;
};
