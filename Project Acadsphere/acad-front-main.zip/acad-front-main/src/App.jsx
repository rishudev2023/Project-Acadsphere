import React from "react";
import "./App.css";
import "./styles/Modal.css";
import "./pages/StarButton.css";

import Navbar from "./shared/Navbar";
import Footer from "./shared/Footer";
import ProtectedRoute from "./pages/ProtectedRoute";
import { Route, Routes, useLocation } from "react-router-dom";
import { useEffect, lazy, Suspense } from "react";
import { useUserContext } from "../context/userContext";
import { useNavigate } from "react-router-dom";
import Loading from "./components/Loading";
import QuestionReports from "./pages/admin/QuestionReports";
import OfflineMessage from "./components/OfflineMessage";
import VerifyOtp from "./pages/VerifyOtp";
import Sanitize from "./components/Sanitize";
import DomPurify from "./components/DomPurify";
import CommunityPage from "./pages//community-pages/CommunityPage";
import CreateNotification from "./pages/admin/CreateNotification";
import Notifications from "./components/Notifications";
import DetailPost from "./pages//community-pages/DetailPost";
import EditPost from "./components/community-components/EditPost";
import MyPosts from "./components/community-components/MyPosts";
import ProtectedSubscriptionRoute from "./pages/ProtectedSubscription";
import SubscriptionTermsConditions from "./pages/policyPages/SubscriptionTermsConditions";
import RichTextEditor from "./components/RichTextEditor";
// import CreatorsRegister from "./pages/CreatorsRegister";

// Lazy load components
const Home = lazy(() => import("./pages/Home"));
const Register = lazy(() => import("./pages/Register"));
const Login = lazy(() => import("./pages/Login"));
const Dashboard = lazy(() => import("./pages/admin/Dashboard"));
const NotFoundPage = lazy(() => import("./pages/NotFoundPage"));
const StudyMode = lazy(() => import("./components/StudyMode"));
const AddQuestion = lazy(() => import("./pages/admin/AddQuestion"));
const YearlyPYQs = lazy(() => import("./pages/YearlyPYQs"));
const ChapterwisePYQs = lazy(() => import("./pages/ChapterwisePYQs"));
const PrivacyPolicy = lazy(() => import("./pages/policyPages/PrivacyPolicy"));
const TermsConditions = lazy(() =>
  import("./pages/policyPages/TermsConditions")
);
const CookiePolicy = lazy(() => import("./pages/policyPages/CookiePolicy"));
const ComingSoon = lazy(() => import("./components/ComingSoon"));
const AddDetailedNotes = lazy(() => import("./pages/admin/AddDetailedNotes"));
const DetailedNotes = lazy(() => import("./pages/DetailedNotes"));
const UserProfile = lazy(() => import("./components/UserProfile"));
const ForgotPassword = lazy(() =>
  import("./components/password-reset/ForgotPassword")
);
const ResetPassword = lazy(() =>
  import("./components/password-reset/ResetPassword")
);
// const Feedback = lazy(() => import("./components/Feedback"));
// const FeedbackMessages = lazy(() => import("./pages/admin/FeedbackMessages"));
const AboutPage = lazy(() => import("./pages/AboutPage"));
const ImportantQuestions = lazy(() => import("./pages/ImportantQuestions"));
const SearchComponent = lazy(() => import("./components/SearchComponent"));
const ViewSolutionPage = lazy(() => import("./pages/ViewSolutionPage"));
const EditUpdateQuestion = lazy(() =>
  import("./pages/admin/EditUpdateQuestion")
);

const MyQuestions = lazy(() => import("./pages/admin/MyQuestions"));
const EditProfile = lazy(() => import("./components/EditProfile"));
const SubscriptionPage = lazy(() => import("./pages/SubscriptionPage"));
const SpinLoading = lazy(() => import("./components/SpinLoading"));

const usePageViews = () => {
  const location = useLocation();

  useEffect(() => {
    window.gtag("config", "G-B57VSPC3H0", {
      page_path: location.pathname + location.search,
    });
  }, [location]);
};

function App() {
  usePageViews();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useUserContext();

  const showFooter = () => {
    const hideFooterPaths = [
      "/study-mode/yearly-pyqs",
      "/study-mode/chapterwise-pyqs",
      "/study-mode/important-questions",
      "/study-mode/search",
      "/admin/my-questions",
    ];

    if (hideFooterPaths.includes(location.pathname)) {
      return false;
    }

    const viewSolutionPathRegex = /^\/view-solution\/[^/]+$/;
    if (viewSolutionPathRegex.test(location.pathname)) {
      return false;
    }

    return true;
  };

  useEffect(() => {
    if (
      user?.user?.isVerified === false &&
      location.pathname !== "/accounts/verifyOtp"
    ) {
      navigate("/accounts/verifyOtp");
    }
  }, [user, location]);

  // if (!user) {
  //   return <SpinLoading />;
  // }

  return (
    <>
      <Navbar />
      <Suspense fallback={<Loading />}>
        <Routes>
          <Route path="/sanitize" element={<Sanitize />} />
          <Route path="/dom-purify" element={<DomPurify />} />
          <Route
            path="/accounts/verifyOtp"
            element={
              <ProtectedRoute>
                <VerifyOtp />
              </ProtectedRoute>
            }
          />
          <Route path="/" element={<Home />} />
          <Route
            path="/study-mode"
            element={
              <ProtectedRoute>
                <StudyMode />
              </ProtectedRoute>
            }
          />
          <Route
            path="/study-mode/chapterwise-pyqs"
            element={
              <ProtectedRoute>
                <ProtectedSubscriptionRoute>
                  <ChapterwisePYQs />
                </ProtectedSubscriptionRoute>
              </ProtectedRoute>
            }
          />
          <Route
            path="/study-mode/important-questions"
            element={
              <ProtectedRoute>
                <ImportantQuestions />
              </ProtectedRoute>
            }
          />
          <Route
            path="/study-mode/yearly-pyqs"
            element={
              <ProtectedRoute>
                <ProtectedSubscriptionRoute>
                  <YearlyPYQs />
                </ProtectedSubscriptionRoute>
              </ProtectedRoute>
            }
          />
          <Route
            path="/view-solution/:questionId"
            element={
              <ProtectedRoute>
                <ViewSolutionPage />
              </ProtectedRoute>
            }
          />
          <Route path="/coming-soon" element={<ComingSoon />} />
          <Route
            path="/study-mode/detailed-notes"
            element={
              <ProtectedRoute>
                <DetailedNotes />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/:id/profile"
            element={
              <ProtectedRoute>
                <UserProfile />
              </ProtectedRoute>
            }
          />
          {/* <Route
            path="/feedback"
            element={
              <ProtectedRoute>
                <Feedback />
              </ProtectedRoute>
            }
          /> */}
          {/* <Route
            path="/feedback-messages"
            element={
              <ProtectedRoute>
                <FeedbackMessages />
              </ProtectedRoute>
            }
          /> */}
          <Route
            path="/study-mode/search"
            element={
              <ProtectedRoute>
                <SearchComponent />
              </ProtectedRoute>
            }
          />
          <Route path="/about" element={<AboutPage />} />
          <Route
            path="/user/:id/edit-profile"
            element={
              <ProtectedRoute>
                <EditProfile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/subscription-premium"
            element={
              <ProtectedRoute>
                <SubscriptionPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/community/feeds"
            element={
              <ProtectedRoute>
                <CommunityPage />
              </ProtectedRoute>
            }
          />

          <Route
            path="/community/post/:postId"
            element={
              <ProtectedRoute>
                <DetailPost />
              </ProtectedRoute>
            }
          />

          <Route
            path="/community/my-posts"
            element={
              <ProtectedRoute>
                <MyPosts />
              </ProtectedRoute>
            }
          />

          <Route
            path="/community/post/:postId/edit"
            element={
              <ProtectedRoute>
                <EditPost />
              </ProtectedRoute>
            }
          />

          <Route
            path="/updates"
            element={
              <ProtectedRoute>
                <Notifications />
              </ProtectedRoute>
            }
          />
          {user?.user && user?.user.role === "admin" && (
            <>
              <Route
                path="/admin/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/addquestion"
                element={
                  <ProtectedRoute>
                    <AddQuestion />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/add-detailed-notes"
                element={
                  <ProtectedRoute>
                    <AddDetailedNotes />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/my-questions"
                element={
                  <ProtectedRoute>
                    <MyQuestions />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/questions/:id/edit"
                element={
                  <ProtectedRoute>
                    <EditUpdateQuestion />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/question-reports"
                element={
                  <ProtectedRoute>
                    <QuestionReports />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/create-notification"
                element={
                  <ProtectedRoute>
                    <CreateNotification />
                  </ProtectedRoute>
                }
              />
            </>
          )}

          <Route path="/login" element={<Login />} />
          <Route path="/user/register" element={<Register />} />
          {/* <Route
            path="/knowledge-architect/register"
            element={<CreatorsRegister />}
          /> */}
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/terms&conditions" element={<TermsConditions />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="/rich-editor" element={<RichTextEditor />} />
          <Route
            path="/subscription-policy"
            element={<SubscriptionTermsConditions />}
          />

          <Route
            path="/accounts/forgot-password"
            element={<ForgotPassword />}
          />
          <Route path="/accounts/reset-password" element={<ResetPassword />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
        <OfflineMessage />
      </Suspense>
      {showFooter() && <Footer />}
    </>
  );
}

export default App;
