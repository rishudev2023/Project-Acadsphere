import { SitemapStream, streamToPromise } from "sitemap";
import { createWriteStream } from "fs";

// Set the hostname of your website (your website URL)
const smStream = new SitemapStream({ hostname: "https://www.acadsphere.in/" });

// Define the URLs of your website that you want to include in the sitemap
const links = [
  { url: "/", changefreq: "yearly", priority: 1.0 }, // Home page (highest priority)

  // User actions
  { url: "/user/register", changefreq: "yearly", priority: 0.9 }, // Important, but static
  { url: "/login", changefreq: "yearly", priority: 0.9 }, // Important for users

  // Study mode - slightly lower than registration and login but important
  { url: "/study-mode", changefreq: "yearly", priority: 0.85 },
  {
    url: "/study-mode/chapterwise-pyqs",
    changefreq: "monthly",
    priority: 0.85,
  }, // Frequently updated
  { url: "/study-mode/yearly-pyqs", changefreq: "monthly", priority: 0.85 }, // Frequently updated

  // Community pages - dynamic, but less critical than study-mode
  { url: "/community/feeds", changefreq: "monthly", priority: 0.8 },

  // About page - static and less important than user interaction or content pages
  { url: "/about", changefreq: "yearly", priority: 0.7 },
];

// Create a writable stream to output the sitemap.xml file to the public folder
const writeStream = createWriteStream("./public/sitemap.xml");

// Pipe the sitemap data to the writable stream
smStream.pipe(writeStream);

// Loop over your links and add them to the sitemap
links.forEach((link) => {
  smStream.write(link);
});

// Close the stream once all links are written
smStream.end();

// Once the stream is finished, this will promise to log a success message
streamToPromise(smStream)
  .then(() => console.log("Sitemap successfully created!"))
  .catch((err) => console.error("Error generating sitemap:", err));
