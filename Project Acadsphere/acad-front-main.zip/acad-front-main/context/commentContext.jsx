import React from "react";
import { createContext, useContext, useState } from "react";

const CommentContext = createContext();

const CommentProvider = ({ children }) => {
  const [Comment, setComment] = useState([]);
  return (
    <CommentContext.Provider value={{ Comment, setComment }}>
      {children}
    </CommentContext.Provider>
  );
};

const useCommentContext = () => {
  return useContext(CommentContext);
};

export { CommentProvider, useCommentContext };
