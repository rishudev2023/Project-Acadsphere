import React from "react";
import { createContext, useContext, useState } from "react";

const QuestionContext = createContext();

const QuestionProvider = ({ children }) => {
  const [Question, setQuestion] = useState([]);
  return (
    <QuestionContext.Provider value={{ Question, setQuestion }}>
      {children}
    </QuestionContext.Provider>
  );
};

const useQuestionContext = () => {
  return useContext(QuestionContext);
};

export { QuestionProvider, useQuestionContext };
