import React from "react";
import { createContext, useContext, useState } from "react";

const FeedbackContext = createContext();

const FeedbackProvider = ({ children }) => {
  const [feedback, setFeedback] = useState([]);

  return (
    <FeedbackContext.Provider value={{ feedback, setFeedback }}>
      {children}
    </FeedbackContext.Provider>
  );
};

const useFeedbackContext = () => {
  return useContext(FeedbackContext);
};

export { FeedbackProvider, useFeedbackContext };
