import React from "react";
import { createContext, useContext, useState } from "react";

const ReportsContext = createContext();

const ReportsProvider = ({ children }) => {
  const [report, setReport] = useState([]);

  return (
    <ReportsContext.Provider value={{ report, setReport }}>
      {children}
    </ReportsContext.Provider>
  );
};

const useReportContext = () => {
  return useContext(ReportsContext);
};

export { ReportsProvider, useReportContext };
